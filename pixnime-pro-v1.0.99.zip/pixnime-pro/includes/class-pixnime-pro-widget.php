<?php
/**
 * Widget class for Pixnime Pro
 * Classe vide pour éviter l'erreur fatale
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Pixnime_Pro_Widget extends WP_Widget {
    
    /**
     * Constructor
     */
    public function __construct() {
        parent::__construct(
            'pixnime_pro_widget',
            __('Pixnime Pro Avatar', 'pixnime-pro'),
            array(
                'description' => __('Display your AI generated avatar', 'pixnime-pro')
            )
        );
    }
    
    /**
     * Widget frontend display
     */
    public function widget($args, $instance) {
        echo $args['before_widget'];
        
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        
        // Afficher l'avatar de l'utilisateur
        $user_id = get_current_user_id();
        $avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
        
        if ($avatar_url) {
            echo '<div class="pixnime-widget-avatar">';
            echo '<img src="' . esc_url($avatar_url) . '" alt="' . esc_attr__('AI Avatar', 'pixnime-pro') . '" style="max-width: 100%; height: auto;" />';
            echo '</div>';
        } else {
            echo '<p>' . __('No avatar generated yet.', 'pixnime-pro') . '</p>';
        }
        
        echo $args['after_widget'];
    }
    
    /**
     * Widget backend form
     */
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('My Avatar', 'pixnime-pro');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:', 'pixnime-pro'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }
    
    /**
     * Update widget settings
     */
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        return $instance;
    }
} 
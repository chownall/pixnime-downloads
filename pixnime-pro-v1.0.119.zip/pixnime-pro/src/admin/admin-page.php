<?php
/**
 * Main admin page for Pixnime Pro
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get current user avatar
$user_id = get_current_user_id();
$current_avatar = get_user_meta($user_id, 'pixnime_avatar_url', true);
$current_avatar_id = get_user_meta($user_id, 'pixnime_avatar_id', true);
$current_avatar_prompt = get_user_meta($user_id, 'pixnime_avatar_prompt', true);
$avatar_variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
$settings = get_option('pixnime_pro_settings', array());

// Vérifier les crédits disponibles
$api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
$credits_remaining = 0;
$credits_status = 'unknown';

if (!empty($api_key)) {
    $pixnime_api = new Pixnime_Pro_API();
    $credit_check = $pixnime_api->verify_pixnime_credits($api_key);
    if ($credit_check['success']) {
        $credits_remaining = $credit_check['credits'];
        $credits_status = 'verified';
    } else {
        $credits_status = 'error';
    }
}

if (!$avatar_variations) {
    $avatar_variations = array();
}

// Check if avatar was just generated
$just_generated = isset($_GET['generated']) && $_GET['generated'] == '1';

// Create instance for generating random ID
$pixnime_instance = new Pixnime_Pro();
?>

<div class="wrap pixnime-pro-admin">
    <!-- Header Graphique Pixnime -->
    <div class="pixnime-header">
        <div class="pixnime-header-content">
            <div class="pixnime-brand">
                <div class="pixnime-logo">
                    <img src="<?php echo esc_url(PIXNIME_PRO_PLUGIN_URL . 'assets/images/logopixnime120.png'); ?>" alt="Pixnime" class="pixnime-logo-img">
                    <div class="pixnime-brand-text">
                        <h1 class="pixnime-title">Pixnime Pro</h1>
                        <p class="pixnime-subtitle"><?php esc_html_e('Generate AI avatars and maintain visual consistency in your creations', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="pixnime-header-actions">
                <!-- Crédits restants -->
                <div class="pixnime-credits">
                    <div class="credits-icon">
                        <span class="dashicons dashicons-star-filled"></span>
                    </div>
                    <div class="credits-info">
                        <span class="credits-label"><?php esc_html_e('Remaining credits', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></span>
                        <span class="credits-count <?php echo esc_attr($credits_status); ?>">
                            <?php if ($credits_status === 'verified'): ?>
                                <?php echo number_format($credits_remaining); ?>
                            <?php elseif ($credits_status === 'error'): ?>
                                <span class="error-text">Erreur</span>
                            <?php else: ?>
                                <span class="unknown-text">--</span>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
                
                <!-- Actions principales avec table pour meilleur alignement -->
                <table class="pixnime-header-buttons-table">
                    <tr>
                        <?php if (empty($api_key)): ?>
                            <td>
                                <a href="https://www.pixnime.com/wordpress" target="_blank" class="button button-primary pixnime-btn-register">
                                    <span class="dashicons dashicons-admin-users"></span>
                                    <?php esc_html_e('Sign up', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </a>
                            </td>
                            <td>
                                <a href="https://www.pixnime.com/index.php?page=howto&action=install" target="_blank" class="button button-secondary pixnime-btn-api">
                                    <span class="dashicons dashicons-admin-network"></span>
                                    <?php esc_html_e('Get your API KEY', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </a>
                            </td>
                        <?php else: ?>
                            <td>
                                <a href="https://www.pixnime.com/index.php?page=offers" target="_blank" class="button button-primary pixnime-btn-credits">
                                    <span class="dashicons dashicons-plus-alt"></span>
                                    <?php esc_html_e('Buy credits', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </a>
                            </td>
                        <?php endif; ?>
                        
                        <td>
                            <a href="https://www.pixnime.com/free-trial" target="_blank" class="button button-secondary pixnime-btn-trial" id="pixnime-btn-free-credits">
                                <span class="dashicons dashicons-heart"></span>
                                <?php esc_html_e('100 free credits', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <a href="<?php echo esc_url(admin_url('admin.php?page=pixnime-pro-settings')); ?>" class="button button-secondary pixnime-btn-settings">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <?php esc_html_e('Settings', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- Barre de statut simplifiée -->
        <div class="pixnime-status-bar">
            <div class="status-item">
                <span class="dashicons dashicons-images-alt2"></span>
                                        <span class="status-label"><?php esc_html_e('Generations:', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></span>
                <span class="status-value">
                    <?php echo count($avatar_variations) + ($current_avatar ? 1 : 0); ?> <?php esc_html_e('created', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </span>
            </div>
        </div>
    </div>
    
    <!-- Section Publicitaire Pixnime Offers - Alignée à droite -->
    <div class="pixnime-promo-sidebar">
        <div class="pixnime-promo-content">
            <div class="pixnime-promo-image">
                <span class="dashicons dashicons-star-filled promo-icon"></span>
            </div>
            <div class="pixnime-promo-text">
                <h4 class="promo-title">🚀 <?php esc_html_e('VIP Offers', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h4>
                <p class="promo-description">
                    <?php esc_html_e('Unlimited generations !', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </p>
                <a href="https://www.pixnime.com/index.php?page=offers" target="_blank" class="promo-cta-button">
                    <span class="dashicons dashicons-star-filled"></span>
                    <?php esc_html_e('See offers', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </a>
            </div>
        </div>
        <div class="promo-close-btn" onclick="this.parentElement.style.display='none'">
            <span class="dashicons dashicons-no-alt"></span>
        </div>
    </div>
    
    <?php if ($just_generated): ?>
    <div class="notice notice-success is-dismissible">
        <p><?php esc_html_e('Avatar generated successfully!', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></p>
    </div>
    <?php endif; ?>
    
    <div class="pixnime-pro-container">
        <!-- Generate "Origin" Avatar or Illustration Section -->
        <div class="generate-section">
            <div class="generate-section-header">
                <h2><?php esc_html_e('Generate "Origin" Avatar or Illustration', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h2>
                <div class="generate-section-actions">
                    <button type="button" class="button button-secondary add-to-workspace" id="upload-to-media-library-btn">
                        <span class="dashicons dashicons-images-alt2"></span>
                        <?php esc_html_e('Choose a file from the library', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?> (PNG ONLY)
                    </button>
                </div>
            </div>
            <div class="avatar-generator">
                <form id="pixnime-generate-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="avatar_description"><?php esc_html_e('Description', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                            </th>
                            <td>
                                <textarea id="avatar_description" name="description" rows="6" cols="50" required><?php echo esc_textarea(
'A beautiful blonde young woman in red slim pants and beige stiletto heels, black crop top t-shirt with giraffe head print, standing and presenting a very modern small electric car'
); ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="style_preset"><?php esc_html_e('Style Preset', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                            </th>
                            <td>
                                <select id="style_preset" name="style_preset" class="regular-text">
                                    <option value=""><?php esc_html_e('-- Choose a style --', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="none"><?php esc_html_e('None (No style)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="2d_cartoon"><?php esc_html_e('2D Cartoon', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="3d_cartoon"><?php esc_html_e('3D Cartoon', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="flat_vector"><?php esc_html_e('Flat Vector', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="cel_shading"><?php esc_html_e('Cel Shading', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="stylized_illustration"><?php esc_html_e('Stylized Illustration', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="pencil_sketch"><?php esc_html_e('Pencil Sketch', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="ink_drawing"><?php esc_html_e('Ink Drawing', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="watercolor"><?php esc_html_e('Watercolor', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="charcoal"><?php esc_html_e('Charcoal', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="ultra_realistic"><?php esc_html_e('Ultra Realistic', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="4k_photorealism"><?php esc_html_e('4K Photorealism', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="cinematic"><?php esc_html_e('Cinematic', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="low_poly"><?php esc_html_e('Low Poly', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="pixel_art"><?php esc_html_e('Pixel Art', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="isometric"><?php esc_html_e('Isometric', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="line_art"><?php esc_html_e('Line Art', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="papercut"><?php esc_html_e('Papercut', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                </select>
                                <p class="description">
                                    <?php esc_html_e('Select a style that will be automatically added to your description', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </p>
                                <div id="style_description" class="style-description"></div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="avatar_randomunique"><?php esc_html_e('Origin ID', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="avatar_randomunique" name="avatar_randomunique" value="<?php echo esc_attr($pixnime_instance->generate_random_id()); ?>" class="regular-text" readonly />
                                <p class="description">
                                    <?php esc_html_e('Unique identifier for this avatar generation (generated once at page load)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary" id="generate-avatar-btn">
                            <span class="dashicons dashicons-admin-generic"></span>
                            <?php esc_html_e('Generate Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        </button>
                    </p>
                </form>
                
                <div id="generation-status" style="display: none;">
                    <div class="generation-loading">
                        <span class="spinner is-active"></span>
                        <span><?php esc_html_e('Generating your avatar...', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Workspace - Avatar Original et Variations -->
        <?php if ($current_avatar || !empty($avatar_variations)): ?>
        <div class="pixnime-pro-section pixnime-workspace">
            <div class="workspace-header">
                <h2>
                    <span class="dashicons dashicons-art"></span>
                    <?php esc_html_e('My Workspace', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </h2>
                <div class="workspace-header-actions">
                    <button class="button button-secondary clear-workspace" title="<?php esc_attr_e('Clear workspace (keep files)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Clear workspace', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                    </button>
                </div>
            </div>
            
            <div class="workspace-content">
                <!-- Avatar Principal -->
                <?php if ($current_avatar): ?>
                <div class="workspace-main-avatar">
                    <div class="main-avatar-label">
                        <span class="dashicons dashicons-star-filled"></span>
                        <?php esc_html_e('Main Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                    </div>
                    
                    <div class="main-avatar-container">
                        <img src="<?php echo esc_url($current_avatar); ?>" alt="<?php esc_attr_e('Main Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>" class="main-avatar-image" />
                        
                        <div class="main-avatar-actions">
                            <button class="button button-secondary delete-current-avatar" title="<?php esc_attr_e('Delete main avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                                <span class="dashicons dashicons-trash"></span>
                                <?php esc_html_e('Delete', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                            </button>
                        </div>
                        
                        <?php if (!empty($current_avatar_prompt)): ?>
                        <div class="main-avatar-prompt">
                            <strong><?php esc_html_e('Prompt used:', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></strong>
                            <div class="prompt-content"><?php echo esc_html($current_avatar_prompt); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Génération de Variations -->
                    <div class="variation-creator">
                        <div class="variation-creator-header">
                            <span class="dashicons dashicons-plus-alt2"></span>
                            <?php esc_html_e('Create a Variation', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        </div>
                        <div class="variation-creator-form">
                            <div class="variation-form-inputs">
                                <textarea id="variation_prompt" name="variation_prompt" class="variation-prompt-input" rows="3" placeholder="<?php esc_attr_e('Describe the variation...', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>"></textarea>
                                <button type="button" class="button button-secondary" id="generate-variation-btn">
                                    <span class="dashicons dashicons-art"></span>
                                    <?php esc_html_e('Generate', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </button>
                            </div>
                        </div>
                        <!-- Conteneur pour les messages d'erreur/succès de variation -->
                        <div id="variation-error-container" class="variation-status-container"></div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Grille des Variations -->
                <?php if (!empty($avatar_variations)): ?>
                <div class="workspace-variations">
                    <div class="variations-label">
                        <span class="dashicons dashicons-images-alt2"></span>
                        <?php esc_html_e('Generated Variations', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?> (<?php echo count($avatar_variations); ?>)
                    </div>
                    <div class="variations-grid">
                        <?php foreach ($avatar_variations as $index => $variation): ?>
                                                         <div class="variation-card">
                                 <div class="variation-image-container">
                                     <img src="<?php echo esc_url($variation['url']); ?>" alt="<?php esc_attr_e('Variation', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>" />
                                 </div>
                                 <div class="variation-info">
                                     <?php if (isset($variation['original_avatar_id']) && $variation['original_avatar_id']): ?>
                                         <div class="variation-id">
                                             <code><?php echo esc_html($variation['original_avatar_id']); ?>_var<?php echo esc_html($index + 1); ?></code>
                                         </div>
                                     <?php endif; ?>
                                     <?php if (isset($variation['prompt']) && $variation['prompt']): ?>
                                         <div class="variation-prompt">
                                             <span class="prompt-text"><?php echo esc_html($variation['prompt']); ?></span>
                                             <button class="copy-prompt-btn" data-prompt="<?php echo esc_attr($variation['prompt']); ?>" title="<?php esc_attr_e('Copier le prompt', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                                                 <span class="dashicons dashicons-admin-page"></span>
                                             </button>
                                         </div>
                                     <?php endif; ?>
                                 </div>
                                 <div class="variation-actions">
                                     <button class="button button-secondary delete-variation" data-index="<?php echo esc_attr($index); ?>" data-url="<?php echo esc_attr($variation['url']); ?>">
                                         <?php esc_html_e('Delete', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                     </button>
                                 </div>
                             </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>


    </div>
</div>

<style>
.pixnime-pro-admin {
    max-width: 1400px;
}

.pixnime-pro-container {
    display: grid;
    gap: 2rem;
    margin-top: 1rem;
}

.pixnime-pro-section {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

/* Workspace Styles */
.pixnime-workspace {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    padding: 2rem;
    position: relative;
    overflow: hidden;
}

.pixnime-workspace::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #8b5cf6, #06b6d4);
}

.workspace-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #e2e8f0;
}

.workspace-header h2 {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin: 0;
    color: #1e293b;
    font-size: 1.5rem;
    font-weight: 600;
}

.workspace-header .dashicons {
    color: #3b82f6;
    font-size: 1.5rem;
}

.workspace-header-actions {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.clear-workspace {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background-color: #fef3c7 !important;
    border-color: #f59e0b !important;
    color: #92400e !important;
    transition: all 0.3s ease;
}

.clear-workspace:hover {
    background-color: #fde68a !important;
    border-color: #d97706 !important;
    color: #78350f !important;
}

.clear-workspace .dashicons {
    font-size: 16px;
}

.workspace-content {
    display: grid;
    gap: 2rem;
}

/* Avatar Principal */
.workspace-main-avatar {
    background: #fff;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.main-avatar-label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
    color: #f59e0b;
    font-weight: 600;
    font-size: 1.1rem;
}

.main-avatar-label .dashicons {
    color: #f59e0b;
}

.main-avatar-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
}

.main-avatar-image {
    width: 300px;
    height: 300px;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    object-fit: cover;
    border: 3px solid #fff;
    transition: transform 0.3s ease;
}

.main-avatar-image:hover {
    transform: scale(1.02);
}

.main-avatar-actions {
    display: flex;
    gap: 0.75rem;
    justify-content: center;
}

/* Créateur de Variations */
.variation-creator {
    margin-top: 1.5rem;
    background: #f8fafc;
    border: 1px dashed #cbd5e1;
    border-radius: 8px;
    padding: 1.5rem;
}

.variation-creator-header {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
    color: #64748b;
    font-weight: 500;
}

.variation-creator-header .dashicons {
    color: #10b981;
}

.variation-creator-form {
    display: flex;
    flex-direction: column;
}

.variation-creator-form .variation-form-inputs {
    display: flex;
    gap: 0.75rem;
    align-items: flex-end;
}

.variation-prompt-input {
    flex: 1;
    padding: 0.75rem;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 14px;
}

.variation-prompt-input:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    outline: none;
}

/* Conteneur de statut pour les variations */
.variation-status-container {
    margin-top: 1rem;
    min-height: 0;
    clear: both;
    display: block;
    width: 100%;
}

.variation-status-container .generation-error,
.variation-status-container .generation-success {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem;
    border-radius: 6px;
    font-size: 14px;
    line-height: 1.4;
    margin-top: 0.5rem;
}

.variation-status-container .generation-error {
    background: #fef2f2;
    color: #dc2626;
    border: 1px solid #fecaca;
}

.variation-status-container .generation-success {
    background: #f0fdf4;
    color: #16a34a;
    border: 1px solid #bbf7d0;
}

.variation-status-container .dashicons {
    font-size: 16px;
    flex-shrink: 0;
}

/* Grille des Variations */
.workspace-variations {
    background: #fff;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.variations-label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
    color: #6366f1;
    font-weight: 600;
    font-size: 1.1rem;
}

.variations-label .dashicons {
    color: #6366f1;
}

.variations-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 1.5rem;
}

.variation-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    overflow: hidden;
    transition: all 0.3s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.variation-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    border-color: #3b82f6;
}

.variation-image-container {
    position: relative;
    aspect-ratio: 1;
    overflow: hidden;
}

.variation-image-container img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.variation-info {
    padding: 1rem;
}

.variation-id {
    margin-bottom: 0.5rem;
}

.variation-id code {
    background: #f1f5f9;
    color: #475569;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 500;
}

.variation-prompt {
    color: #64748b;
    font-size: 0.875rem;
    line-height: 1.4;
    font-style: italic;
    display: flex;
    align-items: center;
    gap: 8px;
    justify-content: space-between;
}

.variation-prompt .prompt-text {
    flex: 1;
}

.copy-prompt-btn {
    background: transparent;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 2px 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    transition: all 0.2s ease;
    flex-shrink: 0;
    min-height: 20px;
}

.copy-prompt-btn:hover {
    background: #f3f4f6;
    border-color: #9ca3af;
}

.copy-prompt-btn .dashicons {
    font-size: 14px;
    color: #6b7280;
    width: 14px;
    height: 14px;
}

.copy-prompt-btn:hover .dashicons {
    color: #374151;
}

.current-avatar-container {
    text-align: center;
    padding: 2rem;
    background: #f9f9f9;
    border-radius: 4px;
}

.no-avatar-placeholder {
    color: #666;
}

.no-avatar-placeholder .dashicons {
    font-size: 4rem;
    width: 4rem;
    height: 4rem;
}

.avatar-generator {
    max-width: 600px;
}

.generation-loading {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    background: #f0f6fc;
    border-radius: 4px;
    margin-top: 1rem;
}

.avatar-variations {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.variation-item {
    text-align: center;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 1rem;
}

.variation-item img {
    width: 400px;
    height: 400px;
    max-width: 100%;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 1rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    transition: transform 0.2s ease;
}

.variation-item img:hover {
    transform: scale(1.01);
    box-shadow: 0 6px 16px rgba(0,0,0,0.15);
}

.variation-actions, .current-avatar-actions {
    display: flex;
    gap: 0.75rem;
    justify-content: center;
    margin-top: 1rem;
    padding: 1rem;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.current-avatar-actions {
    margin-top: 1.5rem;
}

.avatar-id-display {
    margin: 1rem 0 0.5rem 0;
    padding: 0.5rem;
    background-color: #f0f6fc;
    border: 1px solid #c3d9ff;
    border-radius: 4px;
    text-align: center;
    font-size: 14px;
}

.avatar-id-display code {
    background-color: #fff;
    color: #0073aa;
    padding: 2px 6px;
    border-radius: 3px;
    font-weight: bold;
    font-family: 'Courier New', monospace;
}

.main-avatar-prompt {
    margin-top: 1rem;
    padding: 1rem;
    background: #f8f9fa;
    border: 1px solid #e2e4e7;
    border-radius: 6px;
    text-align: left;
}

.main-avatar-prompt .prompt-header {
    display: flex;
    align-items: center;
    margin-bottom: 8px;
    font-weight: 600;
    color: #1e3a8a;
    font-size: 13px;
}

.main-avatar-prompt .prompt-header .dashicons {
    margin-right: 6px;
    font-size: 16px;
}

.main-avatar-prompt .prompt-content {
    font-size: 13px;
    line-height: 1.4;
    color: #374151;
    font-style: italic;
    word-wrap: break-word;
    max-height: 80px;
    overflow-y: auto;
    padding: 8px;
    background: white;
    border-radius: 4px;
    border: 1px solid #e2e4e7;
}

.variation-prompt-display {
    margin: 0.5rem 0;
    padding: 0.5rem;
    background-color: #f9f9f9;
    border-left: 3px solid #46b450;
    font-size: 13px;
    text-align: left;
}

.variation-prompt-display em {
    color: #555;
    font-style: italic;
}

.style-description {
    margin-top: 0.5rem;
    padding: 0.75rem;
    background-color: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    font-size: 13px;
    line-height: 1.4;
    color: #333;
    font-style: italic;
    display: none;
}

.style-description.show {
    display: block;
}

.final-prompt-display {
    margin-top: 1rem;
    padding: 0.5rem;
    background-color: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 3px;
    font-size: 11px;
    line-height: 1.3;
    color: #475569;
    max-width: 600px;
}

.final-prompt-display strong {
    color: #334155;
    font-weight: 600;
}

.final-prompt-display .prompt-text {
    font-family: 'Courier New', Monaco, monospace;
    background-color: #fff;
    padding: 0.25rem 0.5rem;
    border-radius: 2px;
    display: inline-block;
    margin-top: 0.25rem;
    border: 1px solid #e2e8f0;
    word-break: break-word;
    white-space: pre-wrap;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.section-header h2 {
    margin: 0;
    flex-grow: 1;
}

.section-actions {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.button-danger {
    background-color: #dc3545 !important;
    border-color: #dc3545 !important;
    color: #fff !important;
}

.button-danger:hover {
    background-color: #c82333 !important;
    border-color: #bd2130 !important;
}

.button-danger:disabled {
    background-color: #dc3545 !important;
    border-color: #dc3545 !important;
    opacity: 0.6;
}

.delete-all-spinner {
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-right: 5px;
}



/* Responsive Design */
@media (min-width: 768px) {
    .workspace-content {
        grid-template-columns: 1fr 2fr;
        align-items: start;
    }
    
    .workspace-main-avatar {
        position: sticky;
        top: 2rem;
    }
}

@media (max-width: 768px) {
    .pixnime-workspace {
        padding: 1rem;
    }
    
    .workspace-header {
        flex-direction: column;
        gap: 1rem;
        align-items: stretch;
    }
    
    .workspace-actions {
        justify-content: center;
    }
    
    .main-avatar-image {
        width: 250px;
        height: 250px;
    }
    
    .variation-creator-form {
        flex-direction: column;
        gap: 1rem;
    }
    
    .variations-grid {
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 1rem;
    }
}

@media (max-width: 480px) {
    .main-avatar-image {
        width: 200px;
        height: 200px;
    }
    
    .variations-grid {
        grid-template-columns: 1fr 1fr;
    }
    
    .workspace-header h2 {
        font-size: 1.25rem;
    }
}



/* Generate Section Header */
.generate-section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #e2e8f0;
}

.generate-section-header h2 {
    margin: 0;
    color: #1e293b;
    font-size: 1.5rem;
    font-weight: 600;
}

.generate-section-actions {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

#upload-to-media-library-btn {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background-color: #f0fdf4 !important;
    border-color: #16a34a !important;
    color: #15803d !important;
    transition: all 0.3s ease;
    font-size: 13px;
    padding: 6px 12px;
    height: auto;
}

#upload-to-media-library-btn:hover {
    background-color: #dcfce7 !important;
    border-color: #15803d !important;
    color: #166534 !important;
}

#upload-to-media-library-btn .dashicons {
    font-size: 16px;
}
</style> 
/**
 * Pixnime Pro - Main Admin JavaScript File
 * Fichier principal qui coordonne tous les modules JavaScript
 */

(function($) {
    'use strict';

    // Namespace principal pour Pixnime Pro
    window.PixnimePro = {
        
        /**
         * Configuration globale
         */
        config: {
            version: '1.0.84',
            debug: true
        },

        /**
         * État global de l'application
         */
        state: {
            initialized: false,
            modules: {
                debug: false,
                api: false,
                generation: false,
                workspace: false,
                settings: false,
                utils: false
            }
        },

        /**
         * Vérifier que tous les modules sont chargés
         */
        checkModules: function() {
            var modules = ['PixnimeDebug', 'PixnimeAPI', 'PixnimeGeneration', 'PixnimeWorkspace', 'PixnimeSettings', 'PixnimeUtils'];
            var loaded = [];
            var missing = [];
            
            modules.forEach(function(module) {
                if (window[module]) {
                    loaded.push(module);
                    // Marquer le module comme chargé
                    var moduleName = module.replace('Pixnime', '').toLowerCase();
                    if (PixnimePro.state.modules[moduleName] !== undefined) {
                        PixnimePro.state.modules[moduleName] = true;
                    }
                } else {
                    missing.push(module);
                }
            });
            
            console.log('Modules Pixnime Pro chargés:', loaded);
            if (missing.length > 0) {
                console.warn('Modules Pixnime Pro manquants:', missing);
            }
            
            return missing.length === 0;
        },

        /**
         * Initialiser l'application
         */
        init: function() {
            if (this.state.initialized) {
                console.warn('Pixnime Pro déjà initialisé');
                return;
            }
            
            console.log('=== INITIALISATION PIXNIME PRO ===');
            console.log('Version:', this.config.version);
            
            // Vérifier que pixnimeProL10n est disponible
            if (typeof pixnimeProL10n === 'undefined') {
                console.error('pixnimeProL10n non défini - les fonctions AJAX ne fonctionneront pas');
                return;
            }
            
            // Vérifier que tous les modules sont chargés
            var allModulesLoaded = this.checkModules();
            
            if (!allModulesLoaded) {
                console.error('Impossible d\'initialiser - certains modules sont manquants');
                return;
            }
            
            // L'initialisation des modules individuels se fait dans leurs propres fichiers
            console.log('Pixnime Pro initialisé avec succès');
            this.state.initialized = true;
            
            // Exposer des fonctions utiles globalement
            this.exposeGlobalFunctions();
            
            console.log('=====================================');
        },

        /**
         * Exposer des fonctions utiles globalement
         */
        exposeGlobalFunctions: function() {
            // Fonctions de debug accessibles depuis la console
            window.pixnimeDiagnostic = function() {
                if (window.PixnimeDebug) {
                    PixnimeDebug.diagnosticButtonState();
                    PixnimeDebug.diagnosticVariationButton();
                    PixnimeDebug.diagnosticGeneral();
                }
            };
            
            // Fonction pour vérifier l'état de l'application
            window.pixnimeStatus = function() {
                console.log('=== ÉTAT PIXNIME PRO ===');
                console.log('Version:', PixnimePro.config.version);
                console.log('Initialisé:', PixnimePro.state.initialized);
                console.log('Modules:', PixnimePro.state.modules);
                console.log('API Base URL:', window.pixnimeApiBase || 'Non définie');
                console.log('=======================');
            };
            
            // Fonction pour forcer le rechargement des modules
            window.pixnimeReload = function() {
                location.reload();
            };
            
            console.log('💡 Fonctions disponibles dans la console:');
            console.log('   - pixnimeDiagnostic() : Diagnostic complet');
            console.log('   - pixnimeStatus() : État de l\'application');
            console.log('   - pixnimeReload() : Recharger la page');
        },

        /**
         * Gestionnaire d'erreurs globales
         */
        handleError: function(error, context) {
            console.error('Erreur Pixnime Pro:', error);
            if (context) {
                console.error('Contexte:', context);
            }
            
            // En mode debug, afficher plus d'informations
            if (this.config.debug) {
                console.trace();
            }
        },

        /**
         * Utilitaire pour logger avec un préfixe
         */
        log: function(message, data) {
            if (this.config.debug) {
                console.log('[Pixnime Pro]', message, data || '');
            }
        }
    };

    // Initialisation au chargement du DOM
    $(document).ready(function() {
        // Attendre un court délai pour s'assurer que tous les modules sont chargés
        setTimeout(function() {
            PixnimePro.init();
        }, 100);

        // Gestion du bouton copier le prompt dans les variations
        $(document).on('click', '.copy-prompt-btn', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var prompt = $btn.data('prompt');
            if (!prompt) return;
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(prompt);
            } else {
                // Fallback pour anciens navigateurs
                var textArea = document.createElement('textarea');
                textArea.value = prompt;
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                } catch (err) {}
                document.body.removeChild(textArea);
            }
        });

        $('#pixnime-btn-free-credits').on('click', function(e) {
            e.preventDefault();
            var lang = (navigator.language || navigator.userLanguage || '').toLowerCase();
            var msg = (lang.startsWith('fr'))
                ? "Créez votre API KEY dans votre compte Pixnime.com pour recevoir 100 crédits supplémentaires"
                : "Create your API KEY in your Pixnime.com account to receive 100 extra credits";
            alert(msg);
        });
    });

    // Exposer PixnimePro globalement
    window.PixnimePro = PixnimePro;

})(jQuery); 
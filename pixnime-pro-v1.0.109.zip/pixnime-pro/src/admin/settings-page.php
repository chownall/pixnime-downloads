<?php
/**
 * Settings page for Pixnime Pro
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Debug - Afficher les données POST
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('Pixnime Settings Debug - POST data: ' . print_r($_POST, true));
}

// Utiliser le système WordPress standard pour les settings
if (isset($_GET['settings-updated'])) {
    add_settings_error('pixnime_pro_settings', 'settings_updated', esc_html__('Settings saved successfully!', 'pixnime-pro'), 'updated');
}

// Afficher les messages d'erreur/succès
settings_errors('pixnime_pro_settings');

// Get current settings
$settings = get_option('pixnime_pro_settings', array());
$api_key = $settings['api_key'] ?? '';
$openai_key = $settings['openai_key'] ?? '';

// Debug - Afficher les paramètres de watermark
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('Pixnime Settings Debug - Watermark settings: ' . print_r(array(
        'watermark_position' => $settings['watermark_position'] ?? 'not set',
        'watermark_image_id' => $settings['watermark_image_id'] ?? 'not set',
        'watermark_image_url' => $settings['watermark_image_url'] ?? 'not set',
        'watermark_opacity' => $settings['watermark_opacity'] ?? 'not set'
    ), true));
}
?>

<div class="wrap">
    <h1><?php esc_html_e('Pixnime Pro Settings', 'pixnime-pro'); ?></h1>
    
    <form method="post" action="options.php">
        <?php settings_fields('pixnime_pro_settings'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="api_key"><?php esc_html_e('Pixnime API Key', 'pixnime-pro'); ?></label>
                </th>
                <td>
                    <div class="key-field-container" style="display: flex; align-items: flex-start; gap: 10px;">
                        <input type="text" id="api_key" name="pixnime_pro_settings[api_key]" value="<?php echo esc_attr($api_key); ?>" class="regular-text" style="width:300px;" />
                        <button type="button" id="verify-api-key" class="button"><?php esc_html_e('Verify key', 'pixnime-pro'); ?></button>
                        <button type="button" id="clear-pixnime-key" class="button button-secondary clear-key-btn" style="background-color: #dc3232; color: white; border-color: #dc3232;" title="<?php esc_attr_e('Delete Pixnime key (Credits Mode)', 'pixnime-pro'); ?>">
                            🗑️ <?php esc_html_e('Delete', 'pixnime-pro'); ?>
                        </button>
                    </div>
                    <div id="pixnime-api-verify-result" style="margin-top:8px;"></div>
                    <p class="description">
                        <strong><?php esc_html_e('Credits Mode:', 'pixnime-pro'); ?></strong> <?php esc_html_e('Enter your Pixnime API key. Get one at', 'pixnime-pro'); ?>
                        <a href="https://pixnime.com" target="_blank">pixnime.com</a>
                        <br><em><?php esc_html_e('Generation via Pixnime server → OpenAI (50 credits per image)', 'pixnime-pro'); ?></em>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="openai_key"><?php esc_html_e('OpenAI API Key', 'pixnime-pro'); ?></label>
                </th>
                <td>
                    <div class="key-field-container" style="display: flex; align-items: flex-start; gap: 10px;">
                        <input type="text" id="openai_key" name="pixnime_pro_settings[openai_key]" value="<?php echo esc_attr($openai_key); ?>" class="regular-text" style="width:300px;" />
                        <button type="button" id="clear-openai-key" class="button button-secondary clear-key-btn" style="background-color: #dc3232; color: white; border-color: #dc3232;" title="<?php esc_attr_e('Delete OpenAI key (VIP Pro Mode)', 'pixnime-pro'); ?>">
                            🗑️ <?php esc_html_e('Delete', 'pixnime-pro'); ?>
                        </button>
                    </div>
                    <p class="description">
                        <strong><?php esc_html_e('VIP Pro Mode:', 'pixnime-pro'); ?></strong> <?php esc_html_e('VIP Pro subscribers only - unlimited generations', 'pixnime-pro'); ?>
                        <br>
                        <?php esc_html_e('Enter your OpenAI API key for advanced AI avatar generation.', 'pixnime-pro'); ?>
                        <br><em><?php esc_html_e('Direct generation via your OpenAI key (no credits deducted)', 'pixnime-pro'); ?></em>
                        <br><strong><?php esc_html_e('Your key is NOT stored on our servers, it transits encrypted (https) to query the Open AI API', 'pixnime-pro'); ?></strong>
                    </p>
                </td>
            </tr>
        </table>
        
        <!-- Watermark/Logo Settings Section -->
        <h2><?php esc_html_e('Watermark/Logo Settings', 'pixnime-pro'); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="watermark_position"><?php esc_html_e('Watermark/Logo Position', 'pixnime-pro'); ?></label>
                </th>
                <td>
                    <select id="watermark_position" name="pixnime_pro_settings[watermark_position]" class="regular-text">
                        <option value="center" <?php selected($settings['watermark_position'] ?? 'center', 'center'); ?>><?php esc_html_e('Center', 'pixnime-pro'); ?></option>
                        <option value="center-bottom" <?php selected($settings['watermark_position'] ?? 'center', 'center-bottom'); ?>><?php esc_html_e('Center Bottom', 'pixnime-pro'); ?></option>
                        <option value="center-top" <?php selected($settings['watermark_position'] ?? 'center', 'center-top'); ?>><?php esc_html_e('Center Top', 'pixnime-pro'); ?></option>
                        <option value="bottom-right" <?php selected($settings['watermark_position'] ?? 'center', 'bottom-right'); ?>><?php esc_html_e('Bottom Right', 'pixnime-pro'); ?></option>
                        <option value="bottom-left" <?php selected($settings['watermark_position'] ?? 'center', 'bottom-left'); ?>><?php esc_html_e('Bottom Left', 'pixnime-pro'); ?></option>
                        <option value="top-right" <?php selected($settings['watermark_position'] ?? 'center', 'top-right'); ?>><?php esc_html_e('Top Right', 'pixnime-pro'); ?></option>
                        <option value="top-left" <?php selected($settings['watermark_position'] ?? 'center', 'top-left'); ?>><?php esc_html_e('Top Left', 'pixnime-pro'); ?></option>
                        <option value="none" <?php selected($settings['watermark_position'] ?? 'center', 'none'); ?>><?php esc_html_e('No watermark or logo', 'pixnime-pro'); ?></option>
                    </select>
                    <p class="description">
                        <?php esc_html_e('Select the position for the watermark or logo on generated images.', 'pixnime-pro'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="watermark_image"><?php esc_html_e('Watermark/Logo Image', 'pixnime-pro'); ?></label>
                </th>
                <td>
                    <div class="watermark-upload-container">
                        <input type="hidden" id="watermark_image_id" name="pixnime_pro_settings[watermark_image_id]" value="<?php echo esc_attr($settings['watermark_image_id'] ?? ''); ?>" />
                        <input type="text" id="watermark_image_url" name="pixnime_pro_settings[watermark_image_url]" value="<?php echo esc_attr($settings['watermark_image_url'] ?? ''); ?>" class="regular-text" placeholder="<?php esc_attr_e('Select an image for watermark/logo', 'pixnime-pro'); ?>" readonly />
                        <button type="button" id="upload-watermark-btn" class="button"><?php esc_html_e('Choose Image', 'pixnime-pro'); ?></button>
                        <button type="button" id="remove-watermark-btn" class="button button-secondary" style="display: <?php echo !empty($settings['watermark_image_url']) ? 'inline-block' : 'none'; ?>;"><?php esc_html_e('Remove', 'pixnime-pro'); ?></button>
                    </div>
                    <div id="watermark-preview" style="margin-top: 10px;">
                        <?php if (!empty($settings['watermark_image_url'])): ?>
                            <img src="<?php echo esc_url($settings['watermark_image_url']); ?>" alt="Watermark Preview" style="max-width: 100px; max-height: 100px; border: 1px solid #ddd; border-radius: 4px;" />
                        <?php endif; ?>
                    </div>
                    <p class="description">
                        <?php esc_html_e('Upload or select an image to use as watermark/logo.', 'pixnime-pro'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="watermark_opacity"><?php esc_html_e('Watermark Opacity', 'pixnime-pro'); ?></label>
                </th>
                <td>
                    <input type="range" id="watermark_opacity" name="pixnime_pro_settings[watermark_opacity]" min="10" max="100" value="<?php echo esc_attr($settings['watermark_opacity'] ?? '50'); ?>" class="regular-text" />
                    <span id="opacity-value"><?php echo esc_html($settings['watermark_opacity'] ?? '50'); ?>%</span>
                    <p class="description">
                        <?php esc_html_e('Adjust the transparency of the watermark (10% = very transparent, 100% = fully opaque).', 'pixnime-pro'); ?>
                    </p>
                </td>
            </tr>
        </table>
        
        <!-- Watermark Preview Section -->
        <div id="watermark-preview-section" style="margin: 20px 0; padding: 20px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
            <h3><?php esc_html_e('Watermark Preview', 'pixnime-pro'); ?></h3>
            <div id="preview-container" style="position: relative; width: 300px; height: 300px; background: #fff; border: 2px solid #ddd; border-radius: 8px; overflow: hidden;">
                <div id="preview-image" style="width: 100%; height: 100%; background: linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%); background-size: 20px 20px; background-position: 0 0, 0 10px, 10px -10px, -10px 0px; display: flex; align-items: center; justify-content: center;">
                    <span style="color: #999; font-size: 14px;"><?php esc_html_e('Sample Image', 'pixnime-pro'); ?></span>
                </div>
                <div id="preview-watermark" style="position: absolute; display: none;">
                    <img id="preview-watermark-img" src="" alt="Watermark Preview" style="max-width: 50px; max-height: 50px; opacity: 0.5;" />
                </div>
            </div>
            <p class="description" style="margin-top: 10px;">
                <?php esc_html_e('This preview shows how your watermark will appear on generated images. Save settings to apply changes.', 'pixnime-pro'); ?>
            </p>
        </div>
        
        <div style="margin: 20px 0; padding: 15px; background: #e7f3ff; border-left: 4px solid #0073aa; border-radius: 4px;">
            <h3 style="margin-top: 0; color: #0073aa;">🔄 <?php esc_html_e('Automatic saving enabled', 'pixnime-pro'); ?></h3>
            <p style="margin-bottom: 0;">
                <strong><?php esc_html_e('All generated images are automatically saved to the WordPress media library.', 'pixnime-pro'); ?></strong>
            </p>
        </div>
        
        <h2><?php esc_html_e('Usage Information', 'pixnime-pro'); ?></h2>
        <div class="usage-info">
            <h3><?php esc_html_e('API Integration', 'pixnime-pro'); ?></h3>
            <p><?php esc_html_e('This plugin integrates with the Pixnime AI service and OpenAI for advanced avatar generation. Make sure to:', 'pixnime-pro'); ?></p>
            <ul>
                <li><?php esc_html_e('Get your Pixnime API key from pixnime.com', 'pixnime-pro'); ?></li>
                <li><?php esc_html_e('Get your OpenAI API key for VIP Pro features', 'pixnime-pro'); ?></li>
                <li><?php esc_html_e('Configure your preferred default settings', 'pixnime-pro'); ?></li>
                <li><?php esc_html_e('Test avatar generation in the main admin page', 'pixnime-pro'); ?></li>
            </ul>
        </div>
        
        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Settings', 'pixnime-pro'); ?>" />
        </p>
    </form>
</div>

<style>
.usage-info {
    background: #f9f9f9;
    padding: 1.5rem;
    border-radius: 4px;
    margin-top: 2rem;
}

.usage-info h3 {
    margin-top: 0;
    color: #23282d;
}

.usage-info ul {
    margin-left: 1.5rem;
}

.usage-info code {
    background: #fff;
    padding: 0.2rem 0.4rem;
    border: 1px solid #ddd;
    border-radius: 2px;
    font-family: monospace;
}

.usage-info li {
    margin-bottom: 0.5rem;
}

/* Style pour les boutons de suppression */
.clear-key-btn {
    transition: all 0.3s ease;
}

.clear-key-btn:hover {
    background-color: #a00 !important;
    transform: scale(1.05);
}

/* Animation pour les changements */
.key-field-container {
    transition: all 0.3s ease;
}

.key-field-container.removing {
    opacity: 0.5;
    transform: scale(0.98);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // 🗑️ Bouton supprimer clé Pixnime
    document.getElementById('clear-pixnime-key').addEventListener('click', function() {
        if (confirm('Êtes-vous sûr de vouloir supprimer votre clé API Pixnime ?\n\nCela vous fera basculer en Mode VIP Pro si vous avez une clé OpenAI, sinon aucune génération ne sera possible.')) {
            const pixnimeField = document.getElementById('api_key');
            const container = pixnimeField.closest('.key-field-container');
            
            // Animation de suppression
            if (container) {
                container.classList.add('removing');
            }
            
            setTimeout(function() {
                pixnimeField.value = '';
                
                // Sauvegarder automatiquement
                saveKeySettings('pixnime');
                
                if (container) {
                    container.classList.remove('removing');
                }
                
                // Message de confirmation
                showNotification('Clé API Pixnime supprimée avec succès', 'success');
            }, 300);
        }
    });
    
    // 🗑️ Bouton supprimer clé OpenAI
    document.getElementById('clear-openai-key').addEventListener('click', function() {
        if (confirm('Êtes-vous sûr de vouloir supprimer votre clé OpenAI ?\n\nCela vous fera basculer en Mode Crédits si vous avez une clé Pixnime, sinon aucune génération ne sera possible.')) {
            const openaiField = document.getElementById('openai_key');
            const container = openaiField.closest('.key-field-container');
            
            // Animation de suppression
            if (container) {
                container.classList.add('removing');
            }
            
            setTimeout(function() {
                openaiField.value = '';
                
                // Sauvegarder automatiquement
                saveKeySettings('openai');
                
                if (container) {
                    container.classList.remove('removing');
                }
                
                // Message de confirmation
                showNotification('Clé OpenAI supprimée avec succès', 'success');
            }, 300);
        }
    });
    
    // 💾 Sauvegarder automatiquement les paramètres
    function saveKeySettings(keyType) {
        const formData = new FormData();
        formData.append('action', 'pixnime_clear_key');
        formData.append('key_type', keyType);
        formData.append('nonce', '<?php echo wp_create_nonce("pixnime_clear_key"); ?>');
        
        if (keyType === 'pixnime') {
            formData.append('pixnime_key', '');
            formData.append('openai_key', document.getElementById('openai_key').value);
        } else {
            formData.append('pixnime_key', document.getElementById('api_key').value);
            formData.append('openai_key', '');
        }
        
        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Clé supprimée avec succès:', keyType);
            } else {
                console.error('Erreur lors de la suppression:', data.data);
            }
        })
        .catch(error => {
            console.error('Erreur AJAX:', error);
        });
    }
    
    // 📢 Afficher les notifications
    function showNotification(message, type = 'info') {
        const notice = document.createElement('div');
        notice.className = `notice notice-${type} is-dismissible`;
        notice.innerHTML = `<p>${message}</p>`;
        
        const wrap = document.querySelector('.wrap');
        wrap.insertBefore(notice, wrap.firstChild.nextSibling);
        
        // Auto-dismiss après 3 secondes
        setTimeout(function() {
            notice.style.opacity = '0';
            notice.style.transition = 'opacity 0.3s ease';
            setTimeout(function() {
                if (notice.parentNode) {
                    notice.parentNode.removeChild(notice);
                }
            }, 300);
        }, 3000);
    }
    
    // Watermark/Logo Management
    const uploadWatermarkBtn = document.getElementById('upload-watermark-btn');
    const removeWatermarkBtn = document.getElementById('remove-watermark-btn');
    const watermarkImageId = document.getElementById('watermark_image_id');
    const watermarkImageUrl = document.getElementById('watermark_image_url');
    const watermarkPreview = document.getElementById('watermark-preview');
    const watermarkPosition = document.getElementById('watermark_position');
    const watermarkOpacity = document.getElementById('watermark_opacity');
    const opacityValue = document.getElementById('opacity-value');
    const previewWatermark = document.getElementById('preview-watermark');
    const previewWatermarkImg = document.getElementById('preview-watermark-img');
    
    // Upload Watermark Button
    if (uploadWatermarkBtn) {
        uploadWatermarkBtn.addEventListener('click', function() {
            // Vérifier si wp.media est disponible
            if (typeof wp !== 'undefined' && wp.media) {
                const mediaUploader = wp.media({
                    title: 'Select Watermark/Logo Image',
                    button: {
                        text: 'Use this image'
                    },
                    multiple: false,
                    library: {
                        type: 'image'
                    }
                });
                
                mediaUploader.on('select', function() {
                    const attachment = mediaUploader.state().get('selection').first().toJSON();
                    
                    // Mettre à jour les champs
                    watermarkImageId.value = attachment.id;
                    watermarkImageUrl.value = attachment.url;
                    
                    // Afficher la prévisualisation
                    watermarkPreview.innerHTML = `<img src="${attachment.url}" alt="Watermark Preview" style="max-width: 100px; max-height: 100px; border: 1px solid #ddd; border-radius: 4px;" />`;
                    
                    // Afficher le bouton de suppression
                    removeWatermarkBtn.style.display = 'inline-block';
                    
                    // Mettre à jour la prévisualisation en temps réel
                    updateWatermarkPreview();
                });
                
                mediaUploader.open();
            } else {
                alert('WordPress Media Library is not available. Please refresh the page.');
            }
        });
    }
    
    // Remove Watermark Button
    if (removeWatermarkBtn) {
        removeWatermarkBtn.addEventListener('click', function() {
            watermarkImageId.value = '';
            watermarkImageUrl.value = '';
            watermarkPreview.innerHTML = '';
            removeWatermarkBtn.style.display = 'none';
            updateWatermarkPreview();
        });
    }
    
    // Update opacity value display
    if (watermarkOpacity) {
        watermarkOpacity.addEventListener('input', function() {
            opacityValue.textContent = this.value + '%';
            updateWatermarkPreview();
        });
    }
    
    // Update watermark position
    if (watermarkPosition) {
        watermarkPosition.addEventListener('change', updateWatermarkPreview);
    }
    
    // Update watermark preview
    function updateWatermarkPreview() {
        if (!previewWatermark || !previewWatermarkImg) return;
        
        const imageUrl = watermarkImageUrl.value;
        const position = watermarkPosition.value;
        const opacity = watermarkOpacity.value / 100;
        
        if (imageUrl && position !== 'none') {
            previewWatermarkImg.src = imageUrl;
            previewWatermarkImg.style.opacity = opacity;
            previewWatermark.style.display = 'block';
            
            // Position the watermark
            switch (position) {
                case 'center':
                    previewWatermark.style.top = '50%';
                    previewWatermark.style.left = '50%';
                    previewWatermark.style.transform = 'translate(-50%, -50%)';
                    break;
                case 'center-bottom':
                    previewWatermark.style.bottom = '10px';
                    previewWatermark.style.left = '50%';
                    previewWatermark.style.top = 'auto';
                    previewWatermark.style.transform = 'translate(-50%, 0)';
                    break;
                case 'center-top':
                    previewWatermark.style.top = '10px';
                    previewWatermark.style.left = '50%';
                    previewWatermark.style.bottom = 'auto';
                    previewWatermark.style.transform = 'translate(-50%, 0)';
                    break;
                case 'bottom-right':
                    previewWatermark.style.bottom = '10px';
                    previewWatermark.style.right = '10px';
                    previewWatermark.style.top = 'auto';
                    previewWatermark.style.left = 'auto';
                    previewWatermark.style.transform = 'none';
                    break;
                case 'bottom-left':
                    previewWatermark.style.bottom = '10px';
                    previewWatermark.style.left = '10px';
                    previewWatermark.style.top = 'auto';
                    previewWatermark.style.right = 'auto';
                    previewWatermark.style.transform = 'none';
                    break;
                case 'top-right':
                    previewWatermark.style.top = '10px';
                    previewWatermark.style.right = '10px';
                    previewWatermark.style.bottom = 'auto';
                    previewWatermark.style.left = 'auto';
                    previewWatermark.style.transform = 'none';
                    break;
                case 'top-left':
                    previewWatermark.style.top = '10px';
                    previewWatermark.style.left = '10px';
                    previewWatermark.style.bottom = 'auto';
                    previewWatermark.style.right = 'auto';
                    previewWatermark.style.transform = 'none';
                    break;
            }
        } else {
            previewWatermark.style.display = 'none';
        }
    }
    
    // Initialize watermark preview
    updateWatermarkPreview();
    
    // Debug - Afficher les valeurs actuelles
    console.log('Watermark settings loaded:', {
        position: watermarkPosition ? watermarkPosition.value : 'not found',
        imageUrl: watermarkImageUrl ? watermarkImageUrl.value : 'not found',
        imageId: watermarkImageId ? watermarkImageId.value : 'not found',
        opacity: watermarkOpacity ? watermarkOpacity.value : 'not found'
    });
    
    // S'assurer que la prévisualisation se charge après un délai
    setTimeout(function() {
        updateWatermarkPreview();
        console.log('Watermark preview updated after delay');
    }, 500);
});
</script> 
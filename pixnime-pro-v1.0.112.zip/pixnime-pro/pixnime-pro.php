<?php
/*
Plugin Name: Pixnime Pro - AI Character and Illustrations Consistency Generator
Plugin URI: https://pixnime.com/wordpress
Description: Generate AI avatars or illustrations and ensure visual consistency throughout your creations. Start with a prompt, choose a visual style (from 3D cartoon to 4K realistic), and inject adapted prompts to refine poses and expressions. Save time by reusing existing assets, with all visuals stored directly in your WordPress Media Library.
Version: 1.0.112
Author: Pixnime
Author URI: https://pixnime.com
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: pixnime-pro
Domain Path: /languages
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants only if not already defined
if (!defined('PIXNIME_PRO_VERSION')) {
    define('PIXNIME_PRO_VERSION', '1.0.90');
}
if (!defined('PIXNIME_PRO_PLUGIN_DIR')) {
    define('PIXNIME_PRO_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('PIXNIME_PRO_PLUGIN_URL')) {
    define('PIXNIME_PRO_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Charger les classes nécessaires
require_once PIXNIME_PRO_PLUGIN_DIR . 'includes/class-pixnime-pro.php';
require_once PIXNIME_PRO_PLUGIN_DIR . 'includes/class-pixnime-pro-admin.php';
require_once PIXNIME_PRO_PLUGIN_DIR . 'includes/class-pixnime-pro-api.php';
require_once PIXNIME_PRO_PLUGIN_DIR . 'includes/class-pixnime-pro-secure-api.php';

// Initialiser la classe principale pour activer les hooks AJAX
$pixnime_pro = new Pixnime_Pro();
$pixnime_pro->init();

 
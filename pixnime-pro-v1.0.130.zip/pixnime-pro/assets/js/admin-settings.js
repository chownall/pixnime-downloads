/**
 * Pixnime Pro - Settings Functions
 * Fonctions pour la gestion des paramètres et watermark
 */

(function($) {
    'use strict';

    // Namespace pour les fonctions de paramètres
    window.PixnimeSettings = {
        
        /**
         * Gestion de l'upload d'image watermark
         */
        handleWatermarkImageUpload: function() {
            var frame;
            
            // Si le frame existe déjà, l'ouvrir
            if (frame) {
                frame.open();
                return;
            }
            
            // Créer un nouveau frame
            frame = wp.media({
                title: 'Sélectionner une image pour le watermark',
                button: {
                    text: 'Utiliser cette image'
                },
                multiple: false,
                library: {
                    type: 'image'
                }
            });
            
            // Quand une image est sélectionnée
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                
                // Mettre à jour les champs cachés
                $('#watermark_image_id').val(attachment.id);
                $('#watermark_image_url').val(attachment.url);
                
                // Mettre à jour l'aperçu
                PixnimeSettings.updateWatermarkPreview(attachment.url);
            });
            
            // Ouvrir le frame
            frame.open();
        },

        /**
         * Supprimer l'image watermark
         */
        removeWatermarkImage: function() {
            if (!confirm('Supprimer l\'image du watermark ?')) {
                return;
            }
            
            // Vider les champs
            $('#watermark_image_id').val('');
            $('#watermark_image_url').val('');
            
            // Supprimer l'aperçu
            $('.watermark-preview').remove();
            
            // Masquer le bouton de suppression
            $('#watermark_image_remove').hide();
        },

        /**
         * Mettre à jour l'aperçu du watermark
         */
        updateWatermarkPreview: function(imageUrl) {
            var $container = $('.watermark-image-container');
            var $preview = $container.find('.watermark-preview');
            
            if ($preview.length === 0) {
                $preview = $('<div class="watermark-preview"></div>');
                $container.find('#watermark_image_upload').before($preview);
            }
            
            $preview.html('<img src="' + imageUrl + '" style="max-width: 100px; max-height: 100px; border: 1px solid #ddd; margin: 5px 0;" />');
            
            // Afficher le bouton de suppression
            var $removeBtn = $('#watermark_image_remove');
            if ($removeBtn.length === 0) {
                $removeBtn = $('<button type="button" class="button" id="watermark_image_remove">Supprimer</button>');
                $container.find('#watermark_image_upload').after(' ', $removeBtn);
            }
            $removeBtn.show();
        },

        /**
         * Mettre à jour l'affichage de l'opacité
         */
        updateOpacityDisplay: function() {
            var value = $('#watermark_opacity').val();
            $('#watermark_opacity_value').text(value + '%');
        },

        /**
         * Tester le watermark
         */
        testWatermark: function() {
            var testImageId = $('#watermark_test_image').val();
            var $btn = $('#watermark_test');
            var $result = $('#watermark_test_result');
            
            if (!testImageId) {
                alert('Veuillez sélectionner une image de test');
                return;
            }
            
            var originalText = $btn.text();
            $btn.prop('disabled', true).text('Test en cours...');
            $result.html('<p>Test du watermark en cours...</p>');
            
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                data: {
                    action: 'pixnime_test_watermark',
                    nonce: pixnimeProL10n.nonce,
                    test_image_id: testImageId
                },
                success: function(response) {
                    console.log('Test watermark response:', response);
                    
                    if (response.success) {
                        $result.html(
                            '<div class="notice notice-success"><p><strong>Test réussi !</strong></p>' +
                            '<p>Watermark appliqué avec succès:</p>' +
                            '<img src="' + response.data.test_image_url + '" style="max-width: 200px; border: 1px solid #ddd; margin: 10px 0;" />' +
                            '</div>'
                        );
                    } else {
                        $result.html('<div class="notice notice-error"><p><strong>Erreur:</strong> ' + (response.data || 'Erreur inconnue') + '</p></div>');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Erreur test watermark:', error);
                    $result.html('<div class="notice notice-error"><p><strong>Erreur réseau:</strong> ' + error + '</p></div>');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Gestion de l'upload vers la bibliothèque des médias
         */
        handleMediaLibraryUpload: function() {
            var mediaUploader;
            
            // Si l'uploader existe déjà, l'ouvrir
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            
            // Créer un nouvel uploader
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Sélectionner une image',
                button: {
                    text: 'Ajouter au workspace'
                },
                multiple: false
            });
            
            // Quand une image est sélectionnée
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                console.log('Image sélectionnée:', attachment);
                
                // Vérifier si le workspace est vide
                var hasCurrentAvatar = $('.main-avatar-image').length > 0;
                var hasVariations = $('.variation-card').length > 0;
                
                if (hasCurrentAvatar || hasVariations) {
                    alert('Please empty your workspace first');
                    return;
                }
                
                // Générer un avatar_id unique pour cette image
                var avatarId = 'library_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                
                // Appeler l'action AJAX pour ajouter l'image au workspace
                $.ajax({
                    url: pixnimeProL10n.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'pixnime_add_image_to_workspace',
                        nonce: pixnimeProL10n.nonce,
                        image_url: attachment.url,
                        attachment_id: attachment.id,
                        avatar_id: avatarId,
                        filename: attachment.filename || 'library_image'
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            alert('Erreur lors de l\'ajout de l\'image: ' + (response.data || 'Erreur inconnue'));
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Erreur réseau: ' + error);
                    }
                });
            });
            
            // Ouvrir l'uploader
            mediaUploader.open();
        },

        /**
         * Initialisation des paramètres
         */
        init: function() {
            console.log('Pixnime Pro Settings JS loaded');
            
            // Vérifier la disponibilité de wp.media
            if (typeof wp !== 'undefined' && wp.media) {
                console.log('wp.media disponible');
            } else {
                console.warn('wp.media non disponible - les fonctions d\'upload ne fonctionneront pas');
            }
        }
    };

    // Gestionnaires d'événements pour les paramètres
    $(document).ready(function() {
        PixnimeSettings.init();
        
        // Upload d'image watermark
        $('#watermark_image_upload').on('click', function(e) {
            e.preventDefault();
            
            if (typeof wp === 'undefined' || !wp.media) {
                alert('La bibliothèque des médias WordPress n\'est pas disponible');
                return;
            }
            
            PixnimeSettings.handleWatermarkImageUpload();
        });
        
        // Suppression de l'image watermark
        $(document).on('click', '#watermark_image_remove', function(e) {
            e.preventDefault();
            PixnimeSettings.removeWatermarkImage();
        });
        
        // Mise à jour de l'opacité du watermark
        $('#watermark_opacity').on('input', function() {
            PixnimeSettings.updateOpacityDisplay();
        });
        
        // Test du watermark
        $('#watermark_test').on('click', function(e) {
            e.preventDefault();
            PixnimeSettings.testWatermark();
        });
        
        // Upload vers la bibliothèque des médias
        $('#upload-to-media-library-btn').on('click.settings', function(e) {
            e.preventDefault();
            
            // Vérifier si le workspace est vide AVANT d'ouvrir la media library
            var hasCurrentAvatar = $('.main-avatar-image').length > 0;
            var hasVariations = $('.variation-card').length > 0;
            if (hasCurrentAvatar || hasVariations) {
                alert('Please empty your workspace first');
                return;
            }

            if (typeof wp === 'undefined' || !wp.media) {
                alert('La bibliothèque des médias WordPress n\'est pas disponible');
                return;
            }
            
            PixnimeSettings.handleMediaLibraryUpload();
        });
    });

    // Fonction globale pour ouvrir la Media Library sans vérification supplémentaire
    window.openPixnimeMediaLibrary = function() {
        if (typeof wp === 'undefined' || !wp.media) {
            alert('La bibliothèque des médias WordPress n\'est pas disponible');
            return;
        }
        PixnimeSettings.handleMediaLibraryUpload();
    };

})(jQuery); 
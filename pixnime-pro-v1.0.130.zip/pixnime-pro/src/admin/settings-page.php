<?php
/**
 * Settings page for Pixnime Pro
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Note: POST data is handled securely through WordPress Settings API
// which includes proper nonce validation and sanitization

// Utiliser le système WordPress standard pour les settings
if (isset($_GET['settings-updated']) && sanitize_text_field($_GET['settings-updated']) == 'true') {
    add_settings_error('pixnime_pro_settings', 'settings_updated', esc_html__('Settings saved successfully!', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'), 'updated');
}

// Afficher les messages d'erreur/succès
settings_errors('pixnime_pro_settings');

// Get current settings
$settings = get_option('pixnime_pro_settings', array());
$api_key = $settings['api_key'] ?? '';
$openai_key = $settings['openai_key'] ?? '';

// Debug - Afficher les paramètres de watermark
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('Pixnime Settings Debug - Watermark settings: ' . print_r(array(
        'watermark_position' => $settings['watermark_position'] ?? 'not set',
        'watermark_image_id' => $settings['watermark_image_id'] ?? 'not set',
        'watermark_image_url' => $settings['watermark_image_url'] ?? 'not set',
        'watermark_opacity' => $settings['watermark_opacity'] ?? 'not set'
    ), true));
}
?>

<div class="wrap">
    <h1><?php esc_html_e('Pixnime Pro Settings', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h1>
    
    <form method="post" action="options.php">
        <?php settings_fields('pixnime_pro_settings'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="api_key"><?php esc_html_e('Pixnime API Key', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                </th>
                <td>
                    <div class="key-field-container" style="display: flex; align-items: flex-start; gap: 10px;">
                        <input type="text" id="api_key" name="pixnime_pro_settings[api_key]" value="<?php echo esc_attr($api_key); ?>" class="regular-text" style="width:300px;" />
                        <button type="button" id="verify-api-key" class="button"><?php esc_html_e('Verify key', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></button>
                        <button type="button" id="clear-pixnime-key" class="button button-secondary clear-key-btn" style="background-color: #dc3232; color: white; border-color: #dc3232;" title="<?php esc_attr_e('Delete Pixnime key (Credits Mode)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                            🗑️ <?php esc_html_e('Delete', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        </button>
                    </div>
                    <div id="pixnime-api-verify-result" style="margin-top:8px;"></div>
                    <p class="description">
                        <strong><?php esc_html_e('Credits Mode:', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></strong> <?php esc_html_e('Enter your Pixnime API key. Get one at', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        <a href="https://pixnime.com" target="_blank">pixnime.com</a>
                        <br><em><?php esc_html_e('Generation via Pixnime server → OpenAI (50 credits per image)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></em>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="openai_key"><?php esc_html_e('OpenAI API Key', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                </th>
                <td>
                    <div class="key-field-container" style="display: flex; align-items: flex-start; gap: 10px;">
                        <input type="text" id="openai_key" name="pixnime_pro_settings[openai_key]" value="<?php echo esc_attr($openai_key); ?>" class="regular-text" style="width:300px;" />
                        <button type="button" id="clear-openai-key" class="button button-secondary clear-key-btn" style="background-color: #dc3232; color: white; border-color: #dc3232;" title="<?php esc_attr_e('Delete OpenAI key (VIP Pro Mode)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                            🗑️ <?php esc_html_e('Delete', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        </button>
                    </div>
                    <p class="description">
                        <strong><?php esc_html_e('VIP Pro Mode:', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></strong> <?php esc_html_e('VIP Pro subscribers only - unlimited generations', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        <br>
                        <?php esc_html_e('Enter your OpenAI API key for advanced AI avatar generation.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        <br><em><?php esc_html_e('Direct generation via your OpenAI key (no credits deducted)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></em>
                        <br><strong><?php esc_html_e('Your key is NOT stored on our servers, it transits encrypted (https) to query the Open AI API', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></strong>
                    </p>
                </td>
            </tr>
        </table>
        
        <!-- Watermark/Logo Settings Section -->
        <h2><?php esc_html_e('Watermark/Logo Settings', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="watermark_position"><?php esc_html_e('Watermark/Logo Position', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                </th>
                <td>
                    <select id="watermark_position" name="pixnime_pro_settings[watermark_position]" class="regular-text">
                        <option value="center" <?php selected($settings['watermark_position'] ?? 'center', 'center'); ?>><?php esc_html_e('Center', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                        <option value="center-bottom" <?php selected($settings['watermark_position'] ?? 'center', 'center-bottom'); ?>><?php esc_html_e('Center Bottom', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                        <option value="center-top" <?php selected($settings['watermark_position'] ?? 'center', 'center-top'); ?>><?php esc_html_e('Center Top', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                        <option value="bottom-right" <?php selected($settings['watermark_position'] ?? 'center', 'bottom-right'); ?>><?php esc_html_e('Bottom Right', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                        <option value="bottom-left" <?php selected($settings['watermark_position'] ?? 'center', 'bottom-left'); ?>><?php esc_html_e('Bottom Left', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                        <option value="top-right" <?php selected($settings['watermark_position'] ?? 'center', 'top-right'); ?>><?php esc_html_e('Top Right', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                        <option value="top-left" <?php selected($settings['watermark_position'] ?? 'center', 'top-left'); ?>><?php esc_html_e('Top Left', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                        <option value="none" <?php selected($settings['watermark_position'] ?? 'center', 'none'); ?>><?php esc_html_e('No watermark or logo', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                    </select>
                    <p class="description">
                        <?php esc_html_e('Select the position for the watermark or logo on generated images.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="watermark_image"><?php esc_html_e('Watermark/Logo Image', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                </th>
                <td>
                    <div class="watermark-upload-container">
                        <input type="hidden" id="watermark_image_id" name="pixnime_pro_settings[watermark_image_id]" value="<?php echo esc_attr($settings['watermark_image_id'] ?? ''); ?>" />
                        <input type="text" id="watermark_image_url" name="pixnime_pro_settings[watermark_image_url]" value="<?php echo esc_attr($settings['watermark_image_url'] ?? ''); ?>" class="regular-text" placeholder="<?php esc_attr_e('Select an image for watermark/logo', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>" readonly />
                        <button type="button" id="upload-watermark-btn" class="button"><?php esc_html_e('Choose Image', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></button>
                        <button type="button" id="remove-watermark-btn" class="button button-secondary" style="display: <?php echo esc_attr(!empty($settings['watermark_image_url']) ? 'inline-block' : 'none'); ?>;"><?php esc_html_e('Remove', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></button>
                    </div>
                    <div id="watermark-preview" style="margin-top: 10px;">
                        <?php if (!empty($settings['watermark_image_url'])): ?>
                            <img src="<?php echo esc_url($settings['watermark_image_url']); ?>" alt="Watermark Preview" style="max-width: 100px; max-height: 100px; border: 1px solid #ddd; border-radius: 4px;" />
                        <?php endif; ?>
                    </div>
                    <p class="description">
                        <?php esc_html_e('Upload or select an image to use as watermark/logo.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="watermark_opacity"><?php esc_html_e('Watermark Opacity', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                </th>
                <td>
                    <input type="range" id="watermark_opacity" name="pixnime_pro_settings[watermark_opacity]" min="10" max="100" value="<?php echo esc_attr($settings['watermark_opacity'] ?? '50'); ?>" class="regular-text" />
                    <span id="opacity-value"><?php echo esc_html($settings['watermark_opacity'] ?? '50'); ?>%</span>
                    <p class="description">
                        <?php esc_html_e('Adjust the transparency of the watermark (10% = very transparent, 100% = fully opaque).', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                    </p>
                </td>
            </tr>
        </table>
        
        <!-- Watermark Preview Section -->
        <div id="watermark-preview-section" style="margin: 20px 0; padding: 20px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
            <h3><?php esc_html_e('Watermark Preview', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h3>
            <div id="preview-container" style="position: relative; width: 300px; height: 300px; background: #fff; border: 2px solid #ddd; border-radius: 8px; overflow: hidden;">
                <div id="preview-image" style="width: 100%; height: 100%; background: linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%); background-size: 20px 20px; background-position: 0 0, 0 10px, 10px -10px, -10px 0px; display: flex; align-items: center; justify-content: center;">
                    <span style="color: #999; font-size: 14px;"><?php esc_html_e('Sample Image', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></span>
                </div>
                <div id="preview-watermark" style="position: absolute; display: none;">
                    <img id="preview-watermark-img" src="" alt="Watermark Preview" style="max-width: 50px; max-height: 50px; opacity: 0.5;" />
                </div>
            </div>
            <p class="description" style="margin-top: 10px;">
                <?php esc_html_e('This preview shows how your watermark will appear on generated images. Save settings to apply changes.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
            </p>
        </div>
        
        <div style="margin: 20px 0; padding: 15px; background: #e7f3ff; border-left: 4px solid #0073aa; border-radius: 4px;">
            <h3 style="margin-top: 0; color: #0073aa;">🔄 <?php esc_html_e('Automatic saving enabled', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h3>
            <p style="margin-bottom: 0;">
                <strong><?php esc_html_e('All generated images are automatically saved to the WordPress media library.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></strong>
            </p>
        </div>
        
        <h2><?php esc_html_e('Usage Information', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h2>
        <div class="usage-info">
            <h3><?php esc_html_e('API Integration', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h3>
            <p><?php esc_html_e('This plugin integrates with the Pixnime AI service and OpenAI for advanced avatar generation. Make sure to:', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></p>
            <ul>
                <li><?php esc_html_e('Get your Pixnime API key from pixnime.com', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></li>
                <li><?php esc_html_e('Get your OpenAI API key for VIP Pro features', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></li>
                <li><?php esc_html_e('Configure your preferred default settings', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></li>
                <li><?php esc_html_e('Test avatar generation in the main admin page', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></li>
            </ul>
        </div>
        
        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Settings', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>" />
        </p>
    </form>
</div> 
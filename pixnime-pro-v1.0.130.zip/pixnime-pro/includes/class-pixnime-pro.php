<?php
/**
 * Main plugin class
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Pixnime_Pro {
    
    /**
     * Plugin version
     */
    private $version;
    
    /**
     * Admin class instance
     */
    private $admin;
    
    /**
     * API class instance
     */
    private $api;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->version = PIXNIME_PRO_VERSION;
        $this->load_dependencies();
    }
    
    /**
     * Initialize the plugin
     */
    public function init() {
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        $this->admin = new Pixnime_Pro_Admin($this->get_version());
        $this->api = new Pixnime_Pro_API();
        
        // Inclure le widget
        require_once PIXNIME_PRO_PLUGIN_DIR . 'includes/class-pixnime-pro-widget.php';
    }
    
    /**
     * Set locale for translations
     * 
     * Note: load_plugin_textdomain() is no longer needed for WordPress.org hosted plugins
     * since WordPress 4.6. WordPress automatically loads translations as needed.
     */
    private function set_locale() {
        // WordPress automatically loads translations for plugins hosted on WordPress.org
        // since version 4.6. No manual intervention needed.
        
        // Legacy code commented out for reference:
        /*
        $wp_locale = get_locale();
        if (strpos($wp_locale, 'fr') === 0) {
            load_plugin_textdomain(
                'pixnime-pro-ai-character-and-illustrations-consistency-generator',
                false,
                dirname(plugin_basename(__FILE__)) . '/languages/'
            );
            $mo_file = PIXNIME_PRO_PLUGIN_DIR . 'languages/pixnime-pro-fr_FR.mo';
            if (file_exists($mo_file)) {
                load_textdomain('pixnime-pro-ai-character-and-illustrations-consistency-generator', $mo_file);
            }
        } else {
            load_plugin_textdomain(
                'pixnime-pro-ai-character-and-illustrations-consistency-generator',
                false,
                dirname(plugin_basename(__FILE__)) . '/languages/'
            );
        }
        */
    }
    
    /**
     * Register admin hooks
     */
    private function define_admin_hooks() {
        // Admin menu
        add_action('admin_menu', array($this->admin, 'add_admin_menu'));
        
        // Admin scripts and styles
        add_action('admin_enqueue_scripts', array($this->admin, 'enqueue_styles'));
        add_action('admin_enqueue_scripts', array($this->admin, 'enqueue_scripts'));
        
        // Settings
        add_action('admin_init', array($this->admin, 'register_settings'));
        
        // AJAX handlers
        add_action('wp_ajax_pixnime_generate_avatar', array($this->api, 'generate_avatar'));
        add_action('wp_ajax_pixnime_generate_variation', array($this->api, 'generate_variation'));
        add_action('wp_ajax_pixnime_delete_variation', array($this->api, 'delete_variation'));
        add_action('wp_ajax_pixnime_delete_current_avatar', array($this->api, 'delete_current_avatar'));
        add_action('wp_ajax_pixnime_delete_all_avatars', array($this->api, 'delete_all_avatars'));
        add_action('wp_ajax_pixnime_clear_workspace', array($this->api, 'clear_workspace'));
        add_action('wp_ajax_pixnime_save_api_key', array($this->api, 'save_api_key'));
        add_action('wp_ajax_pixnime_add_image_to_workspace', array($this->api, 'add_image_to_workspace'));
        add_action('wp_ajax_pixnime_verify_api_key', array($this->api, 'verify_api_key'));
        add_action('wp_ajax_pixnime_test_watermark', array($this->api, 'test_watermark'));
        add_action('wp_ajax_pixnime_generate_id_from_prompt', array($this, 'ajax_generate_id_from_prompt'));
        add_action('wp_ajax_pixnime_clear_key', array($this->admin, 'handle_clear_key'));
        
        // Hook pour la suppression d'attachments
        add_action('delete_attachment', array($this->api, 'handle_attachment_deletion'));
        
        // Handle direct URL generation
        add_action('admin_init', array($this->api, 'handle_direct_generation'));
    }
    
    /**
     * Register public hooks
     */
    private function define_public_hooks() {
        // Shortcodes
        add_shortcode('pixnime_avatar', array($this, 'avatar_shortcode'));
        add_shortcode('pixnime_gallery', array($this, 'gallery_shortcode'));
        
        // Widget
        add_action('widgets_init', array($this, 'register_widgets'));
    }
    
    /**
     * Register widgets
     */
    public function register_widgets() {
        register_widget('Pixnime_Pro_Widget');
    }
    
    /**
     * Avatar shortcode
     */
    public function avatar_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'pixnime-avatar'
        ), $atts);
        
        // Get user avatar or generate one
        $avatar_url = $this->get_user_avatar_url();
        
        // Vérifier si c'est un attachement WordPress
        $avatar_id = attachment_url_to_postid($avatar_url);
        if ($avatar_id) {
            // Utiliser wp_get_attachment_image pour les attachements WordPress
            return wp_get_attachment_image($avatar_id, 'medium', false, array(
                'class' => esc_attr($atts['class']),
                'alt' => esc_attr__('AI Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator')
            ));
        } else {
            // Fallback pour les URLs externes
            return sprintf(
                '<img src="%s" alt="%s" class="%s" />',
                esc_url($avatar_url),
                esc_attr__('AI Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
                esc_attr($atts['class'])
            );
        }
    }
    
    /**
     * Gallery shortcode
     */
    public function gallery_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'pixnime-gallery'
        ), $atts);
        
        // Get user avatar variations (no limit)
        $variations = $this->get_user_avatar_variations();
        
        $output = '<div class="' . esc_attr($atts['class']) . '">';
        foreach ($variations as $variation) {
            // Vérifier si c'est un attachement WordPress
            $variation_id = attachment_url_to_postid($variation['url']);
            if ($variation_id) {
                // Utiliser wp_get_attachment_image pour les attachements WordPress
                $output .= wp_get_attachment_image($variation_id, 'medium', false, array(
                    'class' => 'pixnime-variation',
                    'alt' => esc_attr__('Avatar Variation', 'pixnime-pro-ai-character-and-illustrations-consistency-generator')
                ));
            } else {
                // Fallback pour les URLs externes
                $output .= sprintf(
                    '<img src="%s" alt="%s" class="pixnime-variation" />',
                    esc_url($variation['url']),
                    esc_attr__('Avatar Variation', 'pixnime-pro-ai-character-and-illustrations-consistency-generator')
                );
            }
        }
        $output .= '</div>';
        
        return $output;
    }
    
    /**
     * Get user avatar URL
     */
    private function get_user_avatar_url() {
        $user_id = get_current_user_id();
        $avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
        
        if (!$avatar_url) {
            // Generate default avatar
            $avatar_url = PIXNIME_PRO_PLUGIN_URL . 'assets/images/default-avatar.svg';
        }
        
        return $avatar_url;
    }
    
    /**
     * Get user avatar variations (no limit)
     */
    private function get_user_avatar_variations() {
        $user_id = get_current_user_id();
        $variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
        
        if (!$variations) {
            $variations = array();
        }
        
        return $variations;
    }
    
    /**
     * Generate random alphanumeric ID
     * Creates a unique identifier with timestamp for uniqueness
     */
    public function generate_random_id($prompt = '') {
        // Si un prompt est fourni, extraire un mot-clé
        if (!empty($prompt)) {
            $keyword = $this->extract_keyword_from_prompt($prompt);
            if ($keyword) {
                $random_part = $this->generate_random_string(6);
                return strtolower($keyword . '_' . $random_part);
            }
        }
        
        // Générer un ID unique avec timestamp pour éviter les doublons
        $timestamp = substr(time(), -6); // 6 derniers chiffres du timestamp
        $random_part = $this->generate_random_string(4);
        return strtolower($timestamp . $random_part);
    }
    
    /**
     * Extract a meaningful keyword from prompt
     */
    private function extract_keyword_from_prompt($prompt) {
        // Nettoyer le prompt et le convertir en minuscules
        $prompt = strtolower(trim($prompt));
        
        // Mots à ignorer (stop words)
        $stop_words = array(
            'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from', 'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the', 'to', 'was', 'will', 'with', 'une', 'un', 'le', 'la', 'les', 'de', 'du', 'des', 'et', 'ou', 'mais', 'donc', 'or', 'ni', 'car', 'avec', 'dans', 'par', 'pour', 'sans', 'sous', 'sur', 'vers', 'chez',
            '4k', 'hd', 'high', 'quality', 'definition', 'style', 'portrait', 'image', 'photo', 'picture', 'illustration', 'avatar', 'character', 'beautiful', 'stunning', 'amazing', 'professional', 'detailed'
        );
        
        // Séparer en mots
        $words = preg_split('/[^a-z0-9]+/', $prompt);
        
        // Chercher des mots significatifs
        foreach ($words as $word) {
            $word = trim($word);
            // Ignorer les mots trop courts, les stop words et les mots trop longs
            if (strlen($word) >= 3 && strlen($word) <= 12 && !in_array($word, $stop_words)) {
                // Nettoyer le mot pour l'ID
                $clean_word = preg_replace('/[^a-z0-9]/', '', $word);
                if (strlen($clean_word) >= 3) {
                    return $clean_word;
                }
            }
        }
        
        return null; // Aucun mot-clé trouvé
    }
    
    /**
     * Generate random alphanumeric string (lowercase)
     */
    private function generate_random_string($length = 8) {
        $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $result = '';
        for ($i = 0; $i < $length; $i++) {
            $result .= $characters[wp_rand(0, strlen($characters) - 1)];
        }
        return $result;
    }
    
    /**
     * AJAX handler for generating ID from prompt
     */
    public function ajax_generate_id_from_prompt() {
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field(wp_unslash($_POST['prompt'])) : '';
        $generated_id = $this->generate_random_id($prompt);
        
        wp_send_json_success(array(
            'avatar_id' => $generated_id
        ));
    }
    
    /**
     * Get plugin version
     */
    public function get_version() {
        return $this->version;
    }
} 
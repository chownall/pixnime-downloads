=== Pixnime Pro - AI Character and Illustrations Consistency Generator ===
Contributors: dufforte, pixnime
Tags: avatar, ai avatar, avatar generator, consistent avatar, avatar consistency, flat cartoon, ai image, illustration, prompt to image, character design, blogger tools, wordpress avatar, personalized avatar, identity toolkit, pixnime, image generation, user profile illustration, wordpress plugin, ai art wordpress, openjourney, dalle, stable diffusion, controlnet, image api
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.120
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Disclaimer ==
This software is provided "as is" without warranty of any kind, either express or implied, including but not limited to the implied warranties of merchantability, fitness for a particular purpose, and non-infringement. The entire risk as to the quality and performance of the software is with you. Should the software prove defective, you assume the cost of all necessary servicing, repair, or correction.

In no event shall the authors or copyright holders be liable for any claim, damages, or other liability, whether in an action of contract, tort, or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.

The use of AI-generated content may be subject to additional terms and conditions from third-party AI service providers. Users are responsible for ensuring compliance with all applicable laws and regulations regarding AI-generated content, including but not limited to copyright, privacy, and data protection laws.

== Installation ==

Create a consistent AI avatar and generate stylized variations to illustrate your WordPress blog.

== External Services ==

This plugin connects to external AI services to generate avatar images and illustrations. The following services are used:

**Pixnime API (https://www.pixnime.com)**
- **Purpose**: Primary AI image generation service for avatar creation and variations
- **Data sent**: User prompts, avatar descriptions, and API key for authentication
- **When sent**: When generating new avatars or creating variations
- **Terms of Service**: https://www.pixnime.com/terms
- **Privacy Policy**: https://www.pixnime.com/privacy

**OpenAI API (https://api.openai.com)**
- **Purpose**: Secondary AI service for image generation and text processing (GPT-4, DALL-E)
- **Data sent**: User prompts, avatar descriptions, and OpenAI API key for authentication
- **When sent**: When using VIP Pro mode or when Pixnime service is unavailable
- **Terms of Service**: https://openai.com/policies/terms-of-use
- **Privacy Policy**: https://openai.com/policies/privacy-policy

**Data Processing**: All prompts and descriptions are sent to these services to generate the requested images. No personal user data beyond the API keys and generation prompts is transmitted. Generated images are stored locally in your WordPress Media Library.

== Description ==
Generate AI avatars or illustrations and ensure visual consistency throughout your creations. Start with a prompt, choose a visual style (from 3D cartoon to 4K realistic), and inject adapted prompts to refine poses and expressions. Save time by reusing existing assets, with all visuals stored directly in your WordPress Media Library.

Pixnime Pro allows bloggers and content creators to generate a personalized AI avatar and create consistent variations to illustrate their articles, profiles, or pages. Based on the latest AI technologies, this plugin offers a simple and powerful experience to enrich your visual identity.

- Consistent AI avatar generation
- Stylized variations (flat cartoon, realistic, anime, pixel art, etc.)
- Easy integration via shortcode or widget
- Secure API and privacy respect

== Installation ==
1. Download the plugin from the WordPress repository or via https://pixnime.com/wordpress
2. Extract the archive to the `wp-content/plugins/` folder
3. Activate the plugin via the WordPress Extensions menu
4. Configure your Pixnime API key in the plugin settings (A free Pixnime API key is required to generate avatars (100 credits included when you sign up).)

== No tables are created ==

== FAQ ==
= Do I need a Pixnime account? =
Yes, a Pixnime API key is required to generate avatars.

= What avatar sizes are available? =
1024x1024 pixels.

= Can I customize the style? =
Yes, several styles are available (cartoon, realistic, anime, etc.).

== Changelog ==
= 1.0.120 =
* Version increment and build optimization - 2025-08-28

= 1.0.119 =
* Version increment and build optimization - 2025-08-06

= 1.0.118 =
* Version increment and build optimization - 2025-07-07

= 1.0.117 =
* Version increment and build optimization - 2025-07-07

= 1.0.116 =
* Version increment and build optimization - 2025-07-07

= 1.0.115 =
* Version increment and build optimization - 2025-07-07

= 1.0.114 =
* Version increment and build optimization - 2025-07-07

= 1.0.113 =
* Version increment and build optimization - 2025-07-07

= 1.0.112 =
* Version increment and build optimization - 2025-07-07

= 1.0.111 =
* Version increment and build optimization - 2025-07-07

= 1.0.110 =
* Version increment and build optimization - 2025-07-07

= 1.0.109 =
* Version increment and build optimization - 2025-07-07

= 1.0.108 =
* Version increment and build optimization - 2025-07-07

= 1.0.107 =
* Version increment and build optimization - 2025-07-07

= 1.0.106 =
* Version increment and build optimization - 2025-07-07

= 1.0.105 =
* Version increment and build optimization - 2025-07-07

= 1.0.104 =
* Version increment and build optimization - 2025-07-07

= 1.0.103 =
* Version increment and build optimization - 2025-07-07

= 1.0.102 =
* Version increment and build optimization - 2025-07-07

= 1.0.101 =
* Version increment and build optimization - 2025-07-06

= 1.0.100 =
* Version increment and build optimization - 2025-07-06

= 1.0.99 =
* Version increment and build optimization - 2025-07-06

== External Services ==

This plugin connects to external AI services to generate avatar images:

**OpenAI API (api.openai.com)**
- Used for: AI image generation and text-to-image conversion
- Data sent: User prompts, style preferences, and generation parameters
- When sent: When generating avatars or variations
- Terms of Service: https://openai.com/policies/terms-of-use
- Privacy Policy: https://openai.com/privacy

**Pixnime API (pixnime.com)**
- Used for: User authentication, credit management, and API verification
- Data sent: API keys for verification and user identification
- When sent: When verifying API keys and checking user status
- Terms of Service: https://pixnime.com/terms
- Privacy Policy: https://pixnime.com/privacy

**Data Privacy**: Your OpenAI API key is encrypted during transmission and is not stored on our servers. It is only used to make direct API calls to OpenAI's services.


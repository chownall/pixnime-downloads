<?php
/**
 * API class for Pixnime Pro
 *
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Remove all direct core file includes - WordPress will autoload these functions
// The class will be properly initialized through WordPress hooks

class Pixnime_Pro_API {
    
    /**
     * Constructor - initialize hooks
     */
    public function __construct() {
        // Register AJAX handlers
        add_action('wp_ajax_pixnime_generate_avatar', array($this, 'generate_avatar'));
        add_action('wp_ajax_pixnime_generate_variation', array($this, 'generate_variation'));
        add_action('wp_ajax_pixnime_clear_workspace', array($this, 'clear_workspace'));
        add_action('wp_ajax_pixnime_delete_avatar', array($this, 'delete_avatar'));
        add_action('wp_ajax_pixnime_delete_all_avatars', array($this, 'delete_all_avatars'));
        add_action('wp_ajax_pixnime_add_to_workspace', array($this, 'add_to_workspace'));
        add_action('wp_ajax_pixnime_delete_variation', array($this, 'delete_variation'));
        add_action('wp_ajax_pixnime_verify_api_key', array($this, 'verify_api_key'));
        add_action('wp_ajax_pixnime_check_credits', array($this, 'check_credits'));
        add_action('wp_ajax_pixnime_test_watermark', array($this, 'test_watermark'));
        
        // Register admin hooks for direct generation
        add_action('admin_init', array($this, 'handle_direct_generation'));
    }
    
    /**
     * Log function for debugging (temporarily enabled)
     */
    private function log($message, $data = null) {
        // Debug logs temporarily enabled for troubleshooting
        error_log('Pixnime Pro Debug: ' . $message);
        if ($data !== null) {
            error_log('Pixnime Pro Data: ' . print_r($data, true));
        }
    }
    
    /**
     * Gère la génération d'un avatar via AJAX avec architecture hybride
     * - Utilisateurs VIP Pro (clé OpenAI) : génération directe
     * - Utilisateurs avec crédits (clé Pixnime) : via api_generate_image
     */
    public function generate_avatar() {
        // Vérification de sécurité
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            wp_send_json_error('Security error');
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        $user_id = get_current_user_id();
        $description = isset($_POST['description']) ? sanitize_textarea_field($_POST['description']) : '';
        $avatar_id = isset($_POST['avatar_randomunique']) ? sanitize_text_field($_POST['avatar_randomunique']) : '';
        
        // Validation de la longueur du prompt final
        $settings = get_option('pixnime_pro_settings', array());
        $style_preset = isset($_POST['style_preset']) ? sanitize_text_field($_POST['style_preset']) : '';
        
        // Calculer le prompt final (description + style)
        $final_prompt = $description;
        if (!empty($style_preset) && $style_preset !== 'none') {
            $style_text = $this->get_style_text($style_preset);
            if ($style_text) {
                $final_prompt = $description . ' ' . $style_text;
            }
        }
        
        $this->log('Génération d\'avatar demandée', [
            'user_id' => $user_id,
            'description' => $description,
            'style_preset' => $style_preset,
            'final_prompt_length' => strlen($final_prompt),
            'avatar_id' => $avatar_id
        ]);
        
        // Augmenter le timeout PHP pour les requêtes longues
        set_time_limit(300); // 5 minutes
        
        $pixnime_api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
        $openai_key = isset($settings['openai_key']) ? $settings['openai_key'] : '';
        
        // 🎯 ARCHITECTURE HYBRIDE : Déterminer le mode de génération
        $is_vip_pro = $this->is_vip_pro_user($openai_key, $pixnime_api_key);
        
        if ($is_vip_pro) {
            // 👑 MODE VIP PRO : Appel à l'API Pixnime VIP Pro (NÉCESSITE les deux clés)
            $this->log('Mode VIP Pro détecté - génération via API Pixnime VIP Pro');
            
            if (empty($openai_key)) {
                wp_send_json_error('OpenAI key required for VIP Pro mode');
                return;
            }
            
            if (empty($pixnime_api_key)) {
                wp_send_json_error('VIP Pro mode also requires Pixnime key for user identification');
                return;
            }
            
            // Get Pixnime user_id via key verification
            $credit_check = $this->verify_pixnime_credits($pixnime_api_key);
            if (!$credit_check['success']) {
                wp_send_json_error('Invalid Pixnime key: ' . $credit_check['message']);
                return;
            }
            
            $pixnime_user_id = $credit_check['user_id'];
            $this->log('User ID Pixnime récupéré:', $pixnime_user_id);
            
            // Stocker le user_id Pixnime en meta WordPress pour éviter des appels futurs
            update_user_meta($user_id, 'pixnime_user_id', $pixnime_user_id);
            
            $api_url = $this->get_pixnime_api_base_url() . '/index.php?page=webhook&action=api_generate_vip_pro';
            $payload = [
                'openai_key' => $openai_key,
                'pixnime_key' => $pixnime_api_key,
                'prompt' => $final_prompt,
                'user_id' => $pixnime_user_id,
                'avatar_id' => $avatar_id,
                'mode' => 'generate'
            ];
            
            $response = wp_remote_post($api_url, [
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($payload),
                'timeout' => 120
            ]);
            
            if (is_wp_error($response)) {
                $this->log('Erreur lors de la génération via API VIP Pro:', $response->get_error_message());
                wp_send_json_error('Erreur de connexion à l\'API VIP Pro: ' . $response->get_error_message());
                return;
            }
            
            $body = wp_remote_retrieve_body($response);
            $result = json_decode($body, true);
            $this->log('Réponse API VIP Pro:', $result);
            
            if (!$result || !isset($result['success']) || !$result['success'] || empty($result['image_url'])) {
                $error_message = isset($result['error']) ? $result['error'] : 'Erreur inconnue lors de la génération (VIP Pro)';
                wp_send_json_error($error_message);
                return;
            }
            
            $avatar_url = $result['image_url'];
            
            // Sauvegarder l'avatar
            update_user_meta($user_id, 'pixnime_avatar_url', $avatar_url);
            update_user_meta($user_id, 'pixnime_avatar_prompt', $final_prompt);
            update_user_meta($user_id, 'pixnime_avatar_id', $avatar_id);
            update_user_meta($user_id, 'pixnime_last_prompt', $description);
            
            // Sauvegarder automatiquement dans la bibliothèque des médias
            $this->save_image_to_media_library($avatar_url, $final_prompt, $user_id);
            
            $this->log('Avatar VIP Pro saved:', $avatar_url);
            
            wp_send_json_success(array(
                'avatar_url' => $avatar_url,
                'message' => __('Avatar generated successfully (VIP Pro Mode)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
                'mode' => 'vip_pro',
                'credits_remaining' => null,
                'credits_used' => 0
            ));
        } else {
            // 💰 MODE CRÉDITS : Génération via api_generate_image
            $this->log('Mode crédits détecté - génération via api_generate_image');
            
            if (empty($pixnime_api_key)) {
                wp_send_json_error('Pixnime API key required');
                return;
            }
            
            // Vérification rapide des crédits avant génération
            $credit_check = $this->verify_pixnime_credits($pixnime_api_key);
            if (!$credit_check['success']) {
                wp_send_json_error($credit_check['message']);
                return;
            }
            
            if ($credit_check['credits'] < 50) {
                wp_send_json_error('Not enough credits (you have ' . $credit_check['credits'] . ' credits, 50 required). Buy some here: https://www.pixnime.com/index.php?page=offers');
                return;
            }
            
            // Génération via l'endpoint api_generate_image
            $generation_result = $this->generate_with_pixnime_api($pixnime_api_key, $final_prompt, $avatar_id);
            
            if (!$generation_result['success']) {
                wp_send_json_error($generation_result['message']);
                return;
            }
            
            $avatar_url = $generation_result['image_url'];
            
            // Sauvegarder l'avatar
            update_user_meta($user_id, 'pixnime_avatar_url', $avatar_url);
            update_user_meta($user_id, 'pixnime_avatar_prompt', $final_prompt);
            update_user_meta($user_id, 'pixnime_avatar_id', $avatar_id);
            update_user_meta($user_id, 'pixnime_last_prompt', $description);
            
            // Sauvegarder automatiquement dans la bibliothèque des médias
            $this->save_image_to_media_library($avatar_url, $final_prompt, $user_id);
            
            // Enregistrer l'utilisation localement pour les statistiques
            $this->log_credit_usage($pixnime_api_key, $generation_result['credits_used'], $generation_result);
            
            $this->log('Avatar crédits saved:', $avatar_url);
            
            wp_send_json_success(array(
                'avatar_url' => $avatar_url,
                'message' => __('Avatar generated successfully via Pixnime', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
                'mode' => 'credits',
                'credits_remaining' => $generation_result['credits_remaining'],
                'credits_used' => $generation_result['credits_used'],
                'generation_id' => $generation_result['generation_id'],
                'total_used_today' => $this->get_daily_credit_usage()
            ));
        }
    }
    
    /**
     * Déterminer si l'utilisateur est VIP Pro (NÉCESSITE les deux clés : OpenAI + Pixnime)
     */
    private function is_vip_pro_user($openai_key, $pixnime_key) {
        // Mode VIP Pro nécessite les DEUX clés pour l'identification utilisateur
        $has_valid_openai = !empty($openai_key) && strlen($openai_key) > 20 && strpos($openai_key, 'sk-') === 0;
        $has_valid_pixnime = !empty($pixnime_key) && strlen($pixnime_key) > 10;
        
        return $has_valid_openai && $has_valid_pixnime;
    }
    
    /**
     * Générer une image via l'endpoint api_generate_image de Pixnime
     */
    private function generate_with_pixnime_api($api_key, $prompt, $avatar_id, $style_info = '') {
        $this->log('Génération via api_generate_image Pixnime');
        $this->log('Clé API utilisée:', substr($api_key, 0, 10) . '...' . substr($api_key, -4));
        $this->log('Prompt:', $prompt);
        $this->log('Avatar ID:', $avatar_id);
        
        // Préparer les données pour l'endpoint
        $request_data = [
            'api_key' => $api_key,
            'prompt' => $prompt,
            'avatar_id' => $avatar_id
        ];
        
        if (!empty($style_info)) {
            $request_data['style_info'] = $style_info;
        }
        
        $api_base = $this->get_pixnime_api_base_url();
        
        // Appel à l'endpoint api_generate_image
        $response = wp_remote_post($api_base . '/index.php?page=webhook&action=api_generate_image', [
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($request_data),
            'timeout' => 120 // 2 minutes pour la génération
        ]);
        
        if (is_wp_error($response)) {
            $this->log('Erreur lors de la génération via Pixnime API:', $response->get_error_message());
            return [
                'success' => false,
                'message' => 'Erreur de connexion lors de la génération: ' . $response->get_error_message()
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $http_code = wp_remote_retrieve_response_code($response);
        $result = json_decode($body, true);
        
        $this->log('Code HTTP api_generate_image:', $http_code);
        $this->log('Corps brut de la réponse:', $body);
        $this->log('Réponse décodée api_generate_image:', $result);
        
        if ($http_code !== 200) {
            $this->log('HTTP Error during generation:', "Code $http_code - $body");
            return [
                'success' => false,
                'message' => "HTTP server error $http_code during generation"
            ];
        }
        
        if (!$result || !isset($result['success']) || !$result['success']) {
            $error_message = isset($result['error']) ? $result['error'] : 'Unknown error during generation';
            $this->log('Generation failed via Pixnime API:', $error_message);
            $this->log('Error details:', $result);
            
            // Specific error messages based on error code
            if (isset($result['code'])) {
                switch ($result['code']) {
                    case 'INSUFFICIENT_CREDITS':
                        $error_message .= ' Buy credits here: https://www.pixnime.com/index.php?page=offers';
                        break;
                    case 'INVALID_API_KEY':
                        $error_message = 'Invalid Pixnime API key';
                        break;
                    case 'PROMPT_TOO_SHORT':
                        $error_message = 'Prompt must contain at least 10 characters';
                        break;
                    case 'PROMPT_TOO_LONG':
                        $error_message = 'Prompt cannot exceed 1000 characters';
                        break;
                }
            }
            
            return [
                'success' => false,
                'message' => $error_message
            ];
        }
        
        // Check that the image URL is present
        if (empty($result['image_url'])) {
            return [
                'success' => false,
                'message' => 'No image URL received from Pixnime server'
            ];
        }
        
        return [
            'success' => true,
            'image_url' => $result['image_url'],
            'credits_remaining' => $result['credits_remaining'] ?? 0,
            'credits_used' => $result['credits_used'] ?? 50,
            'generation_id' => $result['generation_id'] ?? null,
            'avatar_id' => $result['avatar_id'] ?? $avatar_id,
            'prompt_used' => $result['prompt_used'] ?? $prompt,
            'style_used' => $result['style_used'] ?? 'default',
            'model_used' => $result['model_used'] ?? 'gpt-image-1'
        ];
    }
    
    /**
     * Générer une variation via l'endpoint api_edit_image de Pixnime
     */
    private function generate_variation_with_pixnime_api($api_key, $prompt, $avatar_id, $original_image_url, $style_info = '') {
        $this->log('Génération de variation via api_edit_image Pixnime');
        $this->log('Clé API utilisée:', substr($api_key, 0, 10) . '...' . substr($api_key, -4));
        $this->log('Prompt variation:', $prompt);
        $this->log('Avatar ID variation:', $avatar_id);
        $this->log('Image originale URL:', $original_image_url);
        
        // Télécharger l'image originale et la convertir en base64
        $image_base64 = $this->download_image_as_base64($original_image_url);
        if (!$image_base64) {
            return [
                'success' => false,
                'message' => 'Unable to download original image for editing'
            ];
        }
        
        // Préparer les données pour l'endpoint
        $request_data = [
            'api_key' => $api_key,
            'prompt' => $prompt,
            'avatar_id' => $avatar_id,
            'image_base64' => $image_base64,
            'mode' => 'variation' // Ajout du paramètre mode
        ];
        
        if (!empty($style_info)) {
            $request_data['style_info'] = $style_info;
        }
        
        $api_base = $this->get_pixnime_api_base_url();
        
        // Appel à l'endpoint api_edit_image
        $response = wp_remote_post($api_base . '/index.php?page=webhook&action=api_edit_image', [
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($request_data),
            'timeout' => 120 // 2 minutes pour l'édition
        ]);
        
        if (is_wp_error($response)) {
            $this->log('Error during variation generation via Pixnime API:', $response->get_error_message());
            return [
                'success' => false,
                'message' => 'Connection error during variation generation: ' . $response->get_error_message()
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $http_code = wp_remote_retrieve_response_code($response);
        $result = json_decode($body, true);
        
        $this->log('Code HTTP api_edit_image:', $http_code);
        $this->log('Corps brut de la réponse api_edit_image:', $body);
        $this->log('Réponse décodée api_edit_image:', $result);
        
        if ($http_code !== 200) {
            $this->log('HTTP Error during variation generation (Open AI moderation or file format):', "Code $http_code - $body");
            return [
                'success' => false,
                'message' => "HTTP server error $http_code during variation generation. Please check that the prompt is ethically correct."
            ];
        }
        
        if (!$result || !$result['success']) {
            $error_message = isset($result['error']) ? $result['error'] : 'Unknown error during variation generation';
            $this->log('Variation generation failed via Pixnime API:', $error_message);
            $this->log('Variation error details:', $result);
            
            // Specific error messages based on error code
            if (isset($result['code'])) {
                switch ($result['code']) {
                    case 'INSUFFICIENT_CREDITS':
                        $error_message .= ' Buy credits here: https://www.pixnime.com/index.php?page=offers';
                        break;
                    case 'INVALID_API_KEY':
                        $error_message = 'Invalid Pixnime API key';
                        break;
                    case 'PROMPT_TOO_SHORT':
                        $error_message = 'Prompt must contain at least 10 characters';
                        break;
                    case 'PROMPT_TOO_LONG':
                        $error_message = 'Prompt cannot exceed 1000 characters';
                        break;
                }
            }
            
            return [
                'success' => false,
                'message' => $error_message
            ];
        }
        
        // Check that the image URL is present
        if (empty($result['image_url'])) {
            return [
                'success' => false,
                'message' => 'No image URL received from Pixnime server for variation'
            ];
        }
        
        return [
            'success' => true,
            'image_url' => $result['image_url'],
            'credits_remaining' => $result['credits_remaining'] ?? 0,
            'credits_used' => $result['credits_used'] ?? 50,
            'generation_id' => $result['generation_id'] ?? null,
            'avatar_id' => $result['avatar_id'] ?? $avatar_id,
            'prompt_used' => $result['prompt_used'] ?? $prompt,
            'style_used' => $result['style_used'] ?? 'default',
            'model_used' => $result['model_used'] ?? 'gpt-image-1',
            'action' => $result['action'] ?? 'edit'
        ];
    }
    
    /**
     * Télécharger une image depuis une URL et la convertir en base64
     */
    private function download_image_as_base64($image_url) {
        $this->log('Téléchargement de l\'image:', $image_url);
        
        // Télécharger l'image
        $response = wp_remote_get($image_url, [
            'timeout' => 60,
            'redirection' => 5
        ]);
        
        if (is_wp_error($response)) {
            $this->log('Error downloading image:', $response->get_error_message());
            return false;
        }
        
        $image_data = wp_remote_retrieve_body($response);
        $http_code = wp_remote_retrieve_response_code($response);
        
        if ($http_code !== 200 || empty($image_data)) {
            $this->log('HTTP error or empty data during download:', "Code $http_code");
            return false;
        }
        
        // Convertir en base64
        $base64 = base64_encode($image_data);
        $this->log('Image convertie en base64, taille:', strlen($base64) . ' caractères');
        
        return $base64;
    }
    
    /**
     * Vérifier les crédits Pixnime
     */
    public function verify_pixnime_credits($api_key) {
        $api_base = $this->get_pixnime_api_base_url();
        $response = wp_remote_post($api_base . '/index.php?page=webhook&action=api_verify', [
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode(['apikey' => $api_key]),
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => 'Connection error to Pixnime service'
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        if (!$result || !isset($result['success']) || !$result['success']) {
            return [
                'success' => false,
                'message' => 'Invalid Pixnime API key'
            ];
        }
        
        return [
            'success' => true,
            'credits' => $result['credits'] ?? 0,
            'user_id' => $result['user_id'] ?? null
        ];
    }
    
    /**
     * Débiter les crédits Pixnime via l'endpoint api_generate
     */
    public function debit_pixnime_credits($api_key, $credits_to_debit = 50) {
        $this->log('Débit des crédits Pixnime via api_generate:', $credits_to_debit);
        $api_base = $this->get_pixnime_api_base_url();
        // Appel à l'endpoint api_generate pour débiter les crédits
        $response = wp_remote_post($api_base . '/index.php?page=webhook&action=api_generate', [
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'api_key' => $api_key
            ]),
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            $this->log('Error during credit debit:', $response->get_error_message());
            return [
                'success' => false,
                'message' => 'Connection error during credit debit: ' . $response->get_error_message()
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        $this->log('Réponse api_generate:', $result);
        
        if (!$result || !$result['success']) {
            $error_message = isset($result['error']) ? $result['error'] : 'Unknown error during debit';
            $this->log('Credit debit failed:', $error_message);
            
            // If insufficient credits, return a specific error message
            if (isset($result['code']) && $result['code'] === 'INSUFFICIENT_CREDITS') {
                return [
                    'success' => false,
                    'message' => $error_message . ' Buy credits here: https://www.pixnime.com/index.php?page=offers'
                ];
            }
            
            return [
                'success' => false,
                'message' => 'Unable to debit credits: ' . $error_message
            ];
        }
        
        // Vérifier le jeton de sécurité reçu
        if (isset($result['security_token']) && isset($result['user_id'])) {
            $token_verification = $this->verify_security_token($result['security_token'], $result['user_id']);
            if (!$token_verification['success']) {
                $this->log('Token verification failed:', $token_verification['message']);
                return [
                    'success' => false,
                    'message' => 'Security token verification error'
                ];
            }
        }
        
        // Enregistrer l'utilisation localement pour les statistiques
        $this->log_credit_usage($api_key, $credits_to_debit, $result);
        
        return [
            'success' => true,
            'credits_remaining' => $result['credits_remaining'] ?? 0,
            'credits_used' => $result['credits_used'] ?? $credits_to_debit,
            'security_token' => $result['security_token'] ?? null,
            'user_id' => $result['user_id'] ?? null
        ];
    }
    
    /**
     * Vérifier le jeton de sécurité via l'endpoint api_verify_token
     */
    private function verify_security_token($security_token, $user_id) {
        $this->log('Vérification du jeton de sécurité pour user:', $user_id);
        $api_base = $this->get_pixnime_api_base_url();
        $response = wp_remote_post($api_base . '/index.php?page=webhook&action=api_verify_token', [
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'security_token' => $security_token,
                'user_id' => $user_id
            ]),
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            $this->log('Error during token verification:', $response->get_error_message());
            return [
                'success' => false,
                'message' => 'Connection error during token verification'
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        $this->log('Réponse api_verify_token:', $result);
        
        if (!$result || !$result['valid']) {
            $error_message = isset($result['error']) ? $result['error'] : 'Invalid token';
            return [
                'success' => false,
                'message' => $error_message
            ];
        }
        
        return [
            'success' => true,
            'verified_at' => $result['verified_at'] ?? gmdate('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Enregistrer l'utilisation des crédits localement pour les statistiques
     */
    private function log_credit_usage($api_key, $credits_used, $api_response) {
        $usage_log = get_option('pixnime_credit_usage_log', array());
        
        $usage_entry = array(
            'api_key' => substr($api_key, 0, 8) . '...', // Ne stocker que les premiers caractères pour la sécurité
            'credits_used' => $credits_used,
            'timestamp' => current_time('mysql'),
            'action' => 'avatar_generation',
            'user_id' => get_current_user_id(),
            'pixnime_user_id' => $api_response['user_id'] ?? null,
            'security_token' => isset($api_response['security_token']) ? substr($api_response['security_token'], 0, 16) . '...' : null
        );
        
        $usage_log[] = $usage_entry;
        
        // Garder seulement les 100 dernières entrées
        if (count($usage_log) > 100) {
            $usage_log = array_slice($usage_log, -100);
        }
        
        update_option('pixnime_credit_usage_log', $usage_log);
        
        // Incrémenter le compteur total d'utilisation
        $total_used = get_option('pixnime_total_credits_used', 0);
        $total_used += $credits_used;
        update_option('pixnime_total_credits_used', $total_used);
        
        $this->log('Utilisation des crédits enregistrée localement:', $usage_entry);
    }
    
    /**
     * Obtenir l'utilisation des crédits du jour
     */
    private function get_daily_credit_usage() {
        $usage_log = get_option('pixnime_credit_usage_log', array());
        $today = gmdate('Y-m-d');
        $daily_usage = 0;
        
        foreach ($usage_log as $entry) {
            if (strpos($entry['timestamp'], $today) === 0) {
                $daily_usage += $entry['credits_used'];
            }
        }
        
        return $daily_usage;
    }
    
    /**
     * Gère la génération d'une variation d'avatar via AJAX avec vérification des crédits
     * Basé sur la logique du prototype pour maintenir la cohérence
     */
    public function generate_variation() {
        // Check nonce first before any processing
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            wp_send_json_error('Security check failed');
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Augmenter le timeout PHP pour les requêtes longues
        set_time_limit(300); // 5 minutes
        
        $this->log('generate_variation called');
        
        // Sanitize input data
        $user_id = get_current_user_id();
        $variation_prompt = isset($_POST['variation_prompt']) ? sanitize_textarea_field($_POST['variation_prompt']) : '';

        $this->log('Variation parameters:', array(
            'variation_prompt' => $variation_prompt,
            'user_id' => $user_id
        ));

        $this->log('Variation parameters:', array(
            'variation_prompt' => $variation_prompt,
            'user_id' => $user_id
        ));

        if (empty($variation_prompt)) {
            wp_send_json_error('Variation prompt is required');
            return;
        }

        // Récupérer les données de l'avatar original
        $original_avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
        $original_prompt = get_user_meta($user_id, 'pixnime_avatar_prompt', true);
        $original_avatar_id = get_user_meta($user_id, 'pixnime_avatar_id', true);

        if (empty($original_avatar_url) || empty($original_avatar_id)) {
            wp_send_json_error('No original avatar found. Please generate an original avatar first.');
            return;
        }

        $settings = get_option('pixnime_pro_settings', array());
        $pixnime_api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
        $openai_key = isset($settings['openai_key']) ? $settings['openai_key'] : '';
        
        // 🎯 ARCHITECTURE HYBRIDE : Déterminer le mode de génération pour les variations
        $is_vip_pro = $this->is_vip_pro_user($openai_key, $pixnime_api_key);
        
        if ($is_vip_pro) {
            // 👑 MODE VIP PRO : Appel à l'API Pixnime VIP Pro pour variation (NÉCESSITE les deux clés)
            $this->log('Mode VIP Pro détecté pour variation - génération via API Pixnime VIP Pro');
            $this->log('Paramètres variation:', [
                'variation_prompt' => $variation_prompt,
                'original_avatar_url' => $original_avatar_url,
                'original_avatar_id' => $original_avatar_id,
                'user_id' => $user_id
            ]);
            
            if (empty($openai_key)) {
                wp_send_json_error('OpenAI key required for VIP Pro mode');
                return;
            }
            
            if (empty($pixnime_api_key)) {
                wp_send_json_error('VIP Pro mode also requires Pixnime key for user identification');
                return;
            }
            
            // Get Pixnime user_id via key verification
            $credit_check = $this->verify_pixnime_credits($pixnime_api_key);
            if (!$credit_check['success']) {
                wp_send_json_error('Invalid Pixnime key: ' . $credit_check['message']);
                return;
            }
            
            $pixnime_user_id = $credit_check['user_id'];
            $this->log('User ID Pixnime récupéré pour variation:', $pixnime_user_id);
            
            // Télécharger l'image originale et l'encoder en base64
            $this->log('Début téléchargement image originale pour variation');
            $image_base64 = $this->download_image_as_base64($original_avatar_url);
            if (!$image_base64) {
                $this->log('ÉCHEC: Impossible de télécharger l\'image originale pour la variation');
                wp_send_json_error('Impossible de télécharger l\'image originale pour la variation');
                return;
            }
            $this->log('SUCCÈS: Image originale téléchargée et encodée en base64, taille:', strlen($image_base64));
            
            // Générer un nouvel avatar_id pour la variation
            $variation_avatar_id = $original_avatar_id . '_var_' . time();
            $this->log('Avatar ID généré pour la variation:', $variation_avatar_id);
            
            $api_url = $this->get_pixnime_api_base_url() . '/index.php?page=webhook&action=api_generate_vip_pro';
            $payload = [
                'openai_key' => $openai_key,
                'pixnime_key' => $pixnime_api_key,
                'prompt' => $variation_prompt,
                'user_id' => $pixnime_user_id,
                'avatar_id' => $variation_avatar_id,
                'mode' => 'variation',
                'original_image_base64' => $image_base64
            ];
            
            $this->log('Préparation appel API VIP Pro variation:', [
                'api_url' => $api_url,
                'payload_keys' => array_keys($payload),
                'payload_size' => strlen(json_encode($payload)) . ' bytes'
            ]);
            
            $response = wp_remote_post($api_url, [
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($payload),
                'timeout' => 120
            ]);
            
            if (is_wp_error($response)) {
                $this->log('FAILED: Error during variation generation via VIP Pro API:', $response->get_error_message());
                wp_send_json_error('Connection error to VIP Pro API: ' . $response->get_error_message());
                return;
            }
            
            $body = wp_remote_retrieve_body($response);
            $http_code = wp_remote_retrieve_response_code($response);
            $result = json_decode($body, true);
            
            $this->log('Réponse API VIP Pro (variation):', [
                'http_code' => $http_code,
                'body_length' => strlen($body),
                'result' => $result
            ]);
            
            if ($http_code !== 200) {
                $this->log('FAILED: Non-200 HTTP code:', $http_code);
                wp_send_json_error('HTTP server error ' . $http_code . ' during variation generation (Open AI moderation or JPG format forbidden)');
                return;
            }
            
            if (!$result) {
                $this->log('FAILED: Invalid JSON response');
                wp_send_json_error('Invalid response from VIP Pro API');
                return;
            }
            
            if (!$result['success']) {
                $error_message = isset($result['error']) ? $result['error'] : 'Unknown error during variation generation (VIP Pro)';
                $this->log('FAILED: API returns success=false:', $error_message);
                wp_send_json_error($error_message);
                return;
            }
            
            if (empty($result['image_url'])) {
                $this->log('FAILED: No image URL in response');
                wp_send_json_error('No image URL received from VIP Pro API');
                return;
            }
            
            $this->log('SUCCÈS: Variation générée, URL reçue:', $result['image_url']);
            $variation_url = $result['image_url'];
            
            // Sauvegarder la variation
            $variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
            if (!is_array($variations)) {
                $variations = array();
            }
            $variation_data = array(
                'url' => $variation_url,
                'prompt' => $variation_prompt,
                'created_at' => current_time('mysql'),
                'original_avatar_id' => $original_avatar_id
            );
            $variations[] = $variation_data;
            update_user_meta($user_id, 'pixnime_avatar_variations', $variations);
            // Sauvegarder automatiquement dans la bibliothèque des médias
            $local_variation_url = $this->save_variation_to_media_library($variation_url, $variation_prompt, $user_id);
            if ($local_variation_url) {
                $variation_data['url'] = $local_variation_url;
                $variations[count($variations) - 1] = $variation_data;
                update_user_meta($user_id, 'pixnime_avatar_variations', $variations);
            }
            $this->log('Variation VIP Pro saved:', $local_variation_url ?: $variation_url);
            wp_send_json_success(array(
                'variation_url' => $local_variation_url ?: $variation_url,
                'message' => __('Variation generated successfully (VIP Pro Mode)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
                'mode' => 'vip_pro',
                'credits_remaining' => null,
                'credits_used' => 0
            ));
        } else {
            // 💰 MODE CRÉDITS : Génération via api_generate_image
            $this->log('Mode crédits détecté pour variation - génération via api_generate_image');
            
            if (empty($pixnime_api_key)) {
                wp_send_json_error('Pixnime API key required');
                return;
            }
            
            // Vérification rapide des crédits avant génération
            $credit_check = $this->verify_pixnime_credits($pixnime_api_key);
            if (!$credit_check['success']) {
                wp_send_json_error($credit_check['message']);
                return;
            }
            
            if ($credit_check['credits'] < 50) {
                wp_send_json_error('Not enough credits (you have ' . $credit_check['credits'] . ' credits, 50 required). Buy some here: https://www.pixnime.com/index.php?page=offers');
                return;
            }
            
            // Générer un nouvel avatar_id pour la variation
            $variation_avatar_id = $original_avatar_id . '_var_' . time();
            
            // Récupérer l'image originale pour l'édition
            $original_avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
            
            // Génération via l'endpoint api_edit_image pour les variations
            $generation_result = $this->generate_variation_with_pixnime_api($pixnime_api_key, $variation_prompt, $variation_avatar_id, $original_avatar_url);
            
            if (!$generation_result['success']) {
                wp_send_json_error($generation_result['message']);
                return;
            }
            
            $variation_url = $generation_result['image_url'];
            
            // Sauvegarder la variation
            $variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
            if (!is_array($variations)) {
                $variations = array();
            }

            $variation_data = array(
                'url' => $variation_url,
                'prompt' => $variation_prompt,
                'created_at' => current_time('mysql'),
                'original_avatar_id' => $original_avatar_id,
                'generation_id' => $generation_result['generation_id']
            );

            $variations[] = $variation_data;
            update_user_meta($user_id, 'pixnime_avatar_variations', $variations);
            
            // Sauvegarder automatiquement dans la bibliothèque des médias
            $this->save_variation_to_media_library($variation_url, $variation_prompt, $user_id);
            
            // Enregistrer l'utilisation localement pour les statistiques
            $this->log_credit_usage($pixnime_api_key, $generation_result['credits_used'], $generation_result);
            
            $this->log('Variation crédits saved:', $variation_url);
            
            wp_send_json_success(array(
                'variation_url' => $variation_url,
                'message' => __('Variation generated successfully via Pixnime', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
                'mode' => 'credits',
                'credits_remaining' => $generation_result['credits_remaining'],
                'credits_used' => $generation_result['credits_used'],
                'generation_id' => $generation_result['generation_id'],
                'total_used_today' => $this->get_daily_credit_usage()
            ));
        }
    }
    
    /**
     * Génère une image avec OpenAI GPT-4
     */
    private function generate_image_with_openai($prompt, $avatar_id, $api_key) {
        $this->log('Generating image with OpenAI GPT-4');
        $this->log('Prompt:', $prompt);
        $this->log('Avatar ID:', $avatar_id);
        
        // Préparer le prompt pour GPT-4
        $gpt_prompt = $this->prepare_gpt_prompt($prompt, $avatar_id);
        
        $this->log('GPT prompt:', $gpt_prompt);
        
        // Appel à l'API OpenAI GPT-4
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4',
                'messages' => array(
                    array(
                        'role' => 'system',
                        'content' => 'You are an expert avatar and illustration generator. Create a detailed description for generating a beautiful avatar or illustration image. Focus on professional quality.'
                    ),
                    array(
                        'role' => 'user',
                        'content' => $gpt_prompt
                    )
                ),
                'max_tokens' => 500,
                'temperature' => 0.7
            )),
            'timeout' => 60
        ));
        
        if (is_wp_error($response)) {
            $this->log('OpenAI GPT API error:', $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $this->log('OpenAI GPT response:', $data);
        
        if (isset($data['choices'][0]['message']['content'])) {
            $generated_description = $data['choices'][0]['message']['content'];
            $this->log('Generated description:', $generated_description);
            
            // Maintenant utiliser GPT Image 1 avec la description générée par GPT
            return $this->generate_dalle_image($generated_description, $avatar_id, $api_key);
        } else {
            $this->log('No content in GPT response');
            return false;
        }
    }
    
    /**
     * Génère une variation avec l'image originale envoyée à GPT Image 1
     * Basé sur sendImageToGPT du prototype (approche 2)
     */
    private function generate_variation_with_consistency($original_prompt, $original_avatar_id, $variation_prompt, $api_key) {
        $this->log('Generating variation with original image sent to GPT Image 1 (sendImageToGPT approach)');
        
        // Récupérer le chemin de l'image originale
        $user_id = get_current_user_id();
        $original_avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
        
        if (empty($original_avatar_url)) {
            $this->log('No original avatar URL found');
            return false;
        }
        
        // Convertir l'URL en chemin de fichier local
        $upload_dir = wp_upload_dir();
        $image_path = str_replace($upload_dir['url'], $upload_dir['path'], $original_avatar_url);
        
        if (!file_exists($image_path)) {
            $this->log('Original image file not found:', $image_path);
            return false;
        }
        
        // Construire le prompt pour la variation avec instructions de cohérence
        $gpt_prompt = "Use the base image for the pose and expression of the character.\n";
        $gpt_prompt .= $variation_prompt . "\n";
        $gpt_prompt .= "Reprend exactement le fond ou le paysage de l'image précédente. Reprend exactement les couleurs, les habits, les accessoires du personnage de l'image précédente.";
        
        $this->log('GPT Image variation prompt:', $gpt_prompt);
        $this->log('Using original image:', $image_path);
        
        // Utiliser la méthode sendImageToGPT adaptée pour WordPress
        return $this->send_image_to_gpt($image_path, $gpt_prompt, $original_avatar_id . '_var_' . time(), $api_key);
    }

    /**
     * Génère une image avec GPT Image 1 en utilisant la description de GPT
     * Basé sur le prototype qui fonctionne - sauvegarde l'image comme fichier
     */
    private function generate_dalle_image($description, $avatar_id, $api_key) {
        $this->log('Generating GPT Image 1 with GPT description using curl (prototype method)');
        
        // Préparer les données exactement comme dans le prototype
        $data = array(
            'model' => 'gpt-image-1',
            'prompt' => $description . " avatar_randomunique " . $avatar_id . " alphanum",
            'n' => 1,
            'size' => '1024x1024',
            'quality' => 'medium'
            // PAS de response_format comme dans le prototype
        );
        
        $this->log('API request data (prototype style):', $data);
        
        // Utiliser wp_remote_post comme recommandé par WordPress
        $url = 'https://api.openai.com/v1/images/generations';
        
        $response = wp_remote_post($url, array(
            'timeout' => 120, // 2 minutes pour GPT Image 1
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key
            ),
            'body' => json_encode($data)
        ));
        
        // Vérifier les erreurs de connexion
        if (is_wp_error($response)) {
            $this->log('Connection error:', $response->get_error_message());
            return false;
        }
        
        $http_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($http_code !== 200) {
            $this->log('HTTP error code:', $http_code);
            $this->log('Response:', $response_body);
            return false;
        }
        
        $this->log('Response length:', strlen($response_body));
        
        $data_response = json_decode($response_body, true);
        $this->log('OpenAI GPT Image 1 response:', $data_response);
        
        // Gérer la réponse exactement comme dans le prototype
        if (isset($data_response['data'][0]['b64_json'])) {
            $base64_data = $data_response['data'][0]['b64_json'];
            $this->log('Received base64 data, length:', strlen($base64_data));
            
            // Décoder et sauvegarder comme dans le prototype
            $image_content = base64_decode($base64_data);
            $filename = 'pixnime_avatar_' . $avatar_id . '_' . time() . '.png';
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_url = $upload_dir['url'] . '/' . $filename;
            
            // Sauvegarder l'image
            if (file_put_contents($file_path, $image_content)) {
                $this->log('Image saved successfully:', $file_path);
                return $file_url;
            } else {
                $this->log('Failed to save image file');
                return false;
            }
            
        } else if (isset($data_response['data'][0]['url'])) {
            $image_url = $data_response['data'][0]['url'];
            $this->log('Received URL, downloading and saving:', $image_url);
            
            // Télécharger l'image comme dans le prototype
            $image_content = file_get_contents($image_url);
            
            if (!$image_content) {
                $this->log('Failed to download image from URL');
                return false;
            }
            
            // Sauvegarder l'image téléchargée
            $filename = 'pixnime_avatar_' . $avatar_id . '_' . time() . '.png';
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_url = $upload_dir['url'] . '/' . $filename;
            
            if (file_put_contents($file_path, $image_content)) {
                $this->log('Downloaded image saved successfully:', $file_path);
                return $file_url;
            } else {
                $this->log('Failed to save downloaded image');
                return false;
            }
            
        } else {
            $this->log('No valid data in GPT Image 1 response');
            return false;
        }
    }

    /**
     * Génère une image directement avec GPT Image 1 (sans passer par GPT-4)
     * Utilisé pour les variations avec prompt déjà optimisé
     */
    private function generate_dalle_image_direct($prompt, $avatar_id, $api_key) {
        $this->log('Generating GPT Image 1 directly with optimized prompt');
        
        // Préparer les données exactement comme dans le prototype
        $data = array(
            'model' => 'gpt-image-1',
            'prompt' => $prompt,
            'n' => 1,
            'size' => '1024x1024',
            'quality' => 'medium'
            // PAS de response_format comme dans le prototype
        );
        
        $this->log('API request data (direct):', $data);
        
        // Utiliser wp_remote_post comme recommandé par WordPress
        $url = 'https://api.openai.com/v1/images/generations';
        
        $response = wp_remote_post($url, array(
            'timeout' => 120, // 2 minutes pour GPT Image 1
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key
            ),
            'body' => json_encode($data)
        ));
        
        // Vérifier les erreurs de connexion
        if (is_wp_error($response)) {
            $this->log('Connection error (direct):', $response->get_error_message());
            return false;
        }
        
        $http_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($http_code !== 200) {
            $this->log('HTTP error code (direct):', $http_code);
            $this->log('Response (direct):', $response_body);
            return false;
        }
        
        $this->log('Response length (direct):', strlen($response_body));
        
        $data_response = json_decode($response_body, true);
        $this->log('OpenAI GPT Image 1 response (direct):', $data_response);
        
        // Gérer la réponse exactement comme dans le prototype
        if (isset($data_response['data'][0]['b64_json'])) {
            $base64_data = $data_response['data'][0]['b64_json'];
            $this->log('Received base64 data (direct), length:', strlen($base64_data));
            
            // Décoder et sauvegarder comme dans le prototype
            $image_content = base64_decode($base64_data);
            $filename = 'pixnime_variation_' . $avatar_id . '_' . time() . '.png';
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_url = $upload_dir['url'] . '/' . $filename;
            
            // Sauvegarder l'image
            if (file_put_contents($file_path, $image_content)) {
                $this->log('Variation image saved successfully:', $file_path);
                return $file_url;
            } else {
                $this->log('Failed to save variation image file');
                return false;
            }
            
        } else if (isset($data_response['data'][0]['url'])) {
            $image_url = $data_response['data'][0]['url'];
            $this->log('Received URL (direct), downloading and saving:', $image_url);
            
            // Télécharger l'image comme dans le prototype
            $image_content = file_get_contents($image_url);
            
            if (!$image_content) {
                $this->log('Failed to download variation image from URL');
                return false;
            }
            
            // Sauvegarder l'image téléchargée
            $filename = 'pixnime_variation_' . $avatar_id . '_' . time() . '.png';
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_url = $upload_dir['url'] . '/' . $filename;
            
            if (file_put_contents($file_path, $image_content)) {
                $this->log('Downloaded variation image saved successfully:', $file_path);
                return $file_url;
            } else {
                $this->log('Failed to save downloaded variation image');
                return false;
            }
            
        } else {
            $this->log('No valid data in GPT Image 1 response (direct)');
            return false;
        }
    }

    /**
     * Envoie une image à GPT Image 1 pour modification (basé sur sendImageToGPT du prototype)
     * Utilise l'endpoint /v1/images/edits avec image + masque
     */
    private function send_image_to_gpt($image_path, $prompt, $avatar_id, $api_key) {
        $this->log('Sending image to GPT Image 1 for editing (prototype sendImageToGPT method)');
        $this->log('Image path:', $image_path);
        $this->log('Prompt:', $prompt);
        
        $url = 'https://api.openai.com/v1/images/edits';
        
        // Vérifier que l'image existe
        if (!file_exists($image_path)) {
            $this->log('Image file not found:', $image_path);
            return false;
        }
        
        // Créer le masque automatiquement avec canal alpha (RGBA) - exactement comme le prototype
        $image = imagecreatefrompng($image_path);
        if (!$image) {
            $this->log('Failed to create image from PNG');
            return false;
        }
        
        $width = imagesx($image);
        $height = imagesy($image);
        
        // Créer le masque en RGBA (avec canal alpha)
        $mask = imagecreatetruecolor($width, $height);
        
        // Activer le support alpha
        imagealphablending($mask, false);
        imagesavealpha($mask, true);
        
        // Couleur transparente par défaut
        $transparent = imagecolorallocatealpha($mask, 0, 0, 0, 127);
        imagefill($mask, 0, 0, $transparent);
        
        for ($x = 0; $x < $width; $x++) {
            for ($y = 0; $y < $height; $y++) {
                $rgb = imagecolorat($image, $x, $y);
                $r = ($rgb >> 16) & 0xFF;
                $g = ($rgb >> 8) & 0xFF;
                $b = $rgb & 0xFF;
                
                // Calculer la luminosité
                $brightness = ($r + $g + $b) / 3;
                
                // Si la luminosité est faible, c'est probablement le personnage (masque noir avec alpha)
                // Sinon c'est le fond (transparent)
                if ($brightness < 200) {
                    // Personnage : noir opaque
                    $color = imagecolorallocatealpha($mask, 0, 0, 0, 0);
                } else {
                    // Fond : transparent
                    $color = imagecolorallocatealpha($mask, 0, 0, 0, 127);
                }
                imagesetpixel($mask, $x, $y, $color);
            }
        }
        
        // Sauvegarder le masque temporairement en PNG avec alpha
        $upload_dir = wp_upload_dir();
        $mask_path = $upload_dir['path'] . '/temp_mask_' . time() . '.png';
        imagepng($mask, $mask_path);
        
        // Préparer les données pour l'API (exactement comme le prototype)
        $post_data = array(
            'model' => 'gpt-image-1',
            'prompt' => $prompt,
            'size' => '1024x1024',
            'quality' => 'medium'
        );
        
        // Créer le multipart form data
        $boundary = uniqid();
        $data = '';
        
        // Ajouter les champs
        foreach ($post_data as $key => $value) {
            $data .= "--$boundary\r\n";
            $data .= "Content-Disposition: form-data; name=\"$key\"\r\n\r\n";
            $data .= "$value\r\n";
        }
        
        // Ajouter l'image
        $data .= "--$boundary\r\n";
        $data .= "Content-Disposition: form-data; name=\"image\"; filename=\"" . basename($image_path) . "\"\r\n";
        $data .= "Content-Type: image/png\r\n\r\n";
        $data .= file_get_contents($image_path) . "\r\n";
        
        // Ajouter le masque
        $data .= "--$boundary\r\n";
        $data .= "Content-Disposition: form-data; name=\"mask\"; filename=\"" . basename($mask_path) . "\"\r\n";
        $data .= "Content-Type: image/png\r\n\r\n";
        $data .= file_get_contents($mask_path) . "\r\n";
        
        $data .= "--$boundary--\r\n";
        
        // Envoyer la requête avec wp_remote_post comme recommandé par WordPress
        $response = wp_remote_post($url, array(
            'timeout' => 120, // 2 minutes pour GPT Image 1
            'headers' => array(
                'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
                'Authorization' => 'Bearer ' . $api_key
            ),
            'body' => $data
        ));
        
        // Nettoyer les fichiers temporaires
        wp_delete_file($mask_path);
        imagedestroy($image);
        imagedestroy($mask);
        
        // Vérifier les erreurs de connexion
        if (is_wp_error($response)) {
            $this->log('Connection error (image edit):', $response->get_error_message());
            return false;
        }
        
        $http_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($http_code !== 200) {
            $this->log('HTTP error code (image edit):', $http_code);
            $this->log('Response (image edit):', $response_body);
            return false;
        }
        
        $this->log('Image edit response length:', strlen($response_body));
        
        $data_response = json_decode($response_body, true);
        $this->log('GPT Image 1 edit response:', $data_response);
        
        // Gérer la réponse exactement comme dans le prototype
        if (isset($data_response['data'][0]['b64_json'])) {
            $base64_data = $data_response['data'][0]['b64_json'];
            $this->log('Received base64 data (edit), length:', strlen($base64_data));
            
            // Décoder et sauvegarder
            $image_content = base64_decode($base64_data);
            $filename = 'pixnime_variation_' . $avatar_id . '_' . time() . '.png';
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_url = $upload_dir['url'] . '/' . $filename;
            
            // Sauvegarder l'image
            if (file_put_contents($file_path, $image_content)) {
                $this->log('Variation image (edit) saved successfully:', $file_path);
                return $file_url;
            } else {
                $this->log('Failed to save variation image (edit) file');
                return false;
            }
            
        } else if (isset($data_response['data'][0]['url'])) {
            $image_url = $data_response['data'][0]['url'];
            $this->log('Received URL (edit), downloading and saving:', $image_url);
            
            // Télécharger l'image
            $image_content = file_get_contents($image_url);
            
            if (!$image_content) {
                $this->log('Failed to download variation image (edit) from URL');
                return false;
            }
            
            // Sauvegarder l'image téléchargée
            $filename = 'pixnime_variation_' . $avatar_id . '_' . time() . '.png';
            $file_path = $upload_dir['path'] . '/' . $filename;
            $file_url = $upload_dir['url'] . '/' . $filename;
            
            if (file_put_contents($file_path, $image_content)) {
                $this->log('Downloaded variation image (edit) saved successfully:', $file_path);
                return $file_url;
            } else {
                $this->log('Failed to save downloaded variation image (edit)');
                return false;
            }
            
        } else {
            $this->log('No valid data in GPT Image 1 edit response');
            return false;
        }
    }
    
    /**
     * Prépare le prompt pour GPT-4
     */
    private function prepare_gpt_prompt($description, $avatar_id) {
        // Si la description est vide, utiliser un prompt par défaut
        if (empty($description)) {
            return "Create a detailed description for generating a beautiful cartoon avatar with 2D flat style, clean vector lines, vibrant colors, and high definition quality. Use seed ID: " . $avatar_id;
        }
        
        // Améliorer le prompt pour GPT
        $enhanced_prompt = "Based on this description: '" . $description . "', create a detailed and optimized prompt for generating a beautiful image. Use seed ID: " . $avatar_id;
        
        return $enhanced_prompt;
    }
    
    /**
     * Handle direct URL access with GET parameters
     */
    public function handle_direct_generation() {
        // Check permissions first
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Vérifier si on est sur la page admin avec des paramètres GET
        if (isset($_GET['page']) && $_GET['page'] === 'pixnime-pro-ai-character-and-illustrations-consistency-generator' && 
            isset($_GET['description'])) {
            
            $this->log('handle_direct_generation called');
            $this->log('Direct generation parameters detected');
            
            // Sanitize input data
            $user_id = get_current_user_id();
            $description = isset($_GET['description']) ? sanitize_textarea_field(urldecode($_GET['description'])) : '';
            
            $this->log('Direct generation parameters:', array(
                'description' => $description
            ));
            
            // Récupérer la clé OpenAI
            $settings = get_option('pixnime_pro_settings', array());
            $openai_key = isset($settings['openai_key']) ? $settings['openai_key'] : '';
            
            if (empty($openai_key)) {
                $this->log('OpenAI key not found for direct generation');
                // Utiliser l'image par défaut si pas de clé OpenAI
                $avatar_url = PIXNIME_PRO_PLUGIN_URL . 'assets/images/default-avatar.svg';
            } else {
                // Générer l'avatar avec OpenAI
                $avatar_url = $this->generate_image_with_openai($description, $avatar_id, $openai_key);
                if (!$avatar_url) {
                    $this->log('Failed to generate image, using default');
                    $avatar_url = PIXNIME_PRO_PLUGIN_URL . 'assets/images/default-avatar.svg';
                }
            }
            
            // Sauvegarder l'avatar
            update_user_meta($user_id, 'pixnime_avatar_url', $avatar_url);
            update_user_meta($user_id, 'pixnime_avatar_prompt', $description);
            
            $this->log('Direct generation completed:', $avatar_url);
            
            // Rediriger vers la page admin sans les paramètres GET
            wp_redirect(admin_url('admin.php?page=pixnime-pro&generated=1'));
            exit;
        }
        // Pas de log si les conditions ne sont pas remplies - évite les logs inutiles
    }
    
    /**
     * Delete avatar variation
     */
    public function delete_variation() {
        $this->log('delete_variation called');
        
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            $this->log('Nonce verification failed for delete_variation');
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        $user_id = get_current_user_id();
        $variation_index = isset($_POST['variation_index']) ? intval($_POST['variation_index']) : null;
        $image_url = isset($_POST['image_url']) ? esc_url_raw($_POST['image_url']) : '';
        
        $this->log('Delete variation parameters:', array(
            'variation_index' => $variation_index,
            'image_url' => $image_url
        ));
        
        if ($variation_index === null) {
            $this->log('Variation index is null');
            wp_send_json_error('Index de variation requis');
            return;
        }
        
        // Récupérer les variations actuelles
        $variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
        
        if (!$variations || !isset($variations[$variation_index])) {
            wp_send_json_error('Variation non trouvée');
            return;
        }
        
        // Supprimer le fichier physique
        if (!empty($image_url)) {
            $upload_dir = wp_upload_dir();
            $file_path = str_replace($upload_dir['url'], $upload_dir['path'], $image_url);
            
            if (file_exists($file_path)) {
                wp_delete_file($file_path);
                $this->log('Physical file deleted:', $file_path);
            }
        }
        
        // Supprimer la variation du tableau
        unset($variations[$variation_index]);
        
        // Réindexer le tableau
        $variations = array_values($variations);
        
        // Mettre à jour les métadonnées utilisateur
        update_user_meta($user_id, 'pixnime_avatar_variations', $variations);
        
        $this->log('Variation deleted successfully');
        
        wp_send_json_success(array(
            'message' => 'Variation supprimée avec succès'
        ));
    }
    
    /**
     * Delete current avatar
     */
    public function delete_current_avatar() {
        $this->log('delete_current_avatar called');
        
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            $this->log('Nonce verification failed');
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        $user_id = get_current_user_id();
        $image_url = isset($_POST['image_url']) ? esc_url_raw($_POST['image_url']) : '';
        
        $this->log('Delete current avatar parameters:', array(
            'image_url' => $image_url
        ));
        
        // Récupérer les variations avant de supprimer l'avatar principal
        $variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
        $variations_count = 0;
        
        // Supprimer tous les fichiers des variations
        if ($variations && is_array($variations)) {
            $variations_count = count($variations);
            $upload_dir = wp_upload_dir();
            
            foreach ($variations as $variation) {
                if (isset($variation['url']) && !empty($variation['url'])) {
                    $variation_file_path = str_replace($upload_dir['url'], $upload_dir['path'], $variation['url']);
                    if (file_exists($variation_file_path)) {
                        wp_delete_file($variation_file_path);
                        $this->log('Variation file deleted:', $variation_file_path);
                    }
                }
            }
        }
        
        // Supprimer le fichier physique de l'avatar principal
        if (!empty($image_url)) {
            $upload_dir = wp_upload_dir();
            $file_path = str_replace($upload_dir['url'], $upload_dir['path'], $image_url);
            
            if (file_exists($file_path)) {
                wp_delete_file($file_path);
                $this->log('Current avatar physical file deleted:', $file_path);
            }
        }
        
        // Supprimer les métadonnées de l'avatar et des variations
        delete_user_meta($user_id, 'pixnime_avatar_url');
        delete_user_meta($user_id, 'pixnime_avatar_prompt');
        delete_user_meta($user_id, 'pixnime_avatar_id');
        delete_user_meta($user_id, 'pixnime_avatar_variations');
        
        $this->log('Current avatar and variations deleted successfully');
        
        $message = 'Avatar principal supprimé avec succès';
        if ($variations_count > 0) {
            $message .= ' (' . $variations_count . ' variation' . ($variations_count > 1 ? 's' : '') . ' supprimée' . ($variations_count > 1 ? 's' : '') . ' également)';
        }
        
        wp_send_json_success(array(
            'message' => $message
        ));
    }
    
    /**
     * Delete all avatars (main + variations)
     */
    public function delete_all_avatars() {
        $this->log('delete_all_avatars called');
        
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            $this->log('Nonce verification failed');
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        $user_id = get_current_user_id();
        
        // Récupérer l'avatar principal et les variations
        $current_avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
        $variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
        
        if (!$variations) {
            $variations = array();
        }
        
        $deleted_files = 0;
        $upload_dir = wp_upload_dir();
        
        // Supprimer l'avatar principal
        if (!empty($current_avatar_url)) {
            $file_path = str_replace($upload_dir['url'], $upload_dir['path'], $current_avatar_url);
            if (file_exists($file_path)) {
                wp_delete_file($file_path);
                $deleted_files++;
                $this->log('Deleted main avatar file:', $file_path);
            }
        }
        
        // Supprimer toutes les variations
        foreach ($variations as $variation) {
            if (isset($variation['url']) && !empty($variation['url'])) {
                $file_path = str_replace($upload_dir['url'], $upload_dir['path'], $variation['url']);
                if (file_exists($file_path)) {
                    wp_delete_file($file_path);
                    $deleted_files++;
                    $this->log('Deleted variation file:', $file_path);
                }
            }
        }
        
        // Nettoyer toutes les métadonnées
        delete_user_meta($user_id, 'pixnime_avatar_url');
        delete_user_meta($user_id, 'pixnime_avatar_id');
        delete_user_meta($user_id, 'pixnime_avatar_prompt');
        delete_user_meta($user_id, 'pixnime_avatar_variations');
        
        $this->log('All avatar metadata cleaned for user:', $user_id);
        
        $message = sprintf(
            'Suppression terminée : %d fichier(s) supprimé(s) et toutes les métadonnées nettoyées.',
            $deleted_files
        );
        
        wp_send_json_success(array(
            'message' => $message,
            'deleted_files' => $deleted_files,
            'deleted_variations' => count($variations)
        ));
    }
    
    /**
     * Clear workspace (remove metadata only, keep files)
     */
    public function clear_workspace() {
        $this->log('clear_workspace called');
        
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            $this->log('Nonce verification failed for clear_workspace');
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        $user_id = get_current_user_id();
        
        // Récupérer les métadonnées pour le log
        $current_avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
        $variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
        
        if (!$variations) {
            $variations = array();
        }
        
        $this->log('Clearing workspace for user:', $user_id);
        $this->log('Current avatar URL:', $current_avatar_url);
        $this->log('Variations count:', count($variations));
        
        // Supprimer UNIQUEMENT les métadonnées utilisateur
        // NE PAS supprimer les fichiers physiques
        // NE PAS supprimer les entrées de la médiathèque
        delete_user_meta($user_id, 'pixnime_avatar_url');
        delete_user_meta($user_id, 'pixnime_avatar_id');
        delete_user_meta($user_id, 'pixnime_avatar_prompt');
        delete_user_meta($user_id, 'pixnime_avatar_variations');
        delete_user_meta($user_id, 'pixnime_last_prompt');
        
        $this->log('Workspace metadata cleared successfully');
        
        $message = sprintf(
            /* translators: %d: number of variations that were cleared */
            __('Workspace cleared successfully! %d variation(s) and the main avatar have been removed from the workspace. Files remain available in the media library.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            count($variations)
        );
        
        wp_send_json_success(array(
            'message' => $message,
            'cleared_variations' => count($variations),
            'had_main_avatar' => !empty($current_avatar_url)
        ));
    }

    /**
     * Sauvegarde automatique de la clé API après vérification
     */
    public function save_api_key() {
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        // Vérifier les permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Récupérer la clé API
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        
        if (empty($api_key)) {
            wp_send_json_error(__('Missing API key', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'));
            return;
        }
        
        // Récupérer les réglages existants
        $existing_settings = get_option('pixnime_pro_settings', array());
        
        // Mettre à jour seulement la clé API
        $existing_settings['api_key'] = $api_key;
        
        // Sauvegarder en base
        $update_result = update_option('pixnime_pro_settings', $existing_settings);
        
        if ($update_result) {
            wp_send_json_success(array(
                'message' => __('API key saved successfully', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
                'api_key' => $api_key
            ));
        } else {
            wp_send_json_error(__('Error saving to database', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'));
        }
    }

    /**
     * Sauvegarder l'image dans la bibliothèque des médias après la sauvegarde de l'avatar principal
     */
    private function save_image_to_media_library($image_url, $description, $user_id) {
        $this->log('Saving image to media library from URL:', $image_url);
        
        // Télécharger l'image depuis GCP
        $response = wp_remote_get($image_url, [
            'timeout' => 60,
            'redirection' => 5
        ]);
        
        if (is_wp_error($response)) {
            $this->log('Error downloading image from GCP:', $response->get_error_message());
            return;
        }
        
        $image_data = wp_remote_retrieve_body($response);
        $http_code = wp_remote_retrieve_response_code($response);
        
        if ($http_code !== 200 || empty($image_data)) {
            $this->log('Error downloading image, HTTP code:', $http_code);
            return;
        }
        
        // Générer un nom de fichier unique
        $file_name = 'pixnime_avatar_' . time() . '_' . $user_id . '.png';
        
        // Sauvegarder l'image dans la bibliothèque des médias
        $upload = wp_upload_bits($file_name, null, $image_data);
        
        if (is_wp_error($upload)) {
            $this->log('Error saving image to media library:', $upload->get_error_message());
            return;
        }
        
        $file_path = $upload['file'];
        $file_url = $upload['url'];
        
        // Appliquer le watermark si configuré
        $this->log('Application du watermark sur l\'image sauvegardée');
        $watermark_applied = $this->apply_watermark_to_image($file_path);
        if ($watermark_applied) {
            $this->log('Watermark appliqué avec succès sur l\'avatar');
        } else {
            $this->log('Erreur lors de l\'application du watermark, image sauvegardée sans watermark');
        }
        
        // Créer l'attachment dans la base de données WordPress
        $attachment = array(
            'post_mime_type' => 'image/png',
            'post_title' => 'Pixnime Avatar - ' . $description,
            'post_content' => 'Avatar généré par Pixnime Pro',
            'post_excerpt' => $description,
            'post_status' => 'inherit'
        );
        
        $attachment_id = wp_insert_attachment($attachment, $file_path, 0);
        
        if (is_wp_error($attachment_id)) {
            $this->log('Error creating attachment:', $attachment_id->get_error_message());
            return;
        }
        
        // Générer les métadonnées de l'image
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        // Mettre à jour les métadonnées de l'avatar avec l'URL locale
        update_user_meta($user_id, 'pixnime_avatar_url', $file_url); // Utiliser l'URL locale
        update_user_meta($user_id, 'pixnime_avatar_attachment_id', $attachment_id);
        
        $this->log('Image saved to media library with attachment ID:', $attachment_id);
        $this->log('URL updated to local:', $file_url);
    }

    /**
     * Sauvegarder l'image dans la bibliothèque des médias après la sauvegarde de la variation
     */
    private function save_variation_to_media_library($image_url, $description, $user_id) {
        $this->log('Saving variation to media library from URL:', $image_url);
        
        // Télécharger l'image depuis GCP
        $response = wp_remote_get($image_url, [
            'timeout' => 60,
            'redirection' => 5
        ]);
        
        if (is_wp_error($response)) {
            $this->log('Error downloading variation from GCP:', $response->get_error_message());
            return;
        }
        
        $image_data = wp_remote_retrieve_body($response);
        $http_code = wp_remote_retrieve_response_code($response);
        
        if ($http_code !== 200 || empty($image_data)) {
            $this->log('Error downloading variation, HTTP code:', $http_code);
            return;
        }
        
        // Générer un nom de fichier unique pour la variation
        $file_name = 'pixnime_variation_' . time() . '_' . $user_id . '.png';
        
        // Sauvegarder l'image dans la bibliothèque des médias
        $upload = wp_upload_bits($file_name, null, $image_data);
        
        if (is_wp_error($upload)) {
            $this->log('Error saving variation to media library:', $upload->get_error_message());
            return;
        }
        
        $file_path = $upload['file'];
        $file_url = $upload['url'];
        
        // Appliquer le watermark si configuré
        $this->log('Application du watermark sur la variation sauvegardée');
        $watermark_applied = $this->apply_watermark_to_image($file_path);
        if ($watermark_applied) {
            $this->log('Watermark appliqué avec succès sur la variation');
        } else {
            $this->log('Erreur lors de l\'application du watermark, variation sauvegardée sans watermark');
        }
        
        // Créer l'attachment dans la base de données WordPress
        $attachment = array(
            'post_mime_type' => 'image/png',
            'post_title' => 'Pixnime Variation - ' . $description,
            'post_content' => 'Variation d\'avatar générée par Pixnime Pro',
            'post_excerpt' => $description,
            'post_status' => 'inherit'
        );
        
        $attachment_id = wp_insert_attachment($attachment, $file_path, 0);
        
        if (is_wp_error($attachment_id)) {
            $this->log('Error creating variation attachment:', $attachment_id->get_error_message());
            return;
        }
        
        // Générer les métadonnées de l'image
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        // Mettre à jour les métadonnées de la variation avec l'URL locale
        update_user_meta($user_id, 'pixnime_variation_attachment_id', $attachment_id);
        
        $this->log('Variation saved to media library with attachment ID:', $attachment_id);
        $this->log('Variation URL updated to local:', $file_url);
        
        // Retourner l'URL locale pour mise à jour dans les données de variation
        return $file_url;
    }
    
    /**
     * Supprimer le fichier GCP quand le fichier local est supprimé
     * Hook appelé quand un attachment est supprimé de la bibliothèque des médias
     */
    public function handle_attachment_deletion($attachment_id) {
        // Vérifier si c'est un fichier Pixnime
        $post = get_post($attachment_id);
        if (!$post || $post->post_type !== 'attachment') {
            return;
        }
        
        // Vérifier si c'est un fichier Pixnime par le titre
        if (strpos($post->post_title, 'Pixnime') === false) {
            return;
        }
        
        $this->log('Pixnime attachment deleted from media library:', $attachment_id);
        
        // Ici vous pourriez ajouter la logique pour supprimer le fichier GCP
        // Par exemple, appeler un endpoint de suppression sur votre serveur mars.pixnime.com
        // $this->delete_gcp_file($gcp_url);
        
        $this->log('Note: GCP file deletion not implemented yet');
    }
    
    /**
     * Ajouter une image de la bibliothèque des médias au workspace
     */
    public function add_image_to_workspace() {
        $this->log('add_image_to_workspace called');
        
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            $this->log('Nonce verification failed for add_image_to_workspace');
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        $user_id = get_current_user_id();
        $image_url = isset($_POST['image_url']) ? sanitize_url($_POST['image_url']) : '';
        $attachment_id = isset($_POST['attachment_id']) ? intval($_POST['attachment_id']) : 0;
        $avatar_id = isset($_POST['avatar_id']) ? sanitize_text_field($_POST['avatar_id']) : '';
        $filename = isset($_POST['filename']) ? sanitize_text_field($_POST['filename']) : '';
        
        if (empty($image_url) || empty($avatar_id)) {
            wp_send_json_error(__('Missing data', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'));
            return;
        }
        
        // Vérifier que l'utilisateur n'a pas déjà un avatar dans le workspace
        $current_avatar = get_user_meta($user_id, 'pixnime_avatar_url', true);
        $avatar_variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
        
        if (!empty($current_avatar) || !empty($avatar_variations)) {
            wp_send_json_error(__('Votre workspace contient déjà des images. Veuillez le vider avant d\'ajouter une nouvelle image.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'));
            return;
        }
        
        // Sauvegarder l'image comme avatar principal
        update_user_meta($user_id, 'pixnime_avatar_url', $image_url);
        update_user_meta($user_id, 'pixnime_avatar_id', $avatar_id);
        update_user_meta($user_id, 'pixnime_avatar_prompt', ''); // Prompt vide
        update_user_meta($user_id, 'pixnime_avatar_attachment_id', $attachment_id);
        update_user_meta($user_id, 'pixnime_avatar_filename', $filename);
        
        $this->log('Image from library added to workspace:', array(
            'user_id' => $user_id,
            'avatar_id' => $avatar_id,
            'image_url' => $image_url,
            'attachment_id' => $attachment_id,
            'filename' => $filename
        ));
        
        wp_send_json_success(array(
            'message' => 'Image added to workspace successfully',
            'avatar_id' => $avatar_id,
            'image_url' => $image_url,
            'filename' => $filename
        ));
    }

    /**
     * Appliquer un watermark sur une image selon les paramètres des settings
     * 
     * @param string $image_path Chemin vers l'image source
     * @param string $output_path Chemin vers l'image de sortie (optionnel, sinon remplace l'original)
     * @return bool True si le watermark a été appliqué avec succès
     */
    private function apply_watermark_to_image($image_path, $output_path = null) {
        // Récupérer les paramètres de watermark
        $settings = get_option('pixnime_pro_settings', array());
        $watermark_position = $settings['watermark_position'] ?? 'none';
        $watermark_image_url = $settings['watermark_image_url'] ?? '';
        $watermark_opacity = $settings['watermark_opacity'] ?? 50;
        
        // Si pas de watermark ou position 'none', ne rien faire
        if ($watermark_position === 'none' || empty($watermark_image_url)) {
            $this->log('Watermark désactivé ou image manquante, pas de watermark appliqué');
            return true;
        }
        
        // Vérifier que l'image source existe
        if (!file_exists($image_path)) {
            $this->log('Image source introuvable:', $image_path);
            return false;
        }
        
        // Télécharger l'image de watermark
        $watermark_response = wp_remote_get($watermark_image_url);
        if (is_wp_error($watermark_response)) {
            $this->log('Erreur téléchargement watermark:', $watermark_response->get_error_message());
            return false;
        }
        
        $watermark_data = wp_remote_retrieve_body($watermark_response);
        if (empty($watermark_data)) {
            $this->log('Données watermark vides');
            return false;
        }
        
        // Créer un fichier temporaire pour le watermark
        $temp_watermark_path = wp_tempnam('pixnime_watermark_');
        if (!file_put_contents($temp_watermark_path, $watermark_data)) {
            $this->log('Erreur création fichier temporaire watermark');
            return false;
        }
        
        // Charger l'image source
        $source_image = imagecreatefromstring(file_get_contents($image_path));
        if (!$source_image) {
            $this->log('Erreur chargement image source');
            wp_delete_file($temp_watermark_path);
            return false;
        }
        
        // Charger l'image watermark
        $watermark_image = imagecreatefromstring($watermark_data);
        if (!$watermark_image) {
            $this->log('Erreur chargement image watermark');
            imagedestroy($source_image);
            wp_delete_file($temp_watermark_path);
            return false;
        }
        
        // Obtenir les dimensions
        $source_width = imagesx($source_image);
        $source_height = imagesy($source_image);
        $watermark_width = imagesx($watermark_image);
        $watermark_height = imagesy($watermark_image);
        
        // Utiliser la taille originale du watermark, sauf si elle dépasse la taille de l'image source
        if ($watermark_width > $source_width || $watermark_height > $source_height) {
            // Redimensionner pour que ça rentre dans l'image source
            $scale = min($source_width / $watermark_width, $source_height / $watermark_height, 1);
            $new_watermark_width = (int)($watermark_width * $scale);
            $new_watermark_height = (int)($watermark_height * $scale);

            $resized_watermark = imagecreatetruecolor($new_watermark_width, $new_watermark_height);
            imagealphablending($resized_watermark, false);
            imagesavealpha($resized_watermark, true);
            $transparent = imagecolorallocatealpha($resized_watermark, 255, 255, 255, 127);
            imagefill($resized_watermark, 0, 0, $transparent);

            imagecopyresampled(
                $resized_watermark, $watermark_image,
                0, 0, 0, 0,
                $new_watermark_width, $new_watermark_height,
                $watermark_width, $watermark_height
            );
        } else {
            // Pas de redimensionnement
            $new_watermark_width = $watermark_width;
            $new_watermark_height = $watermark_height;
            $resized_watermark = $watermark_image;
        }
        
        // Calculer la position du watermark
        $watermark_x = 0;
        $watermark_y = 0;
        
        switch ($watermark_position) {
            case 'center':
                $watermark_x = ($source_width - $new_watermark_width) / 2;
                $watermark_y = ($source_height - $new_watermark_height) / 2;
                break;
            case 'center-bottom':
                $watermark_x = ($source_width - $new_watermark_width) / 2;
                $watermark_y = $source_height - $new_watermark_height - 10;
                break;
            case 'center-top':
                $watermark_x = ($source_width - $new_watermark_width) / 2;
                $watermark_y = 10;
                break;
            case 'bottom-right':
                $watermark_x = $source_width - $new_watermark_width - 10;
                $watermark_y = $source_height - $new_watermark_height - 10;
                break;
            case 'bottom-left':
                $watermark_x = 10;
                $watermark_y = $source_height - $new_watermark_height - 10;
                break;
            case 'top-right':
                $watermark_x = $source_width - $new_watermark_width - 10;
                $watermark_y = 10;
                break;
            case 'top-left':
                $watermark_x = 10;
                $watermark_y = 10;
                break;
        }
        
        // Appliquer l'opacité
        $opacity = $watermark_opacity / 100;
        
        // Copier le watermark sur l'image source avec opacité
        $this->imagecopymerge_alpha($source_image, $resized_watermark, $watermark_x, $watermark_y, 0, 0, $new_watermark_width, $new_watermark_height, $opacity);
        
        // Sauvegarder l'image avec watermark
        $output_file = $output_path ?: $image_path;
        $success = imagepng($source_image, $output_file);
        
        // Nettoyer la mémoire
        imagedestroy($source_image);
        imagedestroy($watermark_image);
        imagedestroy($resized_watermark);
        wp_delete_file($temp_watermark_path);
        
        if ($success) {
            $this->log('Watermark appliqué avec succès sur:', $output_file);
            return true;
        } else {
            $this->log('Erreur sauvegarde image avec watermark');
            return false;
        }
    }
    
    /**
     * Fonction helper pour copier une image avec transparence et opacité
     * 
     * @param resource $dst_im Image de destination
     * @param resource $src_im Image source
     * @param int $dst_x X destination
     * @param int $dst_y Y destination
     * @param int $src_x X source
     * @param int $src_y Y source
     * @param int $src_w Largeur source
     * @param int $src_h Hauteur source
     * @param float $opacity Opacité (0.0 à 1.0)
     */
    private function imagecopymerge_alpha($dst_im, $src_im, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $opacity) {
        // Créer une image temporaire pour le watermark avec opacité
        $temp_im = imagecreatetruecolor($src_w, $src_h);
        imagealphablending($temp_im, false);
        imagesavealpha($temp_im, true);
        
        // Copier le watermark dans l'image temporaire
        imagecopy($temp_im, $src_im, 0, 0, $src_x, $src_y, $src_w, $src_h);
        
        // Appliquer l'opacité pixel par pixel
        for ($x = 0; $x < $src_w; $x++) {
            for ($y = 0; $y < $src_h; $y++) {
                $color = imagecolorat($temp_im, $x, $y);
                $alpha = ($color >> 24) & 0xFF;
                $red = ($color >> 16) & 0xFF;
                $green = ($color >> 8) & 0xFF;
                $blue = $color & 0xFF;
                
                // Appliquer l'opacité
                $new_alpha = (int)($alpha * $opacity);
                $new_color = imagecolorallocatealpha($temp_im, $red, $green, $blue, $new_alpha);
                imagesetpixel($temp_im, $x, $y, $new_color);
            }
        }
        
        // Copier l'image temporaire sur l'image de destination
        imagecopy($dst_im, $temp_im, $dst_x, $dst_y, 0, 0, $src_w, $src_h);
        
        // Nettoyer
        imagedestroy($temp_im);
    }

    /**
     * Tester l'application du watermark sur une image existante
     */
    public function test_watermark() {
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_nonce', 'nonce', false)) {
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        // Vérifier les permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Récupérer l'ID de l'image de test
        $test_image_id = isset($_POST['test_image_id']) ? intval($_POST['test_image_id']) : 0;
        
        if ($test_image_id <= 0) {
            wp_send_json_error('ID d\'image de test invalide');
            return;
        }
        
        // Récupérer le chemin de l'image
        $test_image_path = get_attached_file($test_image_id);
        if (!$test_image_path || !file_exists($test_image_path)) {
            wp_send_json_error('Image de test introuvable');
            return;
        }
        
        // Créer un chemin temporaire pour l'image avec watermark
        $upload_dir = wp_upload_dir();
        $temp_filename = 'pixnime_watermark_test_' . time() . '.png';
        $temp_path = $upload_dir['path'] . '/' . $temp_filename;
        
        // Appliquer le watermark
        $this->log('Test d\'application du watermark sur:', $test_image_path);
        $watermark_applied = $this->apply_watermark_to_image($test_image_path, $temp_path);
        
        if ($watermark_applied && file_exists($temp_path)) {
            // Créer l'URL de l'image avec watermark
            $temp_url = $upload_dir['url'] . '/' . $temp_filename;
            
            wp_send_json_success(array(
                'message' => 'Watermark appliqué avec succès',
                'test_image_url' => $temp_url,
                'original_image_path' => $test_image_path,
                'watermarked_image_path' => $temp_path
            ));
        } else {
            wp_send_json_error('Erreur lors de l\'application du watermark');
        }
    }

    /**
     * Obtenir le texte du style pour la validation côté serveur
     */
    private function get_style_text($style_preset) {
        $styles = [
            '2d_cartoon' => __('Flat illustration with crisp lines, bright color blocks and minimal shading, ideal for a cheerful and accessible style.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            '3d_cartoon' => __('Stylized 3D characters with soft textures and playful lighting, inspired by semi-realistic 3D cartoons like Pixar or DreamWorks.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'flat_vector' => __('Clean style with simple geometric shapes and uniform palette, perfect for modern infographics and web interfaces.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'cel_shading' => __('3D rendering with flat shading imitating cartoons, often used in stylized video games.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'stylized_illustration' => __('A blend between realism and cartoon with expressive proportions and artistic textures.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'pencil_sketch' => __('Pencil sketch in gray or sepia, with a raw and lively look like a sketchbook.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'ink_drawing' => __('Inked drawings with strong outlines, typical of comics or black and white illustrations.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'watercolor' => __('Watercolor painting effect with transparency, soft gradients and poetic atmosphere.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'charcoal' => __('Grainy illustration in black and white or warm tones, with a raw texture like charcoal.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'ultra_realistic' => __('Very photo-like rendering with extreme detail level, ideal for striking natural or human scenes.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            '4k_photorealism' => __('Very high definition image, true to reality, with perfectly calibrated textures, shadows and lights.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'cinematic' => __('Realistic image inspired by film framing and lighting, with a dramatic or immersive atmosphere.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'low_poly' => __('Simplified geometric style with few polygons, giving a stylized 3D look, often used in video games or data visualization.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'pixel_art' => __('Retro illustration made of visible pixels, reminiscent of 80s-90s video games.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'isometric' => __('Perspective without vanishing point with fixed angle, perfect for maps, buildings or complex systems.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'line_art' => __('Illustration made only of lines, with or without fill, for a minimalist and elegant rendering.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'),
            'papercut' => __('Style imitating paper cutouts in superimposed layers, with a stylized and playful depth effect.', 'pixnime-pro-ai-character-and-illustrations-consistency-generator')
        ];
        return isset($styles[$style_preset]) ? $styles[$style_preset] : '';
    }

    /**
     * Retourne l'URL de base de l'API Pixnime selon la configuration
     */
    private function get_pixnime_api_base_url() {
        // Détection automatique basée sur le domaine d'origine
        $current_domain = $_SERVER['HTTP_HOST'] ?? '';
        
        // Logique de détection par domaine
        if (strpos($current_domain, 'coprosereine.com') !== false) {
            return 'https://www.pixnime.com';
        }
        
        if (strpos($current_domain, 'juliab40.sg-host.com') !== false) {
            return 'https://io.pixnime.com';
        }
        
        // Fallback vers la logique SSL/HTTPS pour les autres domaines
        if (is_ssl()) {
            return 'https://io.pixnime.com';
        } else {
            return 'http://mars.pixnime.com:8080';
        }
    }
} 
/**
 * Pixnime Pro - Utility Functions
 * Fonctions utilitaires pour le plugin
 */

(function($) {
    'use strict';

    // Namespace pour les fonctions utilitaires
    window.PixnimeUtils = {
        
        /**
         * Combiner la description avec le style
         */
        combineDescriptionWithStyle: function(description, stylePreset) {
            if (!description || !stylePreset || stylePreset === 'none') {
                return description;
            }
            
            // Textes des styles disponibles dans pixnimeProL10n
            var styleTexts = {
                '2d_cartoon': pixnimeProL10n.style_2d_cartoon || '',
                '3d_cartoon': pixnimeProL10n.style_3d_cartoon || '',
                'flat_vector': pixnimeProL10n.style_flat_vector || '',
                'cel_shading': pixnimeProL10n.style_cel_shading || '',
                'stylized_illustration': pixnimeProL10n.style_stylized_illustration || '',
                'pencil_sketch': pixnimeProL10n.style_pencil_sketch || '',
                'ink_drawing': pixnimeProL10n.style_ink_drawing || '',
                'watercolor': pixnimeProL10n.style_watercolor || '',
                'charcoal': pixnimeProL10n.style_charcoal || '',
                'ultra_realistic': pixnimeProL10n.style_ultra_realistic || '',
                '4k_photorealism': pixnimeProL10n.style_4k_photorealism || '',
                'cinematic': pixnimeProL10n.style_cinematic || '',
                'low_poly': pixnimeProL10n.style_low_poly || '',
                'pixel_art': pixnimeProL10n.style_pixel_art || '',
                'isometric': pixnimeProL10n.style_isometric || '',
                'line_art': pixnimeProL10n.style_line_art || '',
                'papercut': pixnimeProL10n.style_papercut || ''
            };
            
            var styleText = styleTexts[stylePreset] || '';
            
            if (styleText) {
                return description + '. Style: ' + styleText;
            }
            
            return description;
        },

        /**
         * Afficher le prompt final formaté
         */
        displayFinalPrompt: function(prompt) {
            var $display = $('.final-prompt-display');
            if ($display.length === 0) {
                $display = $('<div class="final-prompt-display" style="margin: 10px 0; padding: 10px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;"></div>');
                $('#avatar_description').after($display);
            }
            
            $display.html('<strong>Prompt final:</strong> ' + prompt);
        },

        /**
         * Valider un email
         */
        validateEmail: function(email) {
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        },

        /**
         * Formater un nombre de crédits
         */
        formatCredits: function(credits) {
            if (credits === undefined || credits === null) {
                return 'N/A';
            }
            
            if (credits >= 1000000) {
                return (credits / 1000000).toFixed(1) + 'M';
            } else if (credits >= 1000) {
                return (credits / 1000).toFixed(1) + 'K';
            }
            
            return credits.toString();
        },

        /**
         * Générer un timestamp lisible
         */
        formatTimestamp: function(timestamp) {
            if (!timestamp) {
                return '';
            }
            
            var date = new Date(timestamp * 1000);
            return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        },

        /**
         * Nettoyer une chaîne de caractères
         */
        sanitizeString: function(str) {
            if (!str) {
                return '';
            }
            
            return str.replace(/[<>]/g, '').trim();
        },

        /**
         * Vérifier si une URL est valide
         */
        isValidUrl: function(url) {
            try {
                new URL(url);
                return true;
            } catch (e) {
                return false;
            }
        },

        /**
         * Obtenir les paramètres d'URL
         */
        getUrlParams: function() {
            var params = {};
            var urlParams = new URLSearchParams(window.location.search);
            
            for (let [key, value] of urlParams) {
                params[key] = value;
            }
            
            return params;
        },

        /**
         * Mettre à jour un paramètre d'URL sans rechargement
         */
        updateUrlParam: function(key, value) {
            var url = new URL(window.location.href);
            
            if (value) {
                url.searchParams.set(key, value);
            } else {
                url.searchParams.delete(key);
            }
            
            history.replaceState(null, '', url.href);
        },

        /**
         * Afficher/masquer un élément avec animation
         */
        toggleElement: function($element, show) {
            if (show) {
                $element.slideDown(300);
            } else {
                $element.slideUp(300);
            }
        },

        /**
         * Créer une notification temporaire
         */
        showNotification: function(message, type, duration) {
            type = type || 'info';
            duration = duration || 3000;
            
            var $notification = $('<div class="pixnime-notification notice notice-' + type + '">' +
                '<p>' + message + '</p>' +
                '</div>');
            
            $('body').append($notification);
            
            $notification.css({
                position: 'fixed',
                top: '20px',
                right: '20px',
                zIndex: 999999,
                maxWidth: '400px'
            }).hide().fadeIn(300);
            
            setTimeout(function() {
                $notification.fadeOut(300, function() {
                    $(this).remove();
                });
            }, duration);
        },

        /**
         * Initialisation des utilitaires
         */
        init: function() {
            console.log('Pixnime Pro Utils JS loaded');
        }
    };

    // Initialisation des utilitaires
    $(document).ready(function() {
        PixnimeUtils.init();
    });

})(jQuery); 
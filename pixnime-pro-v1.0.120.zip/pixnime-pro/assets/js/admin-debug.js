/**
 * Pixnime Pro - Debug & Diagnostic Functions
 * Fonctions de diagnostic et debug pour le plugin
 */

(function($) {
    'use strict';

    // Namespace pour les fonctions de debug
    window.PixnimeDebug = {
        
        /**
         * Diagnostic complet du bouton de génération
         */
        diagnosticButtonState: function() {
            console.log('=== DIAGNOSTIC DU BOUTON GENERATE ===');
            var $btn = $('#generate-avatar-btn');
            
            console.log('1. Bouton existe:', $btn.length > 0);
            console.log('2. Bouton désactivé:', $btn.prop('disabled'));
            console.log('3. Texte du bouton:', $btn.text());
            
            // Vérifier les conditions du workspace
            var hasCurrentAvatar = $('.main-avatar-image').length > 0;
            var hasVariations = $('.variation-card').length > 0;
            console.log('4. Workspace - Avatar principal:', hasCurrentAvatar);
            console.log('5. Workspace - Variations:', hasVariations);
            console.log('6. Workspace bloqué:', hasCurrentAvatar || hasVariations);
            
            // Vérifier les clés API
            var apiKey = pixnimeProL10n.api_key || '';
            var openaiKey = pixnimeProL10n.openai_key || '';
            console.log('7. Clé API Pixnime:', apiKey ? 'PRÉSENTE' : 'ABSENTE');
            console.log('8. Clé OpenAI:', openaiKey ? 'PRÉSENTE' : 'ABSENTE');
            
            // Vérifier si au moins une clé est configurée
            var hasAnyKey = apiKey || openaiKey;
            console.log('9. Au moins une clé configurée:', hasAnyKey);
            
            // Vérifier l'état du formulaire
            var $form = $('#pixnime-generate-form');
            console.log('10. Formulaire présent:', $form.length > 0);
            
            // Vérifier les event listeners
            var events = $._data($btn[0], 'events');
            console.log('11. Event listeners sur le bouton:', events);
            
            // Recommandations
            console.log('=== RECOMMANDATIONS ===');
            if (hasCurrentAvatar || hasVariations) {
                console.log('→ PROBLÈME: Le workspace n\'est pas vide. Utilisez "Clear workspace" pour permettre une nouvelle génération.');
            }
            if (!hasAnyKey) {
                console.log('→ PROBLÈME: Aucune clé API configurée. Allez dans les paramètres pour configurer une clé.');
            }
            if ($btn.prop('disabled')) {
                console.log('→ PROBLÈME: Le bouton est désactivé. Cela peut être dû à une erreur précédente.');
            }
            console.log('=====================================');
        },

        /**
         * Diagnostic du bouton de génération de variations
         */
        diagnosticVariationButton: function() {
            console.log('=== DIAGNOSTIC BOUTON VARIATION ===');
            var $btn = $('#generate-variation-btn');
            var $promptField = $('#variation_prompt');
            
            console.log('1. Bouton variation existe:', $btn.length > 0);
            console.log('2. Bouton variation désactivé:', $btn.prop('disabled'));
            console.log('3. Champ prompt variation existe:', $promptField.length > 0);
            console.log('4. Valeur du prompt:', $promptField.val());
            console.log('5. Avatar principal présent:', $('.main-avatar-image').length > 0);
            
            if ($btn.length === 0) {
                console.log('→ PROBLÈME: Bouton variation non trouvé - vérifiez que vous avez un avatar principal');
            }
            if ($promptField.length === 0) {
                console.log('→ PROBLÈME: Champ prompt variation non trouvé');
            }
            if ($('.main-avatar-image').length === 0) {
                console.log('→ PROBLÈME: Pas d\'avatar principal - générez d\'abord un avatar');
            }
            console.log('====================================');
        },

        /**
         * Forcer la réactivation du bouton de génération
         */
        forceEnableButton: function() {
            console.log('Forcer la réactivation du bouton generate...');
            var $btn = $('#generate-avatar-btn');
            $btn.prop('disabled', false).text('Generate Avatar');
            console.log('Bouton réactivé avec succès !');
        },

        /**
         * Forcer la réactivation du bouton de variation
         */
        forceEnableVariationButton: function() {
            console.log('Forcer la réactivation du bouton variation...');
            var $btn = $('#generate-variation-btn');
            $btn.prop('disabled', false).text('Generate');
            console.log('Bouton variation réactivé avec succès !');
        },

        /**
         * Diagnostic général du plugin
         */
        diagnosticGeneral: function() {
            console.log('=== DIAGNOSTIC GÉNÉRAL PIXNIME PRO ===');
            console.log('jQuery version:', $.fn.jquery);
            console.log('AJAX URL:', pixnimeProL10n.ajax_url);
            console.log('Nonce:', pixnimeProL10n.nonce);
            console.log('Formulaire principal:', $('#pixnime-generate-form').length > 0);
            console.log('Workspace actuel:', {
                avatarPrincipal: $('.main-avatar-image').length,
                variations: $('.variation-card').length
            });
            console.log('====================================');
        },

        /**
         * Initialisation des diagnostics
         */
        init: function() {
            console.log('Pixnime Pro Admin Debug JS loaded');
            console.log('DEBUG - pixnime_ajax:', pixnimeProL10n.ajax_url);
            console.log('DEBUG - API Key:', pixnimeProL10n.api_key || 'VIDE');
            console.log('DEBUG - OpenAI Key:', pixnimeProL10n.openai_key || 'VIDE');
            
            // Debug avancé de la variable pixnimeProL10n
            console.log('=== DEBUG AVANCÉ PIXNIME ===');
            console.log('Type de pixnimeProL10n:', typeof pixnimeProL10n);
            console.log('pixnimeProL10n existe:', typeof pixnimeProL10n !== 'undefined');
            if (typeof pixnimeProL10n !== 'undefined') {
                console.log('Contenu complet de pixnimeProL10n:', pixnimeProL10n);
                console.log('Clé API dans pixnimeProL10n:', pixnimeProL10n.api_key);
                console.log('Longueur de la clé API:', pixnimeProL10n.api_key ? pixnimeProL10n.api_key.length : 0);
            } else {
                console.error('ERREUR: pixnimeProL10n n\'est pas définie !');
            }
            console.log('==============================');
            
            // Debug: Vérifier que le formulaire existe
            console.log('DEBUG - Formulaire trouvé:', $('#pixnime-generate-form').length);
            console.log('DEBUG - Bouton trouvé:', $('#generate-avatar-btn').length);
            
            // Debug: Vérifier que jQuery fonctionne
            console.log('DEBUG - jQuery version:', $.fn.jquery);
            
            // Lancer le diagnostic au chargement
            setTimeout(this.diagnosticButtonState, 1000);
            
            // Ajouter les fonctions globales
            window.pixnimeForceEnableButton = this.forceEnableButton;
            window.pixnimeForceEnableVariationButton = this.forceEnableVariationButton;
            window.pixnimeDiagnosticGeneral = this.diagnosticGeneral;
            
            // Messages d'aide
            console.log('💡 Commandes disponibles dans la console:');
            console.log('   - pixnimeForceEnableButton() : Réactiver le bouton principal');
            console.log('   - pixnimeForceEnableVariationButton() : Réactiver le bouton variation');
            console.log('   - pixnimeDiagnosticGeneral() : Diagnostic général');
        }
    };

    // Gestionnaires d'événements pour le diagnostic
    $(document).ready(function() {
        PixnimeDebug.init();
        
        // Lancer le diagnostic quand on clique sur le bouton
        $('#generate-avatar-btn').on('click', function(e) {
            console.log('Clic sur le bouton generate - Lancement du diagnostic...');
            PixnimeDebug.diagnosticButtonState();
        });
        
        // Diagnostic variations au clic
        $(document).on('click', '#generate-variation-btn', function(e) {
            console.log('Clic sur bouton variation - Diagnostic...');
            PixnimeDebug.diagnosticVariationButton();
        });
    });

})(jQuery); 
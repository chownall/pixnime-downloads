<?php
/**
 * Uninstall script for Pixnime Pro plugin
 * 
 * This file is executed when the plugin is uninstalled through WordPress admin.
 * It cleans up all plugin data according to WordPress best practices.
 * 
 * IMPORTANT: Les avatars générés et leurs fichiers sont CONSERVÉS dans la médiathèque
 * WordPress pour permettre à l'utilisateur de les garder même après désinstallation.
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

// Empêcher l'accès direct
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// S'assurer que WordPress est chargé
if (!defined('ABSPATH')) {
    exit;
}

// Remove all direct core file includes - WordPress will autoload these functions
// The uninstall script runs in WordPress context, so all functions are available

// Vérifier que l'utilisateur a les permissions nécessaires
if (!current_user_can('delete_plugins')) {
    return;
}

// Initialiser WP_Filesystem
global $wp_filesystem;
if (empty($wp_filesystem)) {
    require_once(ABSPATH . '/wp-admin/includes/file.php');
    if (function_exists('WP_Filesystem')) {
        WP_Filesystem();
    }
}

// Fonction de log pour le debug (peut être désactivée en production)
function pixnime_log_uninstall($message, $data = null) {
    if (WP_DEBUG && WP_DEBUG_LOG) {
        error_log('Pixnime Pro Uninstall: ' . $message);
        if ($data !== null) {
            error_log('Pixnime Pro Uninstall Data: ' . print_r($data, true));
        }
    }
}

pixnime_log_uninstall('Début de la désinstallation du plugin Pixnime Pro');

/**
 * 1. NETTOYAGE DES OPTIONS WORDPRESS
 */
pixnime_log_uninstall('Suppression des options WordPress');

$options_to_delete = array(
    'pixnime_pro_settings',           // Paramètres principaux (clé API, clé OpenAI, watermark)
    'pixnime_credit_usage_log',       // Historique d'utilisation des crédits
    'pixnime_total_credits_used',     // Compteur total des crédits utilisés
    'widget_pixnime_pro_widget',      // Configuration du widget
);

foreach ($options_to_delete as $option) {
    $deleted = delete_option($option);
    pixnime_log_uninstall("Option '$option' supprimée: " . ($deleted ? 'OUI' : 'NON'));
}

/**
 * 2. NETTOYAGE DES MÉTADONNÉES UTILISATEUR
 */
pixnime_log_uninstall('Suppression des métadonnées utilisateur');

$user_meta_keys = array(
    'pixnime_avatar_url',             // URL de l'avatar principal
    'pixnime_avatar_prompt',          // Prompt utilisé pour générer l'avatar
    'pixnime_avatar_id',              // ID de l'avatar
    'pixnime_avatar_variations',      // Variations d'avatar
    'pixnime_avatar_attachment_id',   // ID de l'attachment dans la médiathèque
    'pixnime_avatar_filename',        // Nom du fichier
    'pixnime_variation_attachment_id', // ID des attachments des variations
    'pixnime_user_id',                // ID utilisateur Pixnime
    'pixnime_last_prompt',            // Dernier prompt utilisé
);

// Récupérer tous les utilisateurs
$users = get_users(array('fields' => 'ID'));
$users_cleaned = 0;
$total_meta_deleted = 0;

foreach ($users as $user_id) {
    $user_meta_deleted = 0;
    
    foreach ($user_meta_keys as $meta_key) {
        $deleted = delete_user_meta($user_id, $meta_key);
        if ($deleted) {
            $user_meta_deleted++;
            $total_meta_deleted++;
        }
    }
    
    if ($user_meta_deleted > 0) {
        $users_cleaned++;
        pixnime_log_uninstall("Utilisateur $user_id: $user_meta_deleted métadonnées supprimées");
    }
}

pixnime_log_uninstall("Total: $users_cleaned utilisateurs nettoyés, $total_meta_deleted métadonnées supprimées");

/**
 * 3. NETTOYAGE DES FICHIERS PHYSIQUES
 * 
 * COMMENTÉ: Les fichiers d'avatars sont conservés dans la médiathèque
 * pour permettre à l'utilisateur de les garder même après désinstallation
 */
pixnime_log_uninstall('Conservation des fichiers physiques dans la médiathèque');

$upload_dir = wp_upload_dir();
$upload_path = $upload_dir['basedir'];

$files_deleted = 0;

// Nettoyer UNIQUEMENT les fichiers temporaires de watermark
if ($wp_filesystem->is_dir($upload_path)) {
    $temp_files = glob($upload_path . '/pixnime_watermark_*');
    if ($temp_files) {
        foreach ($temp_files as $file) {
            if ($wp_filesystem->exists($file) && $wp_filesystem->delete($file)) {
                $files_deleted++;
                pixnime_log_uninstall("Fichier temporaire supprimé: " . basename($file));
            }
        }
    }
}

pixnime_log_uninstall("$files_deleted fichiers temporaires supprimés (avatars conservés)");

/*
// Section commentée - Suppression des fichiers d'avatars
// Décommentez si vous voulez supprimer tous les fichiers d'avatars

if ($wp_filesystem->is_dir($upload_path)) {
    // Patterns des fichiers à supprimer
    $file_patterns = array(
        'pixnime_avatar_*.png',
        'pixnime_avatar_*.jpg',
        'pixnime_avatar_*.jpeg',
        'pixnime_variation_*.png',
        'pixnime_variation_*.jpg',
        'pixnime_variation_*.jpeg',
    );
    
    foreach ($file_patterns as $pattern) {
        $files = glob($upload_path . '/' . $pattern);
        if ($files) {
            foreach ($files as $file) {
                if ($wp_filesystem->exists($file) && $wp_filesystem->delete($file)) {
                    $files_deleted++;
                    pixnime_log_uninstall("Fichier supprimé: " . basename($file));
                }
            }
        }
    }
}
*/

/**
 * 4. NETTOYAGE DES ATTACHMENTS DANS LA MÉDIATHÈQUE
 * 
 * COMMENTÉ: Les attachments sont conservés dans la médiathèque WordPress
 * pour permettre à l'utilisateur de garder ses avatars générés
 */
pixnime_log_uninstall('Conservation des attachments dans la médiathèque');

global $wpdb;

// Compter les attachments créés par le plugin pour information
$attachments = $wpdb->get_results(
    "SELECT ID FROM {$wpdb->posts} 
     WHERE post_type = 'attachment' 
     AND (post_title LIKE 'Pixnime Avatar%' OR post_title LIKE 'Pixnime Variation%')"
);

$attachments_count = count($attachments);
$attachments_deleted = 0; // Aucun attachment supprimé

pixnime_log_uninstall("$attachments_count attachments Pixnime conservés dans la médiathèque");

/*
// Section commentée - Suppression des attachments
// Décommentez si vous voulez supprimer tous les attachments du plugin

foreach ($attachments as $attachment) {
    // Supprimer l'attachment et ses métadonnées
    $deleted = wp_delete_attachment($attachment->ID, true);
    if ($deleted) {
        $attachments_deleted++;
        pixnime_log_uninstall("Attachment supprimé: ID " . $attachment->ID);
    }
}
*/

/**
 * 5. NETTOYAGE DES TRANSIENTS
 */
pixnime_log_uninstall('Suppression des transients');

$transients_to_delete = array(
    'pixnime_pro_credits_check',
    'pixnime_pro_api_status',
    'pixnime_pro_user_info',
);

$transients_deleted = 0;

foreach ($transients_to_delete as $transient) {
    if (delete_transient($transient)) {
        $transients_deleted++;
        pixnime_log_uninstall("Transient supprimé: $transient");
    }
}

pixnime_log_uninstall("$transients_deleted transients supprimés");

/**
 * 6. NETTOYAGE DES WIDGETS
 */
pixnime_log_uninstall('Suppression des widgets');

// Désactiver le widget de toutes les sidebars
$sidebars_widgets = wp_get_sidebars_widgets();
$widget_instances_removed = 0;

if (is_array($sidebars_widgets)) {
    foreach ($sidebars_widgets as $sidebar => $widgets) {
        if (is_array($widgets)) {
            foreach ($widgets as $key => $widget) {
                if (strpos($widget, 'pixnime_pro_widget') === 0) {
                    unset($sidebars_widgets[$sidebar][$key]);
                    $widget_instances_removed++;
                    pixnime_log_uninstall("Widget supprimé de sidebar '$sidebar': $widget");
                }
            }
        }
    }
    
    if ($widget_instances_removed > 0 && function_exists('wp_set_sidebars_widgets')) {
        wp_set_sidebars_widgets($sidebars_widgets);
        pixnime_log_uninstall("$widget_instances_removed instances de widget supprimées");
    }
}

/**
 * 7. NETTOYAGE DES CACHES
 */
pixnime_log_uninstall('Nettoyage des caches');

// Nettoyer les caches WordPress
if (function_exists('wp_cache_flush')) {
    wp_cache_flush();
    pixnime_log_uninstall('Cache WordPress nettoyé');
}

// Nettoyer les caches d'objets
if (function_exists('wp_cache_delete')) {
    wp_cache_delete('alloptions', 'options');
    pixnime_log_uninstall('Cache des options nettoyé');
}

/**
 * 8. NETTOYAGE DES LOGS D'ERREURS SPÉCIFIQUES
 */
pixnime_log_uninstall('Nettoyage des logs d\'erreurs');

// Nettoyer les logs d'erreurs qui contiennent "Pixnime"
// Utiliser wp_upload_dir() pour déterminer le chemin du dossier wp-content
$upload_dir = wp_upload_dir();
$log_file = dirname($upload_dir['basedir']) . '/debug.log';
if ($wp_filesystem->exists($log_file) && $wp_filesystem->is_writable($log_file)) {
    $log_content = $wp_filesystem->get_contents($log_file);
    if ($log_content !== false) {
        $lines = explode("\n", $log_content);
        $cleaned_lines = array();
        $lines_removed = 0;
        
        foreach ($lines as $line) {
            if (strpos($line, 'Pixnime') === false) {
                $cleaned_lines[] = $line;
            } else {
                $lines_removed++;
            }
        }
        
        if ($lines_removed > 0) {
            $wp_filesystem->put_contents($log_file, implode("\n", $cleaned_lines));
            pixnime_log_uninstall("$lines_removed lignes de logs Pixnime supprimées");
        }
    }
}

/**
 * 9. NETTOYAGE DES TABLES PERSONNALISÉES (si elles existent)
 */
pixnime_log_uninstall('Vérification des tables personnalisées');

// Le plugin n'utilise pas de tables personnalisées actuellement,
// mais on vérifie au cas où des versions futures en auraient créé
$custom_tables = array(
    $wpdb->prefix . 'pixnime_avatars',
    $wpdb->prefix . 'pixnime_generations',
    $wpdb->prefix . 'pixnime_usage_stats',
);

$tables_dropped = 0;

foreach ($custom_tables as $table) {
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
    if ($table_exists) {
        $wpdb->query("DROP TABLE IF EXISTS $table");
        $tables_dropped++;
        pixnime_log_uninstall("Table personnalisée supprimée: $table");
    }
}

if ($tables_dropped === 0) {
    pixnime_log_uninstall('Aucune table personnalisée trouvée');
}

/**
 * 10. NETTOYAGE FINAL ET RAPPORT
 */
pixnime_log_uninstall('Nettoyage final');

// Supprimer les répertoires temporaires créés par le plugin
$temp_dirs = array(
    $upload_dir['basedir'] . '/pixnime-temp/',
    $upload_dir['basedir'] . '/pixnime-cache/',
);

$dirs_removed = 0;

foreach ($temp_dirs as $dir) {
    if ($wp_filesystem->is_dir($dir)) {
        // Utiliser WP_Filesystem pour supprimer récursivement le répertoire
        if ($wp_filesystem->rmdir($dir, true)) {
            $dirs_removed++;
            pixnime_log_uninstall("Répertoire supprimé: $dir");
        }
    }
}

// Rapport final
$total_cleaned = array(
    'options' => count($options_to_delete),
    'users_cleaned' => $users_cleaned,
    'meta_deleted' => $total_meta_deleted,
    'temp_files_deleted' => $files_deleted ?? 0,
    'attachments_conserved' => $attachments_count ?? 0,
    'transients_deleted' => $transients_deleted,
    'widget_instances_removed' => $widget_instances_removed,
    'tables_dropped' => $tables_dropped,
    'dirs_removed' => $dirs_removed,
);

pixnime_log_uninstall('=== RAPPORT FINAL DE DÉSINSTALLATION ===');
pixnime_log_uninstall('Options supprimées: ' . $total_cleaned['options']);
pixnime_log_uninstall('Utilisateurs nettoyés: ' . $total_cleaned['users_cleaned']);
pixnime_log_uninstall('Métadonnées supprimées: ' . $total_cleaned['meta_deleted']);
pixnime_log_uninstall('Fichiers temporaires supprimés: ' . $total_cleaned['temp_files_deleted']);
pixnime_log_uninstall('Attachments conservés: ' . $total_cleaned['attachments_conserved']);
pixnime_log_uninstall('Transients supprimés: ' . $total_cleaned['transients_deleted']);
pixnime_log_uninstall('Widgets supprimés: ' . $total_cleaned['widget_instances_removed']);
pixnime_log_uninstall('Tables supprimées: ' . $total_cleaned['tables_dropped']);
pixnime_log_uninstall('Répertoires supprimés: ' . $total_cleaned['dirs_removed']);
pixnime_log_uninstall('=== FIN DE LA DÉSINSTALLATION ===');

/**
 * 11. NETTOYAGE OPTIONNEL - COMMENTÉ PAR DÉFAUT
 * 
 * Décommentez les sections suivantes si vous voulez un nettoyage plus agressif.
 * 
 * POUR SUPPRIMER COMPLÈTEMENT LES AVATARS:
 * 1. Décommentez la section 3 (fichiers physiques)
 * 2. Décommentez la section 4 (attachments médiathèque)  
 * 3. Optionnellement: décommentez les sections ci-dessous
 */

/*
// Supprimer TOUS les fichiers d'images dans uploads (ATTENTION: très agressif)
if (defined('PIXNIME_FORCE_CLEAN_ALL_IMAGES') && PIXNIME_FORCE_CLEAN_ALL_IMAGES) {
    $all_images = glob($upload_path . '/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
    foreach ($all_images as $image) {
        $image_meta = wp_get_attachment_metadata(attachment_url_to_postid($image));
        if (isset($image_meta['title']) && strpos($image_meta['title'], 'Pixnime') !== false) {
            $wp_filesystem->delete($image);
        }
    }
}

// Supprimer les entrées dans wp_postmeta liées au plugin
$wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE 'pixnime_%'");

// Supprimer les entrées dans wp_usermeta liées au plugin (déjà fait plus haut)
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'pixnime_%'");
*/

pixnime_log_uninstall('Désinstallation terminée avec succès'); 
<?php
/**
 * Widget class for Pixnime Pro
 * Classe vide pour éviter l'erreur fatale
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Pixnime_Pro_Widget extends WP_Widget {
    
    /**
     * Constructor
     */
    public function __construct() {
        parent::__construct(
            'pixnime_pro_widget',
            __('Pixnime Pro Avatar', 'pixnime-pro'),
            array(
                'description' => __('Display your AI generated avatar', 'pixnime-pro')
            )
        );
    }
    
    /**
     * Widget frontend display
     */
    public function widget($args, $instance) {
        echo wp_kses_post($args['before_widget']);
        
        if (!empty($instance['title'])) {
            echo wp_kses_post($args['before_title']) . wp_kses_post(apply_filters('widget_title', $instance['title'])) . wp_kses_post($args['after_title']);
        }
        
        // Afficher l'avatar de l'utilisateur
        $user_id = get_current_user_id();
        $avatar_url = get_user_meta($user_id, 'pixnime_avatar_url', true);
        
        if ($avatar_url) {
            echo '<div class="pixnime-widget-avatar">';
            // Vérifier si c'est un attachement WordPress
            $avatar_id = attachment_url_to_postid($avatar_url);
            if ($avatar_id) {
                // Utiliser wp_get_attachment_image pour les attachements WordPress
                $image = wp_get_attachment_image($avatar_id, 'medium', false, array(
                    'style' => 'max-width: 100%; height: auto;',
                    'alt' => esc_attr__('AI Avatar', 'pixnime-pro')
                ));
                echo wp_kses_post($image);
            } else {
                // Fallback pour les URLs externes
                echo '<img src="' . esc_url($avatar_url) . '" alt="' . esc_attr__('AI Avatar', 'pixnime-pro') . '" style="max-width: 100%; height: auto;" />';
            }
            echo '</div>';
        } else {
            echo '<p>' . esc_html__('No avatar generated yet.', 'pixnime-pro') . '</p>';
        }
        
        echo wp_kses_post($args['after_widget']);
    }
    
    /**
     * Widget backend form
     */
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('My Avatar', 'pixnime-pro');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'pixnime-pro'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }
    
    /**
     * Update widget settings
     */
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        return $instance;
    }
} 
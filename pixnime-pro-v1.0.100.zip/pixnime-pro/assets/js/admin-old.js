jQuery(document).ready(function($){
    console.log('Pixnime Pro Admin JS loaded');
    console.log('DEBUG - pixnime_ajax:', pixnimeProL10n.ajax_url);
    console.log('DEBUG - API Key:', pixnimeProL10n.api_key || 'VIDE');
    console.log('DEBUG - OpenAI Key:', pixnimeProL10n.openai_key || 'VIDE');
    
    // Debug: Vérifier que le formulaire existe
    console.log('DEBUG - Formulaire trouvé:', $('#pixnime-generate-form').length);
    console.log('DEBUG - Bouton trouvé:', $('#generate-avatar-btn').length);
    
    // Debug: Vérifier que jQuery fonctionne
    console.log('DEBUG - jQuery version:', $.fn.jquery);
    
    // Détection automatique de l'URL de l'API Pixnime selon la configuration
    var pixnimeApiBase = (function() {
        // Récupérer la configuration depuis les données localisées
        var serverConfig = pixnimeProL10n.server_config || 'auto';
        
        if (serverConfig === 'auto') {
            return (window.location.protocol === 'https:') ? 'https://io.pixnime.com' : 'http://mars.pixnime.com:8080';
        }
        
        switch (serverConfig) {
            case 'mars':
                return 'http://mars.pixnime.com:8080';
            case 'io':
                return 'https://io.pixnime.com';
            case 'www':
                return 'https://www.pixnime.com';
            default:
                return (window.location.protocol === 'https:') ? 'https://io.pixnime.com' : 'http://mars.pixnime.com:8080';
        }
    })();
    
    // Fonction pour vérifier les crédits avant génération
    function checkCreditsBeforeGeneration(callback) {
        var apiKey = pixnimeProL10n.api_key || '';
        var openaiKey = pixnimeProL10n.openai_key || '';
        
        console.log('DEBUG - checkCreditsBeforeGeneration called');
        console.log('DEBUG - apiKey:', apiKey);
        console.log('DEBUG - openaiKey:', openaiKey);
        
        // 👑 MODE VIP PRO : Si une clé OpenAI est configurée, pas besoin de vérifier les crédits
        if (openaiKey) {
            console.log('Mode VIP Pro détecté - génération sans vérification de crédits');
            return callback({success: true});
        }
        
        if (!apiKey) {
            console.log('DEBUG - Aucune clé API trouvée, affichage du message d\'erreur');
            // Pas de clé API configurée - afficher message d'erreur
            return callback({
                success: false,
                message: pixnimeProL10n.msg_api_key_required
            });
        }
        
        $.ajax({
            url: pixnimeApiBase + '/index.php?page=webhook&action=api_verify',
            method: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({apikey: apiKey}),
            success: function(response) {
                if(response.success && response.credits >= 50) {
                    // Assez de crédits, continuer
                    callback({success: true});
                } else if(response.success && response.credits < 50) {
                    // Pas assez de crédits
                    callback({
                        success: false,
                        message: 'You don\'t have enough credits (you have ' + response.credits + ' credits, 50 required). Purchase more here: <a href="https://www.pixnime.com/index.php?page=offers" target="_blank">https://www.pixnime.com/index.php?page=offers</a>'
                    });
                } else {
                    // Clé invalide
                    callback({
                        success: false,
                        message: 'Clé API invalide. Vérifiez votre clé dans les réglages.'
                    });
                }
            },
            error: function(xhr) {
                // Erreur réseau - on laisse passer pour ne pas bloquer
                callback({success: true});
            }
        });
    }

    // Génération d'avatar via formulaire
    $('#pixnime-generate-form').on('submit', function(e){
        console.log('DEBUG - Événement submit déclenché !');
        e.preventDefault();
        console.log('DEBUG - preventDefault() appelé');
        console.log('Form submitted');
        
        var $form = $(this);
        var $btn = $('#generate-avatar-btn');
        var $status = $('#generation-status');
        
        // Vérifier s'il y a déjà des avatars dans le workspace
        var hasCurrentAvatar = $('.main-avatar-image').length > 0;
        var hasVariations = $('.variation-card').length > 0;
        
        if (hasCurrentAvatar || hasVariations) {
            // Interdire la génération et afficher un message d'erreur
            console.log('Workspace not empty - generation blocked');
            $status.show();
            $status.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>' + pixnimeProL10n.workspace_not_empty_error + '</span></div>');
            return; // Arrêter ici
        }
        
        // Vérifier les crédits avant de continuer
        $btn.prop('disabled', true).text(pixnimeProL10n.generate_btn || 'Generate');
        $status.show();
        
        checkCreditsBeforeGeneration(function(result) {
            if (!result.success) {
                $status.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>' + result.message + '</span></div>');
                $btn.prop('disabled', false).text(pixnimeProL10n.generate_btn || 'Generate');
                return;
            }
            
            // Crédits OK, continuer avec la génération
            proceedWithGeneration();
        });
        
        function proceedWithGeneration() {
            // Récupérer les valeurs du formulaire
            var description = $('#avatar_description').val() || '';
            var stylePreset = $('#style_preset').val() || '';
            var avatarId = $('#avatar_randomunique').val();
            
            // Combiner la description avec le preset de style
            var finalDescription = combineDescriptionWithStyle(description, stylePreset);
            
            console.log('Form data:', {
                description: description,
                stylePreset: stylePreset,
                finalDescription: finalDescription,
                avatar_randomunique: avatarId
            });
            
            // Afficher le statut de génération
            $btn.prop('disabled', true).text('Generating...');
            $status.show();
            
            // Afficher le prompt final complet
            displayFinalPrompt(finalDescription);
            
            // Envoyer la requête AJAX avec timeout étendu
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                timeout: 180000, // 3 minutes pour la génération d'avatar
                data: {
                    action: 'pixnime_generate_avatar',
                    nonce: pixnimeProL10n.nonce,
                    description: finalDescription,
                    style_preset: stylePreset,
                    avatar_randomunique: avatarId,
                    api_key: pixnimeProL10n.api_key,
                    openai_key: pixnimeProL10n.openai_key
                },
                success: function(response){
                    console.log('AJAX response:', response);
                    
                    if(response.success){
                        // Mettre à jour l'avatar affiché
                        $('.current-avatar').attr('src', response.data.avatar_url);
                        
                        // Sauvegarder le prompt dans l'URL pour le restaurer après le rechargement
                        var currentUrl = new URL(window.location.href);
                        currentUrl.searchParams.set('last_prompt', encodeURIComponent(description));
                        history.replaceState(null, '', currentUrl.href);
                        
                        // Afficher les informations d'utilisation des crédits
                        var creditInfo = '';
                        if (response.data.credits_used) {
                            creditInfo += ' (' + response.data.credits_used + ' crédits utilisés';
                            if (response.data.credits_remaining !== undefined) {
                                creditInfo += ', ' + response.data.credits_remaining + ' restants';
                            }
                            if (response.data.total_used_today !== undefined) {
                                creditInfo += ', ' + response.data.total_used_today + ' utilisés aujourd\'hui';
                            }
                            creditInfo += ')';
                        }
                        
                        // Message de succès avec informations de crédits
                        var successMessage = response.data.message || 'Avatar généré avec succès';
                        $status.html('<div class="generation-success"><span class="dashicons dashicons-yes-alt"></span><span>' + successMessage + creditInfo + '</span></div>');
                        
                        // Mettre à jour l'affichage des crédits dans l'en-tête si présent
                        updateHeaderCredits(response.data.credits_remaining);
                        
                        // Afficher la notification de débit des crédits
                        if (response.data.credits_used) {
                            showCreditNotification(
                                response.data.credits_used,
                                response.data.credits_remaining,
                                response.data.total_used_today
                            );
                        }
                        
                        // Recharger la page pour afficher le nouvel avatar
                        setTimeout(function(){
                            location.reload();
                        }, 3000); // Augmenté à 3 secondes pour laisser le temps de lire les infos
                    } else {
                        $status.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>Erreur: ' + (response.data || 'Erreur inconnue') + '</span></div>');
                        console.error('Generation failed:', response);
                    }
                    
                    // Remettre le bouton à son état normal
                    $btn.prop('disabled', false).text(pixnimeProL10n.generate_btn || 'Generate');
                },
                error: function(xhr, status, error){
                    console.error('AJAX request failed:', error);
                    
                    // Si c'est une erreur de timeout ou Internal Server Error, proposer un rafraîchissement
                    if (error === 'timeout' || error === 'Internal Server Error' || xhr.status === 500) {
                        $status.html(
                            '<div class="generation-error">' +
                                '<span class="dashicons dashicons-no-alt"></span>' +
                                '<span>Erreur réseau: ' + error + '</span><br/>' +
                                '<p style="margin-top: 10px;">L\'image a sans doute été générée malgré l\'erreur. Rafraichissez la page.</p>' +
                                '<button type="button" class="button button-secondary refresh-avatar-btn" style="margin-top: 5px;">' +
                                    '<span class="dashicons dashicons-update"></span> Rafraîchir pour voir l\'image' +
                                '</button>' +
                            '</div>'
                        );
                    } else {
                        $status.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>Erreur réseau: ' + error + '</span></div>');
                    }
                    
                    // Remettre le bouton à son état normal
                    $btn.prop('disabled', false).text(pixnimeProL10n.generate_btn || 'Generate');
                }
            });
        }
    });
    
    // Fallback: Gestionnaire sur le bouton de génération
    $('#generate-avatar-btn').on('click', function(e) {
        console.log('DEBUG - Clic sur le bouton de génération détecté');
        e.preventDefault();
        console.log('DEBUG - preventDefault() sur le bouton appelé');
        
        // Déclencher manuellement l'événement submit du formulaire
        $('#pixnime-generate-form').submit();
    });
    
    // Génération d'avatar via bouton (fallback)
    $(document).on('click', '.pixnime-generate-avatar', function(e){
        e.preventDefault();
        console.log('Generate button clicked');
        
        var $btn = $(this);
        $btn.prop('disabled', true).text('Generating with GPT...');
        
        $.post(pixnimeProL10n.ajax_url, {
            action: 'pixnime_generate_avatar',
            nonce: pixnimeProL10n.nonce,
            description: $('#pixnime_prompt').val() || ''
        }, function(response){
            console.log('AJAX response:', response);
            
            if(response.success){
                $('.pixnime-avatar-preview').attr('src', response.data.avatar_url);
                $btn.text('Generated with GPT!');
            } else {
                $btn.text('Generation Failed');
            }
            $btn.prop('disabled', false);
        });
    });
    
    // Vérifier si on a des paramètres GET pour génération directe
    var urlParams = new URLSearchParams(window.location.search);
    if(urlParams.has('description')){
        console.log('Direct generation parameters detected in URL');
    }
    
    // Fonction pour générer un ID basé sur le prompt
    function generateIdFromPrompt(prompt) {
        if (!prompt || prompt.trim() === '') {
            // Fallback: ID aléatoire
            return generateRandomId();
        }
        
        // Envoyer le prompt au serveur pour générer l'ID
        $.ajax({
            url: pixnimeProL10n.ajax_url,
            type: 'POST',
            async: false, // Synchrone pour obtenir le résultat immédiatement
            data: {
                action: 'pixnime_generate_id_from_prompt',
                nonce: pixnimeProL10n.nonce,
                prompt: prompt
            },
            success: function(response) {
                if (response.success && response.data.avatar_id) {
                    $('#avatar_randomunique').val(response.data.avatar_id);
                } else {
                    $('#avatar_randomunique').val(generateRandomId());
                }
            },
            error: function() {
                $('#avatar_randomunique').val(generateRandomId());
            }
        });
    }
    
    // Fonction fallback pour générer un ID aléatoire
    function generateRandomId() {
        var characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
        var id = '';
        for (var i = 0; i < 8; i++) {
            id += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return id;
    }
    
    // Régénérer l'ID quand le prompt change
    $('#avatar_description').on('input', function() {
        var prompt = $(this).val();
        var stylePreset = $('#style_preset').val();
        var finalPrompt = combineDescriptionWithStyle(prompt, stylePreset);
        generateIdFromPrompt(finalPrompt);
    });
    
    // Restaurer le prompt depuis l'URL au chargement de la page
    $(document).ready(function() {
        var urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('last_prompt')) {
            var lastPrompt = decodeURIComponent(urlParams.get('last_prompt'));
            var avatarDescription = $('#avatar_description');
            if (avatarDescription.length && lastPrompt.trim()) {
                avatarDescription.val(lastPrompt);
                // Nettoyer l'URL après avoir restauré le prompt
                urlParams.delete('last_prompt');
                var newUrl = window.location.pathname + '?' + urlParams.toString();
                history.replaceState(null, '', newUrl);
            }
        }
    });
    
    // Gestionnaire pour le bouton de rafraîchissement
    $(document).on('click', '.refresh-avatar-btn', function(e) {
        e.preventDefault();
        console.log('Refresh avatar button clicked');
        
        var $btn = $(this);
        var $status = $('#generation-status');
        
        // Désactiver le bouton pendant le rafraîchissement
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update"></span> ' + pixnimeProL10n.refreshing_avatar);
        
        // Attendre un peu puis recharger la page
        setTimeout(function() {
            location.reload();
        }, 1000);
    });
    
    // Gestionnaire pour "Delete All"
    $(document).on('click', '.delete-all-avatars', function(e) {
        e.preventDefault();
        console.log('Delete all avatars button clicked');
        
        var $btn = $(this);
        var originalText = $btn.html();
        
        // Compter les éléments à supprimer
        var variationCount = $('.variation-item').length;
        var totalCount = variationCount + 1; // +1 pour l'avatar principal
        
        // Confirmation avec détails
        var confirmMessage = pixnimeProL10n.delete_all_avatars_confirm + '\n\n';
        confirmMessage += '• ' + pixnimeProL10n.delete_all_avatars_main_avatar + ' (' + totalCount + ')\n';
        confirmMessage += '• ' + pixnimeProL10n.delete_all_avatars_variations + ' (' + variationCount + ')\n';
        confirmMessage += '• ' + pixnimeProL10n.delete_all_avatars_keep_files + '\n';
        confirmMessage += '• ' + pixnimeProL10n.delete_all_avatars_keep_physical + '\n\n';
        confirmMessage += pixnimeProL10n.delete_all_avatars_access_info;
        
        if (!confirm(confirmMessage)) {
            return;
        }
        
        // Désactiver le bouton et afficher le spinner
        $btn.prop('disabled', true).html('<span class="spinner is-active delete-all-spinner"></span> ' + pixnimeProL10n.deleting_all_avatars);
        
        // Envoyer la requête AJAX pour tout supprimer
        $.ajax({
            url: pixnimeProL10n.ajax_url,
            type: 'POST',
            timeout: 60000, // 1 minute
            data: {
                action: 'pixnime_delete_all_avatars',
                nonce: pixnimeProL10n.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Recharger la page pour afficher le workspace vide
                    location.reload();
                } else {
                    alert('Erreur lors de la suppression : ' + (response.data || 'Erreur inconnue'));
                    $btn.prop('disabled', false).html(originalText);
                }
            },
            error: function(xhr, status, error) {
                console.error('Erreur AJAX:', error);
                alert('Erreur réseau lors de la suppression : ' + error);
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Gestionnaire pour "Clear Workspace"
    $(document).on('click', '.clear-workspace', function(e) {
        e.preventDefault();
        console.log('Clear workspace button clicked');
        
        var $btn = $(this);
        var originalText = $btn.html();
        
        // Confirmation avec détails
        var confirmMessage = pixnimeProL10n.clear_workspace_confirm + '\n\n';
        confirmMessage += pixnimeProL10n.clear_workspace_details + '\n';
        confirmMessage += '• ' + pixnimeProL10n.clear_workspace_main_avatar + '\n';
        confirmMessage += '• ' + pixnimeProL10n.clear_workspace_variations + '\n';
        confirmMessage += '• ' + pixnimeProL10n.clear_workspace_keep_files + '\n';
        confirmMessage += '• ' + pixnimeProL10n.clear_workspace_keep_physical + '\n\n';
        confirmMessage += pixnimeProL10n.clear_workspace_access_info;
        
        if (!confirm(confirmMessage)) {
            return;
        }
        
        // Désactiver le bouton et afficher le spinner
        $btn.prop('disabled', true).html('<span class="spinner is-active clear-workspace-spinner"></span> ' + pixnimeProL10n.clearing_workspace);
        
        // Envoyer la requête AJAX pour vider le workspace
        $.ajax({
            url: pixnimeProL10n.ajax_url,
            type: 'POST',
            timeout: 30000, // 30 secondes
            data: {
                action: 'pixnime_clear_workspace',
                nonce: pixnimeProL10n.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Recharger la page pour afficher le workspace vide
                    location.reload();
                } else {
                    alert('Erreur lors du nettoyage du workspace : ' + (response.data || 'Erreur inconnue'));
                    $btn.prop('disabled', false).html(originalText);
                }
            },
            error: function(xhr, status, error) {
                console.error('Erreur AJAX:', error);
                alert('Erreur réseau lors du nettoyage du workspace : ' + error);
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Gestionnaire pour les variations
    $(document).on('click', '.generate-variation', function(e) {
        e.preventDefault();
        console.log('Generate variation button clicked');
        
        var $btn = $(this);
        var $variationForm = $btn.closest('.variation-form');
        var prompt = $variationForm.find('.variation-prompt').val();
        
        if (!prompt || prompt.trim() === '') {
            alert(pixnimeProL10n.variation_prompt_required);
            return;
        }
        
        // Désactiver le bouton
        $btn.prop('disabled', true).text('Generating variation...');
        
        // Envoyer la requête AJAX pour générer la variation
        $.ajax({
            url: pixnimeProL10n.ajax_url,
            type: 'POST',
            timeout: 180000, // 3 minutes
            data: {
                action: 'pixnime_generate_variation',
                nonce: pixnimeProL10n.nonce,
                prompt: prompt,
                api_key: pixnimeProL10n.api_key,
                openai_key: pixnimeProL10n.openai_key
            },
            success: function(response) {
                if (response.success) {
                    // Recharger la page pour afficher la nouvelle variation
                    location.reload();
                } else {
                    alert('Erreur lors de la génération de la variation : ' + (response.data || 'Erreur inconnue'));
                    $btn.prop('disabled', false).text('Generate Variation');
                }
            },
            error: function(xhr, status, error) {
                console.error('Erreur AJAX:', error);
                alert('Erreur réseau lors de la génération de la variation : ' + error);
                $btn.prop('disabled', false).text('Generate Variation');
            }
        });
    });
    
    // Gestionnaire pour supprimer une variation
    $(document).on('click', '.delete-variation', function(e) {
        e.preventDefault();
        console.log('Delete variation button clicked');
        
        var $btn = $(this);
        var variationId = $btn.data('variation-id');
        
        if (!confirm('Êtes-vous sûr de vouloir supprimer cette variation ?')) {
            return;
        }
        
        // Désactiver le bouton
        $btn.prop('disabled', true).text('Deleting...');
        
        // Envoyer la requête AJAX pour supprimer la variation
        $.ajax({
            url: pixnimeProL10n.ajax_url,
            type: 'POST',
            timeout: 30000, // 30 secondes
            data: {
                action: 'pixnime_delete_variation',
                nonce: pixnimeProL10n.nonce,
                variation_id: variationId
            },
            success: function(response) {
                if (response.success) {
                    // Supprimer l'élément de la page
                    $btn.closest('.variation-card').fadeOut(300, function() {
                        $(this).remove();
                    });
                } else {
                    alert('Erreur lors de la suppression de la variation : ' + (response.data || 'Erreur inconnue'));
                    $btn.prop('disabled', false).text('Delete');
                }
            },
            error: function(xhr, status, error) {
                console.error('Erreur AJAX:', error);
                alert('Erreur réseau lors de la suppression de la variation : ' + error);
                $btn.prop('disabled', false).text('Delete');
            }
        });
    });
    
    // Gestionnaire pour copier l'URL d'une image
    $(document).on('click', '.copy-image-url', function(e) {
        e.preventDefault();
        console.log('Copy image URL button clicked');
        
        var $btn = $(this);
        var imageUrl = $btn.data('image-url');
        
        // Essayer d'utiliser l'API Clipboard moderne
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(imageUrl).then(function() {
                showCopySuccess($btn);
            }).catch(function(err) {
                console.error('Erreur clipboard:', err);
                fallbackCopy(imageUrl);
            });
        } else {
            // Fallback pour les navigateurs plus anciens
            fallbackCopy(imageUrl);
        }
        
        function fallbackCopy(text) {
            var textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                showCopySuccess($btn);
            } catch (err) {
                console.error('Erreur fallback copy:', err);
                alert('Erreur lors de la copie : ' + err);
            }
            
            document.body.removeChild(textArea);
        }
        
        function showCopySuccess($button) {
            var originalText = $button.text();
            $button.text('Copied!').addClass('copied');
            
            setTimeout(function() {
                $button.text(originalText).removeClass('copied');
            }, 2000);
        }
    });
    
    // Gestionnaire pour ajouter une image au workspace
    $(document).on('click', '.add-to-workspace', function(e) {
        e.preventDefault();
        console.log('Add to workspace button clicked');
        
        // Vérifier si le workspace est vide
        var hasCurrentAvatar = $('.main-avatar-image').length > 0;
        var hasVariations = $('.variation-card').length > 0;
        
        if (hasCurrentAvatar || hasVariations) {
            alert(pixnimeProL10n.workspace_not_empty_upload_error);
            return;
        }
        
        // Ouvrir la bibliothèque des médias WordPress
        if (typeof wp !== 'undefined' && wp.media) {
            var mediaUploader = wp.media({
                title: 'Sélectionner une image pour le workspace',
                button: {
                    text: 'Ajouter au workspace'
                },
                multiple: false,
                library: {
                    type: 'image'
                }
            });
            
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                
                // Envoyer la requête AJAX pour ajouter l'image au workspace
                $.ajax({
                    url: pixnimeProL10n.ajax_url,
                    type: 'POST',
                    timeout: 30000, // 30 secondes
                    data: {
                        action: 'pixnime_add_image_to_workspace',
                        nonce: pixnimeProL10n.nonce,
                        attachment_id: attachment.id
                    },
                    success: function(response) {
                        if (response.success) {
                            // Afficher une notification de succès
                            var notification = $('<div class="workspace-notification success"></div>');
                            notification.html(
                                '<span class="dashicons dashicons-yes-alt"></span>' +
                                '<span>Image ajoutée au workspace avec succès !</span>'
                            );
                            notification.css({
                                'position': 'fixed',
                                'top': '20px',
                                'right': '20px',
                                'background': '#46b450',
                                'color': 'white',
                                'padding': '10px 15px',
                                'border-radius': '4px',
                                'box-shadow': '0 2px 5px rgba(0,0,0,0.2)',
                                'z-index': '999999',
                                'font-size': '14px',
                                'max-width': '300px'
                            });
                            
                            $('body').append(notification);
                            
                            // Faire disparaître après 3 secondes
                            setTimeout(function() {
                                notification.fadeOut(500, function() {
                                    notification.remove();
                                });
                            }, 3000);
                            
                            // Recharger la page pour afficher le nouvel avatar dans le workspace
                            setTimeout(function() {
                                location.reload();
                            }, 2000);
                        } else {
                            // Erreur lors de l'ajout
                            alert('Erreur lors de l\'ajout de l\'image au workspace : ' + (response.data || 'Erreur inconnue'));
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Erreur AJAX:', error);
                        alert('Erreur réseau lors de l\'ajout de l\'image au workspace : ' + error);
                    }
                });
            });
            
            mediaUploader.open();
        } else {
            // Fallback si wp.media n'est pas disponible
            alert('La bibliothèque des médias WordPress n\'est pas disponible. Veuillez rafraîchir la page.');
        }
    });
    
    /**
     * Afficher l'image sélectionnée (optionnel)
     */
    function showSelectedImage(attachment) {
        // Créer un aperçu de l'image sélectionnée
        var preview = $('<div class="selected-image-preview"></div>');
        preview.html(`
            <div style="background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 8px; padding: 1rem; margin-top: 1rem;">
                <h4 style="margin: 0 0 0.5rem 0; color: #1e293b;">Image sélectionnée</h4>
                <img src="${attachment.url}" alt="${attachment.filename}" style="max-width: 200px; max-height: 200px; border-radius: 4px; margin-bottom: 0.5rem;" />
                <p style="margin: 0; font-size: 12px; color: #64748b;">${attachment.filename}</p>
                <p style="margin: 0.25rem 0 0 0; font-size: 12px; color: #64748b;">Taille: ${attachment.width} x ${attachment.height}</p>
            </div>
        `);
        
        // Insérer l'aperçu après le formulaire de génération
        $('#pixnime-generate-form').after(preview);
        
        // Faire disparaître l'aperçu après 10 secondes
        setTimeout(function() {
            preview.fadeOut(500, function() {
                preview.remove();
            });
        }, 10000);
    }
    
    // Gestion du watermark - Sélecteur d'image
    $('#watermark_image_upload').on('click', function(e) {
        e.preventDefault();
        
        var frame = wp.media({
            title: 'Sélectionner une image de watermark',
            button: {
                text: 'Utiliser cette image'
            },
            multiple: false,
            library: {
                type: 'image'
            }
        });
        
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            
            // Mettre à jour les champs cachés
            $('#watermark_image_id').val(attachment.id);
            $('#watermark_image_url').val(attachment.url);
            
            // Afficher la prévisualisation
            updateWatermarkPreview(attachment.url);
            
            // Afficher le bouton de suppression
            if ($('#watermark_image_remove').length === 0) {
                $('#watermark_image_upload').after(' <button type="button" class="button" id="watermark_image_remove">Supprimer</button>');
            }
        });
        
        frame.open();
    });
    
    // Supprimer l'image de watermark
    $(document).on('click', '#watermark_image_remove', function(e) {
        e.preventDefault();
        
        $('#watermark_image_id').val('');
        $('#watermark_image_url').val('');
        $('.watermark-preview').remove();
        $(this).remove();
    });
    
    // Mettre à jour la prévisualisation du watermark
    function updateWatermarkPreview(imageUrl) {
        $('.watermark-preview').remove();
        var preview = '<div class="watermark-preview"><img src="' + imageUrl + '" style="max-width: 100px; max-height: 100px; border: 1px solid #ddd; margin: 5px 0;" /></div>';
        $('#watermark_image_upload').before(preview);
    }
    
    // Afficher la valeur de l'opacité en temps réel
    $('#watermark_opacity').on('input', function() {
        $('#watermark_opacity_value').text($(this).val() + '%');
    });
    
    // Test du watermark
    $('#watermark_test').on('click', function(e) {
        e.preventDefault();
        
        var testImageId = $('#watermark_test_image').val();
        if (!testImageId) {
            alert('Veuillez sélectionner une image de test.');
            return;
        }
        
        var $btn = $(this);
        var $result = $('#watermark_test_result');
        
        $btn.prop('disabled', true).text('Test en cours...');
        $result.html('<p>Test du watermark en cours...</p>');
        
        $.ajax({
            url: pixnimeProL10n.ajax_url,
            type: 'POST',
            data: {
                action: 'test_watermark',
                nonce: pixnimeProL10n.nonce,
                test_image_id: testImageId
            },
            success: function(response) {
                if (response.success) {
                    $result.html(
                        '<div style="margin-top: 10px; padding: 10px; background: #f0f8ff; border: 1px solid #0073aa;">' +
                            '<h4>Test réussi !</h4>' +
                            '<p>Watermark appliqué avec succès.</p>' +
                            '<img src="' + response.data.test_image_url + '" style="max-width: 300px; max-height: 300px; border: 1px solid #ddd;" />' +
                            '<p><small>Image temporaire générée pour le test</small></p>' +
                        '</div>'
                    );
                } else {
                    $result.html(
                        '<div style="margin-top: 10px; padding: 10px; background: #ffe6e6; border: 1px solid #dc3232;">' +
                            '<h4>Erreur lors du test</h4>' +
                            '<p>' + (response.data || 'Erreur inconnue') + '</p>' +
                        '</div>'
                    );
                }
            },
            error: function(xhr, status, error) {
                $result.html(
                    '<div style="margin-top: 10px; padding: 10px; background: #ffe6e6; border: 1px solid #dc3232;">' +
                        '<h4>Erreur réseau</h4>' +
                        '<p>Erreur: ' + error + '</p>' +
                    '</div>'
                );
            },
            complete: function() {
                $btn.prop('disabled', false).text('Tester le watermark');
            }
        });
    });
    
    // Initialiser la prévisualisation du watermark si une image existe déjà
    $(document).ready(function() {
        var existingImageUrl = $('#watermark_image_url').val();
        if (existingImageUrl) {
            updateWatermarkPreview(existingImageUrl);
        }
    });
    
    // Fonction pour mettre à jour l'affichage des crédits dans l'en-tête
    function updateHeaderCredits(creditsRemaining) {
        var $creditsDisplay = $('.header-credits-display');
        if ($creditsDisplay.length && creditsRemaining !== undefined) {
            $creditsDisplay.text('Crédits: ' + creditsRemaining);
        }
    }
    
    // Fonction pour afficher la notification de débit des crédits
    function showCreditNotification(creditsUsed, creditsRemaining, totalUsedToday) {
        var notification = $('<div class="credit-notification"></div>');
        notification.html(
            '<span class="dashicons dashicons-info"></span>' +
            '<span>Crédits débités: ' + creditsUsed + '</span>' +
            (creditsRemaining !== undefined ? '<br><small>Reste: ' + creditsRemaining + '</small>' : '') +
            (totalUsedToday !== undefined ? '<br><small>Aujourd\'hui: ' + totalUsedToday + '</small>' : '')
        );
        notification.css({
            'position': 'fixed',
            'top': '20px',
            'right': '20px',
            'background': '#0073aa',
            'color': 'white',
            'padding': '10px 15px',
            'border-radius': '4px',
            'box-shadow': '0 2px 5px rgba(0,0,0,0.2)',
            'z-index': '999999',
            'font-size': '14px',
            'max-width': '300px'
        });
        
        $('body').append(notification);
        
        // Faire disparaître après 5 secondes
        setTimeout(function() {
            notification.fadeOut(500, function() {
                notification.remove();
            });
        }, 5000);
    }
});

// Fonction pour combiner la description et le style dans le prompt final
function combineDescriptionWithStyle(description, stylePreset) {
    if (!stylePreset || stylePreset === 'none') {
        return description;
    }
    // On laisse la logique serveur gérer la concaténation exacte si besoin
    return description + ' ' + stylePreset;
}

// Ajout de la fonction manquante pour éviter l'erreur bloquante
function displayFinalPrompt(prompt) {
    console.log('Prompt final utilisé :', prompt);
} 
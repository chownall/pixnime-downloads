<?php
/**
 * Admin class for Pixnime Pro
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Importation des fonctions WordPress si besoin (pour l'autocomplétion et certains IDE)
if (!function_exists('add_menu_page')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

class Pixnime_Pro_Admin {
    
    /**
     * Plugin version
     */
    private $version;
    
    /**
     * Constructor
     */
    public function __construct($version) {
        $this->version = $version;
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        error_log('Pixnime Pro : add_admin_menu appelé');
        
        $icon_url = PIXNIME_PRO_PLUGIN_URL . 'assets/images/pixnime-icon.svg';
        
        add_menu_page(
            __('Pixnime Pro', 'pixnime-pro'),
            __('Pixnime Pro', 'pixnime-pro'),
            'manage_options',
            'pixnime-pro',
            array($this, 'admin_page'),
            $icon_url,
            30
        );
        
        add_submenu_page(
            'pixnime-pro',
            __('Settings', 'pixnime-pro'),
            __('Settings', 'pixnime-pro'),
            'manage_options',
            'pixnime-pro-settings',
            array($this, 'settings_page')
        );
        
        // Ajouter le CSS pour forcer l'affichage de l'icône
        add_action('admin_head', array($this, 'admin_menu_icon_css'));
        
        error_log('Pixnime Pro : menu ajouté avec succès');
    }
    
    /**
     * CSS pour forcer l'affichage de l'icône dans le menu admin
     */
    public function admin_menu_icon_css() {
        echo '<style>
        #adminmenu #toplevel_page_pixnime-pro .wp-menu-image {
            text-align: center !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }
        #adminmenu #toplevel_page_pixnime-pro .wp-menu-image img {
            opacity: 1 !important;
            filter: none !important;
            display: block !important;
            width: 20px !important;
            height: 20px !important;
            margin: 0 auto !important;
        }
        #adminmenu #toplevel_page_pixnime-pro.current .wp-menu-image img,
        #adminmenu #toplevel_page_pixnime-pro.wp-has-current-submenu .wp-menu-image img,
        #adminmenu #toplevel_page_pixnime-pro:hover .wp-menu-image img {
            opacity: 1 !important;
            filter: none !important;
            display: block !important;
            width: 20px !important;
            height: 20px !important;
            margin: 0 auto !important;
        }
        </style>';
    }
    
    /**
     * Main admin page
     */
    public function admin_page() {
        include PIXNIME_PRO_PLUGIN_DIR . 'src/admin/admin-page.php';
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        include PIXNIME_PRO_PLUGIN_DIR . 'src/admin/settings-page.php';
    }
    

    
    /**
     * Enqueue admin styles
     */
    public function enqueue_styles($hook) {
        if (strpos($hook, 'pixnime-pro') !== false) {
            wp_enqueue_style(
                'pixnime-pro-admin',
                PIXNIME_PRO_PLUGIN_URL . 'assets/css/admin.css',
                array(),
                $this->version,
                'all'
            );
        }
    }
    
    /**
     * Enqueue scripts
     */
    public function enqueue_scripts($hook) {
        // Debug: Log du hook actuel
        error_log('Pixnime Debug - Hook actuel: ' . $hook);
        error_log('Pixnime Debug - Condition strpos: ' . (strpos($hook, 'pixnime-pro') !== false ? 'TRUE' : 'FALSE'));
        
        if (strpos($hook, 'pixnime-pro') !== false) {
            error_log('Pixnime Debug - Scripts chargés pour hook: ' . $hook);
            
            // Charger la bibliothèque des médias WordPress
            wp_enqueue_media();
            
            // Charger les modules JavaScript dans l'ordre correct
            // 1. Utilitaires (dépendances pour les autres modules)
            wp_enqueue_script(
                'pixnime-pro-utils',
                PIXNIME_PRO_PLUGIN_URL . 'assets/js/admin-utils.js',
                array('jquery'),
                $this->version,
                false
            );
            
            // 2. API (utilisé par génération et workspace)
            wp_enqueue_script(
                'pixnime-pro-api',
                PIXNIME_PRO_PLUGIN_URL . 'assets/js/admin-api.js',
                array('jquery', 'pixnime-pro-utils'),
                $this->version,
                false
            );
            
            // 3. Debug (peut être utilisé partout)
            wp_enqueue_script(
                'pixnime-pro-debug',
                PIXNIME_PRO_PLUGIN_URL . 'assets/js/admin-debug.js',
                array('jquery', 'pixnime-pro-utils'),
                $this->version,
                false
            );
            
            // 4. Génération (utilise API et utils)
            wp_enqueue_script(
                'pixnime-pro-generation',
                PIXNIME_PRO_PLUGIN_URL . 'assets/js/admin-generation.js',
                array('jquery', 'pixnime-pro-api', 'pixnime-pro-utils'),
                $this->version,
                false
            );
            
            // 5. Workspace (utilise API et utils)
            wp_enqueue_script(
                'pixnime-pro-workspace',
                PIXNIME_PRO_PLUGIN_URL . 'assets/js/admin-workspace.js',
                array('jquery', 'pixnime-pro-api', 'pixnime-pro-utils'),
                $this->version,
                false
            );
            
            // 6. Paramètres (utilise media-upload)
            wp_enqueue_script(
                'pixnime-pro-settings',
                PIXNIME_PRO_PLUGIN_URL . 'assets/js/admin-settings.js',
                array('jquery', 'media-upload', 'pixnime-pro-utils'),
                $this->version,
                false
            );
            
            // 7. Fichier principal (coordonne tous les modules)
            wp_enqueue_script(
                'pixnime-pro-admin',
                PIXNIME_PRO_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery', 'pixnime-pro-utils', 'pixnime-pro-api', 'pixnime-pro-debug', 'pixnime-pro-generation', 'pixnime-pro-workspace', 'pixnime-pro-settings'),
                $this->version,
                false
            );
            
            // Localisation des données (attachée au script principal)
            $settings = get_option('pixnime_pro_settings', array());
            
            // Debug: Log des settings récupérés
            error_log('Pixnime Debug - Settings récupérés: ' . print_r($settings, true));
            error_log('Pixnime Debug - API Key présente: ' . (isset($settings['api_key']) ? 'OUI (' . substr($settings['api_key'], 0, 10) . '...)' : 'NON'));
            error_log('Pixnime Debug - OpenAI Key présente: ' . (isset($settings['openai_key']) ? 'OUI (' . substr($settings['openai_key'], 0, 10) . '...)' : 'NON'));
            
            wp_localize_script('pixnime-pro-admin', 'pixnimeProL10n', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('pixnime_nonce'),
                'api_key' => $settings['api_key'] ?? '',
                'openai_key' => $settings['openai_key'] ?? '',
                'generating_avatar' => __('Generating your avatar...', 'pixnime-pro'),
                'avatar_generated' => __('Avatar generated successfully!', 'pixnime-pro'),
                'error_generating' => __('Error generating avatar', 'pixnime-pro'),
                'credits_insufficient' => __('Insufficient credits', 'pixnime-pro'),
                'api_key_missing' => __('API key missing', 'pixnime-pro'),
                'workspace_not_empty_error' => __('You must first clear your workspace before generating a new main image.', 'pixnime-pro'),
                'workspace_not_empty_upload_error' => __('Clear your workspace first before selecting a new image.', 'pixnime-pro'),
                'clear_workspace_confirm' => __('Clear workspace?', 'pixnime-pro'),
                'clear_workspace_details' => __('This action will:', 'pixnime-pro'),
                'clear_workspace_main_avatar' => __('Remove the main avatar from the workspace', 'pixnime-pro'),
                'clear_workspace_variations' => __('Remove all variations from the workspace', 'pixnime-pro'),
                'clear_workspace_keep_files' => __('KEEP all files in the media library', 'pixnime-pro'),
                'clear_workspace_keep_physical' => __('KEEP all physical files', 'pixnime-pro'),
                'clear_workspace_access_info' => __('You can still access the images via the WordPress media library.', 'pixnime-pro'),
                'clearing_workspace' => __('Clearing workspace...', 'pixnime-pro'),
                'refreshing_avatar' => __('Refreshing...', 'pixnime-pro'),
                'deleting_all_avatars' => __('Deleting all avatars...', 'pixnime-pro'),
                'delete_all_avatars_confirm' => __('WARNING: This action will permanently delete:', 'pixnime-pro'),
                'delete_all_avatars_main_avatar' => __('Main avatar', 'pixnime-pro'),
                'delete_all_avatars_variations' => __('Variations', 'pixnime-pro'),
                'delete_all_avatars_keep_files' => __('All associated files', 'pixnime-pro'),
                'delete_all_avatars_keep_physical' => __('This action is IRREVERSIBLE', 'pixnime-pro'),
                'delete_all_avatars_access_info' => __('Continue?', 'pixnime-pro'),
                'variation_prompt_required' => __('Please enter a variation prompt', 'pixnime-pro'),
                'checking_credits' => __('Checking credits...', 'pixnime-pro'),
                'style_2d_cartoon' => __('Flat illustration with clean lines, bright color flats and few shadows, ideal for a cheerful and accessible style.', 'pixnime-pro'),
                'style_3d_cartoon' => __('Stylized 3D characters with soft textures and playful lighting, inspired by semi-realistic 3D animated films like Pixar or DreamWorks', 'pixnime-pro'),
                'style_flat_vector' => __('Clean style with simple geometric shapes and uniform palette, perfect for modern infographics and web interfaces.', 'pixnime-pro'),
                'style_cel_shading' => __('3D rendering with flat shading mimicking cartoons, often used in stylized video games.', 'pixnime-pro'),
                'style_stylized_illustration' => __('A mix between realism and cartoon with expressive proportions and artistic textures.', 'pixnime-pro'),
                'style_pencil_sketch' => __('Pencil sketch in gray or sepia, with a raw and lively look like in a sketchbook.', 'pixnime-pro'),
                'style_ink_drawing' => __('Inked drawings with strong outlines, typical of comics or black and white illustrations.', 'pixnime-pro'),
                'style_watercolor' => __('Watercolor painting effect with transparency, soft gradients and poetic atmosphere.', 'pixnime-pro'),
                'style_charcoal' => __('Grainy illustration in black and white or warm tones, with raw texture like charcoal.', 'pixnime-pro'),
                'style_ultra_realistic' => __('Very photo-like rendering with extreme detail level, ideal for striking natural or human scenes.', 'pixnime-pro'),
                'style_4k_photorealism' => __('Very high definition image, faithful to reality, with perfectly calibrated textures, shadows and lights.', 'pixnime-pro'),
                'style_cinematic' => __('Realistic image inspired by film framing and lighting, with dramatic or immersive atmosphere.', 'pixnime-pro'),
                'style_low_poly' => __('Simplified geometric style with few polygons, giving a stylized 3D look, often used in video games or data visualization.', 'pixnime-pro'),
                'style_pixel_art' => __('Retro illustration composed of visible pixels, reminiscent of 80s-90s video games.', 'pixnime-pro'),
                'style_isometric' => __('No-fade perspective with fixed angle, perfect for representing maps, buildings or complex systems.', 'pixnime-pro'),
                'style_line_art' => __('Illustration composed only of lines, with or without fill, for a minimalist and elegant rendering.', 'pixnime-pro'),
                'style_papercut' => __('Style imitating paper cutouts in superimposed layers, with a stylized and playful depth effect.', 'pixnime-pro'),
                'msg_api_key_required' => __('Pixnime API key required for credits mode. Configure your key in the settings.', 'pixnime-pro'),
                'generate_btn' => __('Generate', 'pixnime-pro'),
                'generate_avatar_btn' => __('Generate Avatar', 'pixnime-pro'),
                'variation_network_error' => __('Network Error : Wordpress closed connection. Image is probably generated, please refresh.', 'pixnime-pro'),
                'refresh_image_btn' => __('Refresh to see image', 'pixnime-pro'),
                'credits_used' => __('credits used', 'pixnime-pro'),
                'credits_remaining' => __('remaining', 'pixnime-pro'),
                'credits_used_today' => __('used today', 'pixnime-pro'),
                'credits_label' => __('Credits:', 'pixnime-pro'),
                'credits_display' => __('credits', 'pixnime-pro'),
                'api_key_verification' => __('Verification...', 'pixnime-pro'),
                'api_key_none' => __('No API key configured', 'pixnime-pro'),
                'api_key_valid' => __('Valid API key!', 'pixnime-pro'),
                'api_key_invalid' => __('Invalid API key', 'pixnime-pro'),
                'api_key_error' => __('Error: ', 'pixnime-pro'),
                'api_key_unknown_error' => __('Unknown error', 'pixnime-pro'),
                'api_key_connection_error' => __('Connection error', 'pixnime-pro'),
                'api_key_cannot_verify' => __('Cannot verify API key', 'pixnime-pro'),
                'api_key_verify_button' => __('Verify Key', 'pixnime-pro'),
                'credits_available' => __('Available credits:', 'pixnime-pro'),
                'not_enough_credits' => __('You don\'t have enough credits (you have {credits} credits, 50 required). Purchase more here:', 'pixnime-pro'),
                'invalid_api_key_settings' => __('Invalid API key. Check your key in the settings.', 'pixnime-pro'),
                'delete_main_avatar_confirm' => __('Delete main avatar?', 'pixnime-pro'),
                'delete_main_avatar_details' => __('This will also delete all associated variations.', 'pixnime-pro'),
                'deleting_avatar' => __('Deleting...', 'pixnime-pro'),
                'error_deleting_avatar' => __('Error deleting avatar: ', 'pixnime-pro'),
                'unknown_error' => __('Unknown error', 'pixnime-pro'),
                'network_error_deleting' => __('Network error while deleting: ', 'pixnime-pro'),
                'image_url_not_found' => __('Image URL not found', 'pixnime-pro'),
                'image_id_not_found' => __('Image ID not found', 'pixnime-pro'),
                'adding_to_workspace' => __('Adding to workspace...', 'pixnime-pro'),
                'error_adding_to_workspace' => __('Error adding to workspace: ', 'pixnime-pro'),
                'network_error_adding' => __('Network error while adding to workspace: ', 'pixnime-pro'),
                'copy_success' => __('Copied!', 'pixnime-pro'),
                'copy_error' => __('Unable to copy URL. Please copy manually: ', 'pixnime-pro'),
                'empty_workspace_first' => __('Please empty your workspace first', 'pixnime-pro')
            ));
            
            // Debug: Log de l'injection de la variable
            error_log('Pixnime Debug - Variable pixnimeProL10n injectée avec api_key: ' . ($settings['api_key'] ?? 'VIDE'));
        } else {
            error_log('Pixnime Debug - Scripts NON chargés pour hook: ' . $hook);
        }
        
        // Charger la bibliothèque des médias sur la page des réglages aussi
        if (strpos($hook, 'pixnime-pro-settings') !== false) {
            wp_enqueue_media();
        }
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('pixnime_pro_settings', 'pixnime_pro_settings', array(
            'sanitize_callback' => array($this, 'sanitize_settings')
        ));
        
        add_settings_section(
            'pixnime_pro_general',
            __('General Settings', 'pixnime-pro'),
            array($this, 'settings_section_callback'),
            'pixnime_pro_settings'
        );
        
        add_settings_field(
            'api_key',
            __('Pixnime API Key', 'pixnime-pro'),
            array($this, 'api_key_field_callback'),
            'pixnime_pro_settings',
            'pixnime_pro_general'
        );
        
        add_settings_field(
            'openai_key',
            __('OpenAI API Key', 'pixnime-pro'),
            array($this, 'openai_key_field_callback'),
            'pixnime_pro_settings',
            'pixnime_pro_general'
        );
        
        // Section Watermark
        add_settings_section(
            'pixnime_pro_watermark',
            __('Watermark Settings', 'pixnime-pro'),
            array($this, 'watermark_section_callback'),
            'pixnime_pro_settings'
        );
        
        add_settings_field(
            'watermark_position',
            __('Watermark Position', 'pixnime-pro'),
            array($this, 'watermark_position_field_callback'),
            'pixnime_pro_settings',
            'pixnime_pro_watermark'
        );
        
        add_settings_field(
            'watermark_image',
            __('Watermark Image', 'pixnime-pro'),
            array($this, 'watermark_image_field_callback'),
            'pixnime_pro_settings',
            'pixnime_pro_watermark'
        );
        
        add_settings_field(
            'watermark_opacity',
            __('Watermark Opacity', 'pixnime-pro'),
            array($this, 'watermark_opacity_field_callback'),
            'pixnime_pro_settings',
            'pixnime_pro_watermark'
        );
        
        add_settings_field(
            'watermark_test',
            __('Test Watermark', 'pixnime-pro'),
            array($this, 'watermark_test_field_callback'),
            'pixnime_pro_settings',
            'pixnime_pro_watermark'
        );
    }
    
    /**
     * Settings section callback
     */
    public function settings_section_callback() {
        echo '<p>' . esc_html__('Configure your Pixnime Pro settings below.', 'pixnime-pro') . '</p>';
    }
    
    /**
     * API key field callback
     */
    public function api_key_field_callback() {
        $options = get_option('pixnime_pro_settings');
        $api_key = isset($options['api_key']) ? $options['api_key'] : '';
        
        echo '<input type="text" id="api_key" name="pixnime_pro_settings[api_key]" value="' . esc_attr($api_key) . '" class="regular-text" />';
        echo '<p class="description">' . wp_kses(__('Enter your Pixnime API key. Get one at <a href="https://pixnime.com" target="_blank">pixnime.com</a>', 'pixnime-pro'), array('a' => array('href' => array(), 'target' => array()))) . '</p>';
    }
    
    /**
     * OpenAI key field callback
     */
    public function openai_key_field_callback() {
        $options = get_option('pixnime_pro_settings');
        $openai_key = isset($options['openai_key']) ? $options['openai_key'] : '';
        
        echo '<input type="text" id="openai_key" name="pixnime_pro_settings[openai_key]" value="' . esc_attr($openai_key) . '" class="regular-text" />';
        echo '<p class="description"><strong>' . esc_html__('VIP Pro subscribers only - unlimited generations', 'pixnime-pro') . '</strong><br>';
        echo esc_html__('Enter your OpenAI API key for advanced AI avatar generation.', 'pixnime-pro') . '<br>';
        echo esc_html__('Direct generation via your OpenAI key (no credits deducted)', 'pixnime-pro') . '<br>';
        echo esc_html__('Your key is NOT stored on our servers, it is encrypted when querying the Open AI API', 'pixnime-pro') . '</p>';
    }
    
    /**
     * Watermark section callback
     */
    public function watermark_section_callback() {
        echo '<p>' . esc_html__('Configure watermark settings for your generated images. The watermark will be automatically applied when saving to the media library.', 'pixnime-pro') . '</p>';
    }
    
    /**
     * Watermark position field callback
     */
    public function watermark_position_field_callback() {
        $options = get_option('pixnime_pro_settings');
        $position = isset($options['watermark_position']) ? $options['watermark_position'] : 'none';
        
        $positions = array(
            'none' => 'Disabled',
            'top-left' => 'Top Left',
            'top-right' => 'Top Right',
            'center-top' => 'Center Top',
            'center' => 'Center',
            'center-bottom' => 'Center Bottom',
            'bottom-left' => 'Bottom Left',
            'bottom-right' => 'Bottom Right'
        );
        
        echo '<select id="watermark_position" name="pixnime_pro_settings[watermark_position]">';
        foreach ($positions as $value => $label) {
            $selected = ($position === $value) ? 'selected' : '';
            echo '<option value="' . esc_attr($value) . '" ' . esc_attr($selected) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('Choose the position of the watermark on your images.', 'pixnime-pro') . '</p>';
    }
    
    /**
     * Watermark image field callback
     */
    public function watermark_image_field_callback() {
        $options = get_option('pixnime_pro_settings');
        $image_id = isset($options['watermark_image_id']) ? $options['watermark_image_id'] : '';
        $image_url = isset($options['watermark_image_url']) ? $options['watermark_image_url'] : '';
        
        echo '<div class="watermark-image-container">';
        echo '<input type="hidden" id="watermark_image_id" name="pixnime_pro_settings[watermark_image_id]" value="' . esc_attr($image_id) . '" />';
        echo '<input type="hidden" id="watermark_image_url" name="pixnime_pro_settings[watermark_image_url]" value="' . esc_attr($image_url) . '" />';
        
        if (!empty($image_url)) {
            echo '<div class="watermark-preview">';
            if (!empty($image_id)) {
                // Utiliser wp_get_attachment_image pour les images d'attachement WordPress
                $image = wp_get_attachment_image($image_id, 'thumbnail', false, array(
                    'style' => 'max-width: 100px; max-height: 100px; border: 1px solid #ddd; margin: 5px 0;'
                ));
                echo wp_kses_post($image);
            } else {
                // Fallback pour les URLs externes
                echo '<img src="' . esc_url($image_url) . '" style="max-width: 100px; max-height: 100px; border: 1px solid #ddd; margin: 5px 0;" />';
            }
            echo '</div>';
        }
        
        echo '<button type="button" class="button" id="watermark_image_upload">' . esc_html__('Select an image', 'pixnime-pro') . '</button>';
        if (!empty($image_url)) {
            echo ' <button type="button" class="button" id="watermark_image_remove">' . esc_html__('Remove', 'pixnime-pro') . '</button>';
        }
        echo '</div>';
        echo '<p class="description">' . esc_html__('Select a PNG image with transparency for the watermark. Recommended size: 200x200px.', 'pixnime-pro') . '</p>';
    }
    
    /**
     * Watermark opacity field callback
     */
    public function watermark_opacity_field_callback() {
        $options = get_option('pixnime_pro_settings');
        $opacity = isset($options['watermark_opacity']) ? $options['watermark_opacity'] : 50;
        
        echo '<input type="range" id="watermark_opacity" name="pixnime_pro_settings[watermark_opacity]" min="0" max="100" value="' . esc_attr($opacity) . '" style="width: 200px;" />';
        echo ' <span id="watermark_opacity_value">' . esc_html($opacity) . '%</span>';
        echo '<p class="description">' . esc_html__('Adjust the opacity of the watermark (0 = transparent, 100 = opaque).', 'pixnime-pro') . '</p>';
    }
    
    /**
     * Watermark test field callback
     */
    public function watermark_test_field_callback() {
        echo '<div class="watermark-test-container">';
        echo '<select id="watermark_test_image" style="margin-right: 10px;">';
        echo '<option value="">' . esc_html__('Select a test image...', 'pixnime-pro') . '</option>';
        
        // Récupérer les images récentes de la bibliothèque des médias
        $recent_images = get_posts(array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'numberposts' => 10,
            'post_status' => 'inherit'
        ));
        
        foreach ($recent_images as $image) {
            $image_url = wp_get_attachment_url($image->ID);
            echo '<option value="' . esc_attr($image->ID) . '">' . esc_html($image->post_title) . '</option>';
        }
        
        echo '</select>';
        echo '<button type="button" class="button button-primary" id="watermark_test">' . esc_html__('Test watermark', 'pixnime-pro') . '</button>';
        echo '<div id="watermark_test_result" style="margin-top: 10px;"></div>';
        echo '</div>';
        echo '<p class="description">' . esc_html__('Test the application of the watermark on an existing image from your media library.', 'pixnime-pro') . '</p>';
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        // LOG: Début de la sauvegarde des settings
        error_log('=== PIXNIME SETTINGS SAVE START ===');
        error_log('Pixnime Settings Save - Input reçu: ' . print_r($input, true));
        
        // Récupérer les paramètres existants
        $existing_settings = get_option('pixnime_pro_settings', array());
        $sanitized = $existing_settings;
        $error_message = '';
        
        error_log('Pixnime Settings Save - Settings existants: ' . print_r($existing_settings, true));

        // Traiter la clé API Pixnime
        if (isset($input['api_key'])) {
            $sanitized['api_key'] = sanitize_text_field($input['api_key']);
            error_log('Pixnime Settings Save - Clé Pixnime traitée: ' . substr($sanitized['api_key'], 0, 10) . '...');
        }

        // Traiter la clé OpenAI avec vérification VIP Pro
        if (isset($input['openai_key']) && !empty(trim($input['openai_key']))) {
            $openai_key = sanitize_text_field($input['openai_key']);
            $pixnime_key = isset($sanitized['api_key']) ? $sanitized['api_key'] : '';
            
            error_log('Pixnime Settings Save - Tentative sauvegarde clé OpenAI');
            error_log('Pixnime Settings Save - OpenAI key length: ' . strlen($openai_key));
            error_log('Pixnime Settings Save - Pixnime key length: ' . strlen($pixnime_key));

            // Vérification côté Pixnime (VIP Pro)
            $is_vip = false;
            if (!empty($pixnime_key)) {
                // Log pour debug
                error_log('Pixnime VIP Check - Début vérification avec pixnime_key: ' . substr($pixnime_key, 0, 10) . '...');
                error_log('Pixnime VIP Check - OpenAI key: ' . substr($openai_key, 0, 10) . '...');
                
                $request_body = json_encode(array(
                    'openai_key' => $openai_key,
                    'pixnime_key' => $pixnime_key
                ));
                error_log('Pixnime VIP Check - Request body: ' . $request_body);
                
                // Utiliser l'endpoint api_verify qui existe (au lieu de api_check_vip qui n'existe pas)
                $response = wp_remote_post('https://www.pixnime.com/index.php?page=webhook&action=api_verify', array(
                    'timeout' => 30, // Augmenté à 30 secondes
                    'headers' => array('Content-Type' => 'application/json'),
                    'body' => json_encode(array('apikey' => $pixnime_key))
                ));
                
                if (!is_wp_error($response)) {
                    $http_code = wp_remote_retrieve_response_code($response);
                    $body = wp_remote_retrieve_body($response);
                    $data = json_decode($body, true);
                    
                    error_log('Pixnime VIP Check - HTTP Code: ' . $http_code);
                    error_log('Pixnime VIP Check - Response Body: ' . $body);
                    error_log('Pixnime VIP Check - Réponse complète: ' . print_r($data, true));
                    
                    // Analyser la réponse de l'endpoint api_verify
                    if (isset($data['success']) && $data['success']) {
                        error_log('Pixnime VIP Check - API success=true');
                        
                        // Chercher le statut VIP Pro dans différents emplacements possibles
                        $vip_fields_to_check = [
                            'is_vip',
                            'vippro', 
                            'vip_pro',
                            'is_vip_pro',
                            'users.vippro',
                            'user.vippro',
                            'account.vippro'
                        ];
                        
                        foreach ($vip_fields_to_check as $field) {
                            // Gérer les champs imbriqués avec notation point
                            if (strpos($field, '.') !== false) {
                                $parts = explode('.', $field);
                                $value = $data;
                                foreach ($parts as $part) {
                                    if (isset($value[$part])) {
                                        $value = $value[$part];
                                    } else {
                                        $value = null;
                                        break;
                                    }
                                }
                            } else {
                                $value = isset($data[$field]) ? $data[$field] : null;
                            }
                            
                            if ($value == 1 || $value === true || $value === 'true') {
                                $is_vip = true;
                                error_log("Pixnime VIP Check - VIP confirmé via $field=$value");
                                break;
                            } elseif ($value == 0 || $value === false || $value === 'false') {
                                error_log("Pixnime VIP Check - Pas VIP: $field=$value");
                            }
                        }
                        
                        // Si aucun champ VIP Pro trouvé, accepter temporairement si clé Pixnime valide
                        if (!$is_vip) {
                            error_log('Pixnime VIP Check - Aucun champ VIP Pro trouvé, acceptation temporaire car clé Pixnime valide');
                            error_log('Pixnime VIP Check - Clés disponibles: ' . print_r(array_keys($data), true));
                            // TODO: À ajuster selon la vraie structure de réponse de l'API
                            $is_vip = true; // Accepter temporairement pour permettre les tests
                        }
                    } else {
                        error_log('Pixnime VIP Check - Réponse API success=false ou manquante');
                        if (isset($data['error'])) {
                            error_log('Pixnime VIP Check - Erreur API: ' . $data['error']);
                        }
                    }
                } else {
                    error_log('Pixnime VIP Check - Erreur lors de l\'appel API: ' . $response->get_error_message());
                }
            } else {
                error_log('Pixnime VIP Check - Clé Pixnime manquante');
            }
            
            error_log('Pixnime VIP Check - Résultat final is_vip: ' . ($is_vip ? 'true' : 'false'));
            
            if ($is_vip) {
                $sanitized['openai_key'] = $openai_key;
                error_log('Pixnime VIP Check - Clé OpenAI sauvegardée avec succès');
            } else {
                // Ne pas inclure la clé OpenAI dans les paramètres sauvegardés
                // (on ne fait pas unset car elle pourrait ne pas exister)
                error_log('Pixnime VIP Check - Clé OpenAI REFUSÉE - ajout du message d\'erreur');
                add_settings_error('pixnime_pro_settings', 'not_vip_pro', esc_html__('Vous devez passer VIP Pro d\'abord, allez sur pixnime.com', 'pixnime-pro'), 'error');
            }
        } elseif (isset($input['openai_key'])) {
            // Si la clé est vide, on la supprime
            unset($sanitized['openai_key']);
            error_log('Pixnime Settings Save - Clé OpenAI vide supprimée');
        }

        // Ajouter les paramètres de watermark
        if (isset($input['watermark_position'])) {
            $sanitized['watermark_position'] = sanitize_text_field($input['watermark_position']);
        }
        
        if (isset($input['watermark_image_id'])) {
            $sanitized['watermark_image_id'] = intval($input['watermark_image_id']);
        }
        
        if (isset($input['watermark_image_url'])) {
            $sanitized['watermark_image_url'] = sanitize_url($input['watermark_image_url']);
        }
        
        if (isset($input['watermark_opacity'])) {
            $sanitized['watermark_opacity'] = intval($input['watermark_opacity']);
        }
        
        // LOG: Fin de la sauvegarde des settings
        error_log('Pixnime Settings Save - Settings finaux: ' . print_r($sanitized, true));
        error_log('=== PIXNIME SETTINGS SAVE END ===');
        
        return $sanitized;
    }
    
    /**
     * AJAX handler pour supprimer les clés API
     */
    public function handle_clear_key() {
        // Vérifier le nonce
        if (!check_ajax_referer('pixnime_clear_key', 'nonce', false)) {
            wp_send_json_error('Nonce verification failed');
            return;
        }
        
        // Vérifier les permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        $key_type = sanitize_text_field($_POST['key_type'] ?? '');
        
        if (!in_array($key_type, ['pixnime', 'openai'])) {
            wp_send_json_error('Invalid key type');
            return;
        }
        
        // Récupérer les paramètres actuels
        $settings = get_option('pixnime_pro_settings', array());
        
        // Supprimer complètement la clé spécifiée (pas juste la vider)
        if ($key_type === 'pixnime') {
            unset($settings['api_key']);
            $message = 'Clé API Pixnime supprimée avec succès';
        } else {
            unset($settings['openai_key']);
            $message = 'Clé OpenAI supprimée avec succès';
        }
        
        // Sauvegarder les nouveaux paramètres
        $update_result = update_option('pixnime_pro_settings', $settings);
        
        if ($update_result) {
            wp_send_json_success(array(
                'message' => $message,
                'key_type' => $key_type,
                'settings' => $settings
            ));
        } else {
            wp_send_json_error('Erreur lors de la sauvegarde des paramètres');
        }
    }
} 
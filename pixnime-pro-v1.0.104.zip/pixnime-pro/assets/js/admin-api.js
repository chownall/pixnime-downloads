/**
 * Pixnime Pro - API Functions
 * Fonctions pour la gestion des API et vérification des crédits
 */

(function($) {
    'use strict';

    // Namespace pour les fonctions API
    window.PixnimeAPI = {
        
        /**
         * Détection automatique de l'URL de l'API Pixnime selon la configuration
         */
        getApiBaseUrl: function() {
            // Détection automatique basée sur le domaine d'origine
            var currentDomain = window.location.hostname;
            
            // Logique de détection par domaine
            if (currentDomain.indexOf('coprosereine.com') !== -1) {
                return 'https://www.pixnime.com';
            }
            
            if (currentDomain.indexOf('juliab40.sg-host.com') !== -1) {
                return 'https://io.pixnime.com';
            }
            
            // Fallback vers la logique SSL/HTTPS pour les autres domaines
            return (window.location.protocol === 'https:') ? 'https://io.pixnime.com' : 'http://mars.pixnime.com:8080';
        },

        /**
         * Vérifier les crédits avant génération
         */
        checkCreditsBeforeGeneration: function(callback) {
            var apiKey = pixnimeProL10n.api_key || '';
            var openaiKey = pixnimeProL10n.openai_key || '';
            
            // Mode VIP Pro : Si une clé OpenAI est configurée, pas besoin de vérifier les crédits
            if (openaiKey) {
                return callback({success: true});
            }
            
            if (!apiKey) {
                return callback({
                    success: false,
                    message: pixnimeProL10n.msg_api_key_required
                });
            }
            
            $.ajax({
                url: this.getApiBaseUrl() + '/index.php?page=webhook&action=api_verify',
                method: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({apikey: apiKey}),
                success: function(response) {
                    if(response.success && response.credits >= 50) {
                        callback({success: true});
                    } else if(response.success && response.credits < 50) {
                        callback({
                            success: false,
                            message: pixnimeProL10n.not_enough_credits.replace('{credits}', response.credits) + ' <a href="https://www.pixnime.com/index.php?page=offers" target="_blank">https://www.pixnime.com/index.php?page=offers</a>'
                        });
                    } else {
                        callback({
                            success: false,
                            message: pixnimeProL10n.invalid_api_key_settings
                        });
                    }
                },
                error: function(xhr) {
                    callback({success: true});
                }
            });
        },

        /**
         * Vérifier la clé API manuellement
         */
        verifyApiKey: function() {
            var apiKey = $('#api_key').val() || '';
            var $btn = $('#verify-api-key');
            var $result = $('#pixnime-api-verify-result');
            
            if (!apiKey) {
                $result.html('<div class="notice notice-error"><p>' + pixnimeProL10n.api_key_none + '</p></div>');
                return;
            }
            
            $btn.prop('disabled', true).text(pixnimeProL10n.api_key_verification);
            
            $.ajax({
                url: this.getApiBaseUrl() + '/index.php?page=webhook&action=api_verify',
                method: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({apikey: apiKey}),
                success: function(response) {
                    console.log('API Verification Response:', response);
                    
                    if (response && response.success) {
                        $result.html('<div class="notice notice-success"><p><strong>' + pixnimeProL10n.api_key_valid + '</strong><br>' + pixnimeProL10n.credits_available + ' ' + response.credits + '</p><pre>' + JSON.stringify(response, null, 2) + '</pre></div>');
                    } else {
                        $result.html('<div class="notice notice-error"><p><strong>' + pixnimeProL10n.api_key_invalid + '</strong><br>' + pixnimeProL10n.api_key_error + (response.error || pixnimeProL10n.api_key_unknown_error) + '</p><pre>' + JSON.stringify(response, null, 2) + '</pre></div>');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('API Verification Error:', error);
                    $result.html('<div class="notice notice-error"><p><strong>' + pixnimeProL10n.api_key_connection_error + '</strong><br>' + pixnimeProL10n.api_key_cannot_verify + '</p><p>' + pixnimeProL10n.api_key_error + error + '</p></div>');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(pixnimeProL10n.api_key_verify_button);
                }
            });
        },

        /**
         * Mise à jour de l'affichage des crédits dans l'en-tête
         */
        updateHeaderCredits: function(creditsRemaining) {
            var $creditsDisplay = $('.credits-display');
            if ($creditsDisplay.length && creditsRemaining !== undefined) {
                $creditsDisplay.text(creditsRemaining + ' ' + pixnimeProL10n.credits_display);
            }
        },

        /**
         * Affichage d'une notification de crédits
         */
        showCreditNotification: function(creditsUsed, creditsRemaining, totalUsedToday) {
            var message = '';
            
            if (creditsUsed) {
                message += creditsUsed + ' ' + pixnimeProL10n.credits_used;
            }
            
            if (creditsRemaining !== undefined) {
                message += ' • ' + creditsRemaining + ' ' + pixnimeProL10n.credits_remaining;
            }
            
            if (totalUsedToday !== undefined) {
                message += ' • ' + totalUsedToday + ' ' + pixnimeProL10n.credits_used_today;
            }
            
            // Créer ou mettre à jour la notification
            var $notification = $('.credit-notification');
            if ($notification.length === 0) {
                $notification = $('<div class="credit-notification notice notice-info" style="margin: 10px 0; padding: 10px; border-left: 4px solid #0073aa;"></div>');
                $('.generation-status').after($notification);
            }
            
            $notification.html('<p><strong>' + pixnimeProL10n.credits_label + '</strong> ' + message + '</p>');
            
            // Masquer après 5 secondes
            setTimeout(function() {
                $notification.fadeOut();
            }, 5000);
        },

        /**
         * Initialisation des fonctions API
         */
        init: function() {
            console.log('Pixnime Pro API JS loaded');
            console.log('API Base URL:', this.getApiBaseUrl());
            
            // Exposer l'URL de base pour les autres modules
            window.pixnimeApiBase = this.getApiBaseUrl();
        }
    };

    // Gestionnaires d'événements pour les API
    $(document).ready(function() {
        PixnimeAPI.init();
        
        // Vérification manuelle de la clé API
        $(document).on('click', '#verify-api-key', function(e) {
            e.preventDefault();
            PixnimeAPI.verifyApiKey();
        });
    });

})(jQuery); 
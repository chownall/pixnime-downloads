<?php
/**
 * Pixnime Secure API class for WordPress integration
 * 
 * This class handles:
 * 1. Secure credit debit on Pixnime side
 * 2. Security token verification
 * 3. Secure generation process
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Pixnime_Pro_Secure_API {
    
    private $pixnime_base_url;
    private $timeout = 30;
    
    public function __construct($base_url = 'http://mars.pixnime.com:8080') {
        $this->pixnime_base_url = rtrim($base_url, '/');
    }
    
    /**
     * Débiter les crédits de manière sécurisée
     * 
     * @param string $api_key Clé API de l'utilisateur
     * @return array|false Résultat avec jeton de sécurité ou false en cas d'erreur
     */
    public function debit_credits($api_key) {
        $url = $this->pixnime_base_url . '/index.php?page=webhook&action=api_generate';
        
        $data = [
            'api_key' => $api_key
        ];
        
        $response = wp_remote_post($url, [
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($data),
            'timeout' => $this->timeout
        ]);
        
        if (is_wp_error($response)) {
            error_log('Pixnime API Error: ' . $response->get_error_message());
            return false;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        if ($status_code !== 200 || !$result || !$result['success']) {
            error_log('Pixnime API Error: ' . ($result['error'] ?? 'Unknown error'));
            return false;
        }
        
        return $result;
    }
    
    /**
     * Vérifier la validité du jeton de sécurité
     * 
     * @param string $security_token Jeton de sécurité reçu
     * @param int $user_id ID utilisateur
     * @return array|false Données de vérification ou false en cas d'erreur
     */
    public function verify_token($security_token, $user_id) {
        $url = $this->pixnime_base_url . '/index.php?page=webhook&action=api_verify_token';
        
        $data = [
            'security_token' => $security_token,
            'user_id' => $user_id
        ];
        
        $response = wp_remote_post($url, [
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($data),
            'timeout' => $this->timeout
        ]);
        
        if (is_wp_error($response)) {
            error_log('Pixnime Token Verify Error: ' . $response->get_error_message());
            return false;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        if ($status_code !== 200 || !$result || !$result['valid']) {
            error_log('Pixnime Token Invalid: ' . ($result['error'] ?? 'Unknown error'));
            return false;
        }
        
        return $result;
    }
    
    /**
     * Processus complet sécurisé : débit + vérification + génération
     * 
     * @param string $api_key Clé API utilisateur
     * @param array $generation_params Paramètres de génération
     * @return array Résultat de la génération
     */
    public function secure_generate($api_key, $generation_params = []) {
        // 1. 💰 DÉBITER LES CRÉDITS CÔTÉ PIXNIME
        $debit_result = $this->debit_credits($api_key);
        
        if (!$debit_result) {
            return [
                'success' => false,
                'error' => 'Impossible de débiter les crédits',
                'step' => 'debit'
            ];
        }
        
        $security_token = $debit_result['security_token'];
        $user_id = $debit_result['user_id'];
        $credits_remaining = $debit_result['credits_remaining'];
        
        // 2. 🔐 VÉRIFIER LE JETON DE SÉCURITÉ
        $verify_result = $this->verify_token($security_token, $user_id);
        
        if (!$verify_result) {
            return [
                'success' => false,
                'error' => 'Jeton de sécurité invalide',
                'step' => 'verify',
                'security_token' => $security_token
            ];
        }
        
        // 3. 🎨 PROCÉDER À LA GÉNÉRATION CÔTÉ WORDPRESS
        try {
            // Utiliser la méthode de génération existante
            $openai_key = get_option('pixnime_pro_settings')['openai_key'] ?? '';
            
            if (empty($openai_key)) {
                throw new Exception('Clé OpenAI non configurée');
            }
            
            // Créer une instance de l'API existante et utiliser ses méthodes
            $pixnime_api = new Pixnime_Pro_API();
            
            if ($generation_params['type'] === 'avatar') {
                $avatar_url = $pixnime_api->generate_image_with_openai(
                    $generation_params['description'], 
                    $generation_params['avatar_id'], 
                    $openai_key
                );
            } else {
                // Pour les variations
                $avatar_url = $pixnime_api->generate_variation_with_consistency(
                    $generation_params['original_prompt'],
                    $generation_params['original_avatar_id'],
                    $generation_params['variation_prompt'],
                    $openai_key
                );
            }
            
            if (!$avatar_url) {
                throw new Exception('Échec de la génération d\'image');
            }
            
            // 4. ✅ SUCCÈS COMPLET
            return [
                'success' => true,
                'message' => 'Image générée avec succès',
                'avatar_url' => $avatar_url,
                'credits_remaining' => $credits_remaining,
                'credits_used' => $verify_result['credits_debited'] ?? 50,
                'user_id' => $user_id,
                'generated_at' => current_time('mysql')
            ];
            
        } catch (Exception $e) {
            // En cas d'erreur de génération, les crédits ont déjà été débités côté Pixnime
            error_log('Pixnime Generation Error: ' . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Erreur lors de la génération: ' . $e->getMessage(),
                'step' => 'generation',
                'credits_debited' => $verify_result['credits_debited'] ?? 50,
                'note' => 'Les crédits ont été débités côté Pixnime'
            ];
        }
    }
} 
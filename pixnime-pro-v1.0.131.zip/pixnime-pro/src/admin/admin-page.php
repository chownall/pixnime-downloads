<?php
/**
 * Main admin page for Pixnime Pro
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get current user avatar
$user_id = get_current_user_id();
$current_avatar = get_user_meta($user_id, 'pixnime_avatar_url', true);
$current_avatar_id = get_user_meta($user_id, 'pixnime_avatar_id', true);
$current_avatar_prompt = get_user_meta($user_id, 'pixnime_avatar_prompt', true);
$avatar_variations = get_user_meta($user_id, 'pixnime_avatar_variations', true);
$settings = get_option('pixnime_pro_settings', array());

// Vérifier les crédits disponibles
$api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
$credits_remaining = 0;
$credits_status = 'unknown';

if (!empty($api_key)) {
    $pixnime_api = new Pixnime_Pro_API();
    $credit_check = $pixnime_api->verify_pixnime_credits($api_key);
    if ($credit_check['success']) {
        $credits_remaining = $credit_check['credits'];
        $credits_status = 'verified';
    } else {
        $credits_status = 'error';
    }
}

if (!$avatar_variations) {
    $avatar_variations = array();
}

// Check if avatar was just generated
$just_generated = isset($_GET['generated']) && sanitize_text_field($_GET['generated']) == '1';

// Create instance for generating random ID
$pixnime_instance = new Pixnime_Pro();
?>

<div class="wrap pixnime-pro-admin">
    <!-- Header Graphique Pixnime -->
    <div class="pixnime-header">
        <div class="pixnime-header-content">
            <div class="pixnime-brand">
                <div class="pixnime-logo">
                    <img src="<?php echo esc_url(PIXNIME_PRO_PLUGIN_URL . 'assets/images/logopixnime120.png'); ?>" alt="Pixnime" class="pixnime-logo-img">
                    <div class="pixnime-brand-text">
                        <h1 class="pixnime-title">Pixnime Pro</h1>
                        <p class="pixnime-subtitle"><?php esc_html_e('Generate AI avatars and maintain visual consistency in your creations', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="pixnime-header-actions">
                <!-- Crédits restants -->
                <div class="pixnime-credits">
                    <div class="credits-icon">
                        <span class="dashicons dashicons-star-filled"></span>
                    </div>
                    <div class="credits-info">
                        <span class="credits-label"><?php esc_html_e('Remaining credits', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></span>
                        <span class="credits-count <?php echo esc_attr($credits_status); ?>">
                            <?php if ($credits_status === 'verified'): ?>
                                <?php echo esc_html(number_format($credits_remaining)); ?>
                            <?php elseif ($credits_status === 'error'): ?>
                                <span class="error-text">Erreur</span>
                            <?php else: ?>
                                <span class="unknown-text">--</span>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
                
                <!-- Actions principales avec table pour meilleur alignement -->
                <table class="pixnime-header-buttons-table">
                    <tr>
                        <?php if (empty($api_key)): ?>
                            <td>
                                <a href="https://www.pixnime.com/wordpress" target="_blank" class="button button-primary pixnime-btn-register">
                                    <span class="dashicons dashicons-admin-users"></span>
                                    <?php esc_html_e('Sign up', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </a>
                            </td>
                            <td>
                                <a href="https://www.pixnime.com/index.php?page=howto&action=install" target="_blank" class="button button-secondary pixnime-btn-api">
                                    <span class="dashicons dashicons-admin-network"></span>
                                    <?php esc_html_e('Get your API KEY', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </a>
                            </td>
                        <?php else: ?>
                            <td>
                                <a href="https://www.pixnime.com/index.php?page=offers" target="_blank" class="button button-primary pixnime-btn-credits">
                                    <span class="dashicons dashicons-plus-alt"></span>
                                    <?php esc_html_e('Buy credits', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </a>
                            </td>
                        <?php endif; ?>
                        
                        <td>
                            <a href="https://www.pixnime.com/free-trial" target="_blank" class="button button-secondary pixnime-btn-trial" id="pixnime-btn-free-credits">
                                <span class="dashicons dashicons-heart"></span>
                                <?php esc_html_e('100 free credits', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <a href="<?php echo esc_url(admin_url('admin.php?page=pixnime-pro-settings')); ?>" class="button button-secondary pixnime-btn-settings">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <?php esc_html_e('Settings', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- Barre de statut simplifiée -->
        <div class="pixnime-status-bar">
            <div class="status-item">
                <span class="dashicons dashicons-images-alt2"></span>
                                        <span class="status-label"><?php esc_html_e('Generations:', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></span>
                <span class="status-value">
                    <?php echo count($avatar_variations) + ($current_avatar ? 1 : 0); ?> <?php esc_html_e('created', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </span>
            </div>
        </div>
    </div>
    
    <!-- Section Publicitaire Pixnime Offers - Alignée à droite -->
    <div class="pixnime-promo-sidebar">
        <div class="pixnime-promo-content">
            <div class="pixnime-promo-image">
                <span class="dashicons dashicons-star-filled promo-icon"></span>
            </div>
            <div class="pixnime-promo-text">
                <h4 class="promo-title">🚀 <?php esc_html_e('VIP Offers', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h4>
                <p class="promo-description">
                    <?php esc_html_e('Unlimited generations !', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </p>
                <a href="https://www.pixnime.com/index.php?page=offers" target="_blank" class="promo-cta-button">
                    <span class="dashicons dashicons-star-filled"></span>
                    <?php esc_html_e('See offers', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </a>
            </div>
        </div>
        <div class="promo-close-btn" id="promo-close-btn">
            <span class="dashicons dashicons-no-alt"></span>
        </div>
    </div>
    
    <?php if ($just_generated): ?>
    <div class="notice notice-success is-dismissible">
        <p><?php esc_html_e('Avatar generated successfully!', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></p>
    </div>
    <?php endif; ?>
    
    <div class="pixnime-pro-container">
        <!-- Generate "Origin" Avatar or Illustration Section -->
        <div class="generate-section">
            <div class="generate-section-header">
                <h2><?php esc_html_e('Generate "Origin" Avatar or Illustration', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></h2>
                <div class="generate-section-actions">
                    <button type="button" class="button button-secondary add-to-workspace" id="upload-to-media-library-btn">
                        <span class="dashicons dashicons-images-alt2"></span>
                        <?php esc_html_e('Choose a file from the library', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?> (PNG ONLY)
                    </button>
                </div>
            </div>
            <div class="avatar-generator">
                <form id="pixnime-generate-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="avatar_description"><?php esc_html_e('Description', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                            </th>
                            <td>
                                <textarea id="avatar_description" name="description" rows="6" cols="50" required><?php echo esc_textarea(
'A beautiful blonde young woman in red slim pants and beige stiletto heels, black crop top t-shirt with giraffe head print, standing and presenting a very modern small electric car'
); ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="style_preset"><?php esc_html_e('Style Preset', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                            </th>
                            <td>
                                <select id="style_preset" name="style_preset" class="regular-text">
                                    <option value=""><?php esc_html_e('-- Choose a style --', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="none"><?php esc_html_e('None (No style)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="2d_cartoon"><?php esc_html_e('2D Cartoon', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="3d_cartoon"><?php esc_html_e('3D Cartoon', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="flat_vector"><?php esc_html_e('Flat Vector', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="cel_shading"><?php esc_html_e('Cel Shading', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="stylized_illustration"><?php esc_html_e('Stylized Illustration', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="pencil_sketch"><?php esc_html_e('Pencil Sketch', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="ink_drawing"><?php esc_html_e('Ink Drawing', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="watercolor"><?php esc_html_e('Watercolor', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="charcoal"><?php esc_html_e('Charcoal', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="ultra_realistic"><?php esc_html_e('Ultra Realistic', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="4k_photorealism"><?php esc_html_e('4K Photorealism', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="cinematic"><?php esc_html_e('Cinematic', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="low_poly"><?php esc_html_e('Low Poly', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="pixel_art"><?php esc_html_e('Pixel Art', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="isometric"><?php esc_html_e('Isometric', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="line_art"><?php esc_html_e('Line Art', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                    <option value="papercut"><?php esc_html_e('Papercut', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></option>
                                </select>
                                <p class="description">
                                    <?php esc_html_e('Select a style that will be automatically added to your description', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </p>
                                <div id="style_description" class="style-description"></div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="avatar_randomunique"><?php esc_html_e('Origin ID', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="avatar_randomunique" name="avatar_randomunique" value="<?php echo esc_attr($pixnime_instance->generate_random_id()); ?>" class="regular-text" readonly />
                                <p class="description">
                                    <?php esc_html_e('Unique identifier for this avatar generation (generated once at page load)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary" id="generate-avatar-btn">
                            <span class="dashicons dashicons-admin-generic"></span>
                            <?php esc_html_e('Generate Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        </button>
                    </p>
                </form>
                
                <div id="generation-status" style="display: none;">
                    <div class="generation-loading">
                        <span class="spinner is-active"></span>
                        <span><?php esc_html_e('Generating your avatar...', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Workspace - Avatar Original et Variations -->
        <?php if ($current_avatar || !empty($avatar_variations)): ?>
        <div class="pixnime-pro-section pixnime-workspace">
            <div class="workspace-header">
                <h2>
                    <span class="dashicons dashicons-art"></span>
                    <?php esc_html_e('My Workspace', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                </h2>
                <div class="workspace-header-actions">
                    <button class="button button-secondary clear-workspace" title="<?php esc_attr_e('Clear workspace (keep files)', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Clear workspace', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                    </button>
                </div>
            </div>
            
            <div class="workspace-content">
                <!-- Avatar Principal -->
                <?php if ($current_avatar): ?>
                <div class="workspace-main-avatar">
                    <div class="main-avatar-label">
                        <span class="dashicons dashicons-star-filled"></span>
                        <?php esc_html_e('Main Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                    </div>
                    
                    <div class="main-avatar-container">
                        <img src="<?php echo esc_url($current_avatar); ?>" alt="<?php esc_attr_e('Main Avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>" class="main-avatar-image" />
                        
                        <div class="main-avatar-actions">
                            <button class="button button-secondary delete-current-avatar" title="<?php esc_attr_e('Delete main avatar', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                                <span class="dashicons dashicons-trash"></span>
                                <?php esc_html_e('Delete', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                            </button>
                        </div>
                        
                        <?php if (!empty($current_avatar_prompt)): ?>
                        <div class="main-avatar-prompt">
                            <strong><?php esc_html_e('Prompt used:', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?></strong>
                            <div class="prompt-content"><?php echo esc_html($current_avatar_prompt); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Génération de Variations -->
                    <div class="variation-creator">
                        <div class="variation-creator-header">
                            <span class="dashicons dashicons-plus-alt2"></span>
                            <?php esc_html_e('Create a Variation', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                        </div>
                        <div class="variation-creator-form">
                            <div class="variation-form-inputs">
                                <textarea id="variation_prompt" name="variation_prompt" class="variation-prompt-input" rows="3" placeholder="<?php esc_attr_e('Describe the variation...', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>"></textarea>
                                <button type="button" class="button button-secondary" id="generate-variation-btn">
                                    <span class="dashicons dashicons-art"></span>
                                    <?php esc_html_e('Generate', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                </button>
                            </div>
                        </div>
                        <!-- Conteneur pour les messages d'erreur/succès de variation -->
                        <div id="variation-error-container" class="variation-status-container"></div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Grille des Variations -->
                <?php if (!empty($avatar_variations)): ?>
                <div class="workspace-variations">
                    <div class="variations-label">
                        <span class="dashicons dashicons-images-alt2"></span>
                        <?php esc_html_e('Generated Variations', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?> (<?php echo count($avatar_variations); ?>)
                    </div>
                    <div class="variations-grid">
                        <?php foreach ($avatar_variations as $index => $variation): ?>
                                                         <div class="variation-card">
                                 <div class="variation-image-container">
                                     <img src="<?php echo esc_url($variation['url']); ?>" alt="<?php esc_attr_e('Variation', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>" />
                                 </div>
                                 <div class="variation-info">
                                     <?php if (isset($variation['original_avatar_id']) && $variation['original_avatar_id']): ?>
                                         <div class="variation-id">
                                             <code><?php echo esc_html($variation['original_avatar_id']); ?>_var<?php echo esc_html($index + 1); ?></code>
                                         </div>
                                     <?php endif; ?>
                                     <?php if (isset($variation['prompt']) && $variation['prompt']): ?>
                                         <div class="variation-prompt">
                                             <span class="prompt-text"><?php echo esc_html($variation['prompt']); ?></span>
                                             <button class="copy-prompt-btn" data-prompt="<?php echo esc_attr($variation['prompt']); ?>" title="<?php esc_attr_e('Copier le prompt', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>">
                                                 <span class="dashicons dashicons-admin-page"></span>
                                             </button>
                                         </div>
                                     <?php endif; ?>
                                 </div>
                                 <div class="variation-actions">
                                     <button class="button button-secondary delete-variation" data-index="<?php echo esc_attr($index); ?>" data-url="<?php echo esc_attr($variation['url']); ?>">
                                         <?php esc_html_e('Delete', 'pixnime-pro-ai-character-and-illustrations-consistency-generator'); ?>
                                     </button>
                                 </div>
                             </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>


    </div>
</div> 
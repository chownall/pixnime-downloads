/**
 * Pixnime Pro - Workspace Functions
 * Fonctions pour la gestion du workspace, suppression et copie
 */

(function($) {
    'use strict';

    // Namespace pour les fonctions de workspace
    window.PixnimeWorkspace = {
        
        /**
         * Vider le workspace
         */
        clearWorkspace: function() {
            var confirmText = pixnimeProL10n.clear_workspace_confirm || 'Vider le workspace ?';
            
            if (!confirm(confirmText)) {
                return;
            }
            
            var $btn = $('.clear-workspace');
            var originalText = $btn.text();
            $btn.prop('disabled', true).text(pixnimeProL10n.clearing_workspace || 'Vidage en cours...');
            
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                data: {
                    action: 'pixnime_clear_workspace',
                    nonce: pixnimeProL10n.nonce
                },
                success: function(response) {
                    console.log('Clear workspace response:', response);
                    
                    if (response.success) {
                        // Rechargement automatique après 1 seconde
                        setTimeout(function(){
                            location.reload();
                        }, 1000);
                    } else {
                        alert('Erreur lors du vidage du workspace: ' + (response.data || 'Erreur inconnue'));
                        $btn.prop('disabled', false).text(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Erreur AJAX clear workspace:', error);
                    alert((pixnimeProL10n.network_error_clear_workspace || 'Network error while clearing workspace: ') + error);
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Supprimer tous les avatars
         */
        deleteAllAvatars: function() {
            var confirmText = pixnimeProL10n.delete_all_avatars_confirm || 'Supprimer tous les avatars ?';
            
            if (!confirm(confirmText + '\n\nCette action est IRRÉVERSIBLE !')) {
                return;
            }
            
            var $btn = $('.delete-all-avatars');
            var originalText = $btn.text();
            $btn.prop('disabled', true).text(pixnimeProL10n.deleting_all_avatars || 'Suppression en cours...');
            
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                data: {
                    action: 'pixnime_delete_all_avatars',
                    nonce: pixnimeProL10n.nonce
                },
                success: function(response) {
                    console.log('Delete all avatars response:', response);
                    
                    if (response.success) {
                        // Rechargement automatique après 1 seconde
                        setTimeout(function(){
                            location.reload();
                        }, 1000);
                    } else {
                        alert('Erreur lors de la suppression: ' + (response.data || 'Erreur inconnue'));
                        $btn.prop('disabled', false).text(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Erreur AJAX delete all avatars:', error);
                    alert((pixnimeProL10n.network_error_delete_all || 'Network error while deleting: ') + error);
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Supprimer une variation
         */
        deleteVariation: function($btn) {
            var variationIndex = $btn.data('index');
            var imageUrl = $btn.data('url');
            
            if (variationIndex === undefined) {
                alert('Index de variation non trouvé');
                return;
            }
            
            if (!confirm('Supprimer cette variation ?')) {
                return;
            }
            
            var originalText = $btn.text();
            
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                data: {
                    action: 'pixnime_delete_variation',
                    nonce: pixnimeProL10n.nonce,
                    variation_index: variationIndex,
                    image_url: imageUrl
                },
                success: function(response) {
                    console.log('Delete variation response:', response);
                    
                    if (response.success) {
                        // Supprimer la carte de variation de l'interface
                        $btn.closest('.variation-card').fadeOut(300, function() {
                            $(this).remove();
                        });
                    } else {
                        alert('Erreur lors de la suppression de la variation: ' + (response.data || 'Erreur inconnue'));
                        $btn.prop('disabled', false).text(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Erreur AJAX delete variation:', error);
                    alert((pixnimeProL10n.network_error_delete_variation || 'Network error while deleting: ') + error);
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Supprimer l'avatar principal
         */
        deleteCurrentAvatar: function() {
            console.log('deleteCurrentAvatar function called');
            
            if (!confirm(pixnimeProL10n.delete_main_avatar_confirm + '\n\n' + pixnimeProL10n.delete_main_avatar_details)) {
                console.log('User cancelled deletion');
                return;
            }
            
            var $btn = $('.delete-current-avatar');
            var originalText = $btn.text();
            console.log('Button found:', $btn.length > 0);
            console.log('Original text:', originalText);
            
            $btn.prop('disabled', true).text(pixnimeProL10n.deleting_avatar);
            
            // Récupérer l'URL de l'image pour la suppression
            var imageUrl = $('.main-avatar-image').attr('src') || '';
            console.log('Image URL:', imageUrl);
            
            console.log('Sending AJAX request...');
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                data: {
                    action: 'pixnime_delete_current_avatar',
                    nonce: pixnimeProL10n.nonce,
                    image_url: imageUrl
                },
                success: function(response) {
                    console.log('Delete current avatar response:', response);
                    
                    if (response.success) {
                        console.log('Success - reloading page...');
                        // Rechargement automatique après 1 seconde
                        setTimeout(function(){
                            location.reload();
                        }, 1000);
                    } else {
                        console.log('Error in response:', response.data);
                        alert(pixnimeProL10n.error_deleting_avatar + (response.data || pixnimeProL10n.unknown_error));
                        $btn.prop('disabled', false).text(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Erreur AJAX delete current avatar:', error);
                    console.error('Status:', status);
                    console.error('Response:', xhr.responseText);
                    alert(pixnimeProL10n.network_error_deleting + error);
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Copier l'URL d'une image
         */
        copyImageUrl: function($btn) {
            var imageUrl = $btn.data('image-url');
            
            if (!imageUrl) {
                alert(pixnimeProL10n.image_url_not_found);
                return;
            }
            
            // Méthode moderne pour copier dans le presse-papiers
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(imageUrl).then(function() {
                    this.showCopySuccess($btn);
                }.bind(this)).catch(function(err) {
                    console.error('Erreur lors de la copie:', err);
                    this.fallbackCopy(imageUrl, $btn);
                }.bind(this));
            } else {
                // Fallback pour les navigateurs plus anciens
                this.fallbackCopy(imageUrl, $btn);
            }
        },

        /**
         * Méthode de copie de secours
         */
        fallbackCopy: function(text, $btn) {
            var textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                var successful = document.execCommand('copy');
                if (successful) {
                    this.showCopySuccess($btn);
                } else {
                    alert(pixnimeProL10n.copy_error + text);
                }
            } catch (err) {
                console.error('Erreur lors de la copie:', err);
                alert(pixnimeProL10n.copy_error + text);
            } finally {
                document.body.removeChild(textArea);
            }
        },

        /**
         * Afficher un message de succès de copie
         */
        showCopySuccess: function($btn) {
            var originalText = $btn.text();
            $btn.text(pixnimeProL10n.copy_success).addClass('copied');
            
            setTimeout(function() {
                $btn.text(originalText).removeClass('copied');
            }, 2000);
        },

        /**
         * Ajouter une image au workspace ou ouvrir la bibliothèque des médias
         */
        addToWorkspace: function($btn) {
            // Si c'est le bouton principal "Choose a file from the library"
            if ($btn.attr('id') === 'upload-to-media-library-btn') {
                this.handleChooseFromLibrary();
                return;
            }
            
            // Sinon, c'est un bouton d'ajout d'image spécifique
            var imageId = $btn.data('image-id');
            
            if (!imageId) {
                alert(pixnimeProL10n.image_id_not_found);
                return;
            }
            
            var originalText = $btn.text();
            $btn.prop('disabled', true).text(pixnimeProL10n.adding_to_workspace);
            
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                data: {
                    action: 'pixnime_add_image_to_workspace',
                    nonce: pixnimeProL10n.nonce,
                    image_id: imageId
                },
                success: function(response) {
                    console.log('Add to workspace response:', response);
                    
                    if (response.success) {
                        // Rechargement automatique après 1 seconde
                        setTimeout(function(){
                            location.reload();
                        }, 1000);
                    } else {
                        alert(pixnimeProL10n.error_adding_to_workspace + (response.data || pixnimeProL10n.unknown_error));
                        $btn.prop('disabled', false).text(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Erreur AJAX add to workspace:', error);
                    alert(pixnimeProL10n.network_error_adding + error);
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Gérer le bouton "Choose a file from the library"
         */
        handleChooseFromLibrary: function() {
            // Vérifier si le workspace est vide
            var hasCurrentAvatar = $('.main-avatar-image').length > 0;
            var hasVariations = $('.variation-card').length > 0;
            
            if (hasCurrentAvatar || hasVariations) {
                alert(pixnimeProL10n.empty_workspace_first);
                return;
            }
            
            // Si le workspace est vide, ouvrir directement la Media Library
            if (typeof window.openPixnimeMediaLibrary === 'function') {
                window.openPixnimeMediaLibrary();
            } else {
                // Fallback : on tente le trigger comme avant
                $('#upload-to-media-library-btn').trigger('click.settings');
            }
        },

        /**
         * Initialisation des fonctions de workspace
         */
        init: function() {
            console.log('Pixnime Pro Workspace JS loaded');
            console.log('Delete current avatar button count:', $('.delete-current-avatar').length);
            console.log('Workspace elements found:', {
                'main-avatar-image': $('.main-avatar-image').length,
                'delete-current-avatar': $('.delete-current-avatar').length,
                'variation-card': $('.variation-card').length
            });
        }
    };

    // Gestionnaires d'événements pour le workspace
    $(document).ready(function() {
        PixnimeWorkspace.init();
        
        // Vider le workspace
        $(document).on('click', '.clear-workspace', function(e) {
            e.preventDefault();
            PixnimeWorkspace.clearWorkspace();
        });
        
        // Supprimer tous les avatars
        $(document).on('click', '.delete-all-avatars', function(e) {
            e.preventDefault();
            PixnimeWorkspace.deleteAllAvatars();
        });
        
        // Supprimer une variation
        $(document).on('click', '.delete-variation', function(e) {
            e.preventDefault();
            PixnimeWorkspace.deleteVariation($(this));
        });
        
        // Supprimer l'avatar principal
        $(document).on('click', '.delete-current-avatar', function(e) {
            console.log('Delete current avatar button clicked!');
            e.preventDefault();
            PixnimeWorkspace.deleteCurrentAvatar();
        });
        
        // Copier l'URL d'une image
        $(document).on('click', '.copy-image-url', function(e) {
            e.preventDefault();
            PixnimeWorkspace.copyImageUrl($(this));
        });
        
        // Ajouter une image au workspace
        $(document).on('click', '.add-to-workspace', function(e) {
            e.preventDefault();
            PixnimeWorkspace.addToWorkspace($(this));
        });
    });

})(jQuery); 
<?php
/**
 * Uninstall script for Pixnime Pro plugin
 * 
 * This file is executed when the plugin is uninstalled through WordPress admin.
 * It cleans up all plugin data according to WordPress best practices.
 * 
 * @package Pixnime_Pro
 * @since 1.0.0
 */

// Empêcher l'accès direct
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Vérifier que l'utilisateur a les permissions nécessaires
if (!current_user_can('delete_plugins')) {
    return;
}

// Fonction de log pour le debug (peut être désactivée en production)
function pixnime_log_uninstall($message, $data = null) {
    if (WP_DEBUG && WP_DEBUG_LOG) {
        error_log('Pixnime Pro Uninstall: ' . $message);
        if ($data !== null) {
            error_log('Pixnime Pro Uninstall Data: ' . print_r($data, true));
        }
    }
}

pixnime_log_uninstall('Début de la désinstallation du plugin Pixnime Pro');

/**
 * 1. NETTOYAGE DES OPTIONS WORDPRESS
 */
pixnime_log_uninstall('Suppression des options WordPress');

$options_to_delete = array(
    'pixnime_pro_settings',           // Paramètres principaux (clé API, clé OpenAI, watermark)
    'pixnime_credit_usage_log',       // Historique d'utilisation des crédits
    'pixnime_total_credits_used',     // Compteur total des crédits utilisés
    'widget_pixnime_pro_widget',      // Configuration du widget
);

foreach ($options_to_delete as $option) {
    $deleted = delete_option($option);
    pixnime_log_uninstall("Option '$option' supprimée: " . ($deleted ? 'OUI' : 'NON'));
}

/**
 * 2. NETTOYAGE DES MÉTADONNÉES UTILISATEUR
 */
pixnime_log_uninstall('Suppression des métadonnées utilisateur');

$user_meta_keys = array(
    'pixnime_avatar_url',             // URL de l'avatar principal
    'pixnime_avatar_prompt',          // Prompt utilisé pour générer l'avatar
    'pixnime_avatar_id',              // ID de l'avatar
    'pixnime_avatar_variations',      // Variations d'avatar
    'pixnime_avatar_attachment_id',   // ID de l'attachment dans la médiathèque
    'pixnime_avatar_filename',        // Nom du fichier
    'pixnime_variation_attachment_id', // ID des attachments des variations
    'pixnime_user_id',                // ID utilisateur Pixnime
    'pixnime_last_prompt',            // Dernier prompt utilisé
);

// Récupérer tous les utilisateurs
$users = get_users(array('fields' => 'ID'));
$users_cleaned = 0;
$total_meta_deleted = 0;

foreach ($users as $user_id) {
    $user_meta_deleted = 0;
    
    foreach ($user_meta_keys as $meta_key) {
        $deleted = delete_user_meta($user_id, $meta_key);
        if ($deleted) {
            $user_meta_deleted++;
            $total_meta_deleted++;
        }
    }
    
    if ($user_meta_deleted > 0) {
        $users_cleaned++;
        pixnime_log_uninstall("Utilisateur $user_id: $user_meta_deleted métadonnées supprimées");
    }
}

pixnime_log_uninstall("Total: $users_cleaned utilisateurs nettoyés, $total_meta_deleted métadonnées supprimées");

/**
 * 3. NETTOYAGE DES FICHIERS PHYSIQUES
 */
pixnime_log_uninstall('Suppression des fichiers physiques');

$upload_dir = wp_upload_dir();
$upload_path = $upload_dir['basedir'];

if (is_dir($upload_path)) {
    $files_deleted = 0;
    
    // Patterns des fichiers à supprimer
    $file_patterns = array(
        'pixnime_avatar_*.png',
        'pixnime_avatar_*.jpg',
        'pixnime_avatar_*.jpeg',
        'pixnime_variation_*.png',
        'pixnime_variation_*.jpg',
        'pixnime_variation_*.jpeg',
    );
    
    foreach ($file_patterns as $pattern) {
        $files = glob($upload_path . '/' . $pattern);
        if ($files) {
            foreach ($files as $file) {
                if (file_exists($file) && unlink($file)) {
                    $files_deleted++;
                    pixnime_log_uninstall("Fichier supprimé: " . basename($file));
                }
            }
        }
    }
    
    // Nettoyer les fichiers temporaires de watermark
    $temp_files = glob($upload_path . '/pixnime_watermark_*');
    if ($temp_files) {
        foreach ($temp_files as $file) {
            if (file_exists($file) && unlink($file)) {
                $files_deleted++;
                pixnime_log_uninstall("Fichier temporaire supprimé: " . basename($file));
            }
        }
    }
    
    pixnime_log_uninstall("$files_deleted fichiers physiques supprimés");
}

/**
 * 4. NETTOYAGE DES ATTACHMENTS DANS LA MÉDIATHÈQUE
 */
pixnime_log_uninstall('Suppression des attachments dans la médiathèque');

global $wpdb;

// Rechercher tous les attachments créés par le plugin
$attachments = $wpdb->get_results(
    "SELECT ID FROM {$wpdb->posts} 
     WHERE post_type = 'attachment' 
     AND (post_title LIKE 'Pixnime Avatar%' OR post_title LIKE 'Pixnime Variation%')"
);

$attachments_deleted = 0;

foreach ($attachments as $attachment) {
    // Supprimer l'attachment et ses métadonnées
    $deleted = wp_delete_attachment($attachment->ID, true);
    if ($deleted) {
        $attachments_deleted++;
        pixnime_log_uninstall("Attachment supprimé: ID " . $attachment->ID);
    }
}

pixnime_log_uninstall("$attachments_deleted attachments supprimés de la médiathèque");

/**
 * 5. NETTOYAGE DES TRANSIENTS
 */
pixnime_log_uninstall('Suppression des transients');

$transients_to_delete = array(
    'pixnime_pro_credits_check',
    'pixnime_pro_api_status',
    'pixnime_pro_user_info',
);

$transients_deleted = 0;

foreach ($transients_to_delete as $transient) {
    if (delete_transient($transient)) {
        $transients_deleted++;
        pixnime_log_uninstall("Transient supprimé: $transient");
    }
}

pixnime_log_uninstall("$transients_deleted transients supprimés");

/**
 * 6. NETTOYAGE DES WIDGETS
 */
pixnime_log_uninstall('Suppression des widgets');

// Désactiver le widget de toutes les sidebars
$sidebars_widgets = wp_get_sidebars_widgets();
$widget_instances_removed = 0;

if (is_array($sidebars_widgets)) {
    foreach ($sidebars_widgets as $sidebar => $widgets) {
        if (is_array($widgets)) {
            foreach ($widgets as $key => $widget) {
                if (strpos($widget, 'pixnime_pro_widget') === 0) {
                    unset($sidebars_widgets[$sidebar][$key]);
                    $widget_instances_removed++;
                    pixnime_log_uninstall("Widget supprimé de sidebar '$sidebar': $widget");
                }
            }
        }
    }
    
    if ($widget_instances_removed > 0) {
        wp_set_sidebars_widgets($sidebars_widgets);
        pixnime_log_uninstall("$widget_instances_removed instances de widget supprimées");
    }
}

/**
 * 7. NETTOYAGE DES CACHES
 */
pixnime_log_uninstall('Nettoyage des caches');

// Nettoyer les caches WordPress
if (function_exists('wp_cache_flush')) {
    wp_cache_flush();
    pixnime_log_uninstall('Cache WordPress nettoyé');
}

// Nettoyer les caches d'objets
if (function_exists('wp_cache_delete')) {
    wp_cache_delete('alloptions', 'options');
    pixnime_log_uninstall('Cache des options nettoyé');
}

/**
 * 8. NETTOYAGE DES LOGS D'ERREURS SPÉCIFIQUES
 */
pixnime_log_uninstall('Nettoyage des logs d\'erreurs');

// Nettoyer les logs d'erreurs qui contiennent "Pixnime"
$log_file = WP_CONTENT_DIR . '/debug.log';
if (file_exists($log_file) && is_writable($log_file)) {
    $log_content = file_get_contents($log_file);
    if ($log_content !== false) {
        $lines = explode("\n", $log_content);
        $cleaned_lines = array();
        $lines_removed = 0;
        
        foreach ($lines as $line) {
            if (strpos($line, 'Pixnime') === false) {
                $cleaned_lines[] = $line;
            } else {
                $lines_removed++;
            }
        }
        
        if ($lines_removed > 0) {
            file_put_contents($log_file, implode("\n", $cleaned_lines));
            pixnime_log_uninstall("$lines_removed lignes de logs Pixnime supprimées");
        }
    }
}

/**
 * 9. NETTOYAGE DES TABLES PERSONNALISÉES (si elles existent)
 */
pixnime_log_uninstall('Vérification des tables personnalisées');

// Le plugin n'utilise pas de tables personnalisées actuellement,
// mais on vérifie au cas où des versions futures en auraient créé
$custom_tables = array(
    $wpdb->prefix . 'pixnime_avatars',
    $wpdb->prefix . 'pixnime_generations',
    $wpdb->prefix . 'pixnime_usage_stats',
);

$tables_dropped = 0;

foreach ($custom_tables as $table) {
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
    if ($table_exists) {
        $wpdb->query("DROP TABLE IF EXISTS $table");
        $tables_dropped++;
        pixnime_log_uninstall("Table personnalisée supprimée: $table");
    }
}

if ($tables_dropped === 0) {
    pixnime_log_uninstall('Aucune table personnalisée trouvée');
}

/**
 * 10. NETTOYAGE FINAL ET RAPPORT
 */
pixnime_log_uninstall('Nettoyage final');

// Supprimer les répertoires temporaires créés par le plugin
$temp_dirs = array(
    WP_CONTENT_DIR . '/pixnime-temp/',
    $upload_dir['basedir'] . '/pixnime-cache/',
);

$dirs_removed = 0;

foreach ($temp_dirs as $dir) {
    if (is_dir($dir)) {
        // Supprimer récursivement le répertoire
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isDir()) {
                rmdir($file->getRealPath());
            } else {
                unlink($file->getRealPath());
            }
        }
        
        if (rmdir($dir)) {
            $dirs_removed++;
            pixnime_log_uninstall("Répertoire supprimé: $dir");
        }
    }
}

// Rapport final
$total_cleaned = array(
    'options' => count($options_to_delete),
    'users_cleaned' => $users_cleaned,
    'meta_deleted' => $total_meta_deleted,
    'files_deleted' => $files_deleted ?? 0,
    'attachments_deleted' => $attachments_deleted,
    'transients_deleted' => $transients_deleted,
    'widget_instances_removed' => $widget_instances_removed,
    'tables_dropped' => $tables_dropped,
    'dirs_removed' => $dirs_removed,
);

pixnime_log_uninstall('=== RAPPORT FINAL DE DÉSINSTALLATION ===');
pixnime_log_uninstall('Options supprimées: ' . $total_cleaned['options']);
pixnime_log_uninstall('Utilisateurs nettoyés: ' . $total_cleaned['users_cleaned']);
pixnime_log_uninstall('Métadonnées supprimées: ' . $total_cleaned['meta_deleted']);
pixnime_log_uninstall('Fichiers supprimés: ' . $total_cleaned['files_deleted']);
pixnime_log_uninstall('Attachments supprimés: ' . $total_cleaned['attachments_deleted']);
pixnime_log_uninstall('Transients supprimés: ' . $total_cleaned['transients_deleted']);
pixnime_log_uninstall('Widgets supprimés: ' . $total_cleaned['widget_instances_removed']);
pixnime_log_uninstall('Tables supprimées: ' . $total_cleaned['tables_dropped']);
pixnime_log_uninstall('Répertoires supprimés: ' . $total_cleaned['dirs_removed']);
pixnime_log_uninstall('=== FIN DE LA DÉSINSTALLATION ===');

/**
 * 11. NETTOYAGE OPTIONNEL - COMMENTÉ PAR DÉFAUT
 * 
 * Décommentez les sections suivantes si vous voulez un nettoyage plus agressif
 */

/*
// Supprimer TOUS les fichiers d'images dans uploads (ATTENTION: très agressif)
if (defined('PIXNIME_FORCE_CLEAN_ALL_IMAGES') && PIXNIME_FORCE_CLEAN_ALL_IMAGES) {
    $all_images = glob($upload_path . '/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
    foreach ($all_images as $image) {
        $image_meta = wp_get_attachment_metadata(attachment_url_to_postid($image));
        if (isset($image_meta['title']) && strpos($image_meta['title'], 'Pixnime') !== false) {
            unlink($image);
        }
    }
}

// Supprimer les entrées dans wp_postmeta liées au plugin
$wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE 'pixnime_%'");

// Supprimer les entrées dans wp_usermeta liées au plugin (déjà fait plus haut)
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'pixnime_%'");
*/

pixnime_log_uninstall('Désinstallation terminée avec succès'); 
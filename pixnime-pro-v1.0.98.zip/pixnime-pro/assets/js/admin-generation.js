/**
 * Pixnime Pro - Generation Functions
 * Fonctions pour la génération d'avatars et variations
 */

(function($) {
    'use strict';

    // Namespace pour les fonctions de génération
    window.PixnimeGeneration = {
        
        /**
         * Génération d'un ID aléatoire unique
         */
        generateRandomId: function() {
            var characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
            var timestamp = Date.now().toString().slice(-6); // 6 derniers chiffres du timestamp
            var randomPart = '';
            for (var i = 0; i < 4; i++) {
                randomPart += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            return timestamp + randomPart;
        },

        /**
         * Procédure de génération d'avatar
         */
        proceedWithGeneration: function() {
            var description = $('#avatar_description').val() || '';
            var stylePreset = $('#style_preset').val() || '';
            var avatarId = $('#avatar_randomunique').val();
            var $btn = $('#generate-avatar-btn');
            var $status = $('#generation-status');
            
            var finalDescription = PixnimeUtils.combineDescriptionWithStyle(description, stylePreset);
            
            // Masquer les erreurs précédentes
            $('#credit-error-container').hide();
            
            $btn.prop('disabled', true).text('Generating...');
            $status.show();
            
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                timeout: 180000, // 3 minutes pour la génération d'avatar
                data: {
                    action: 'pixnime_generate_avatar',
                    nonce: pixnimeProL10n.nonce,
                    description: finalDescription,
                    style_preset: stylePreset,
                    avatar_randomunique: avatarId,
                    api_key: pixnimeProL10n.api_key,
                    openai_key: pixnimeProL10n.openai_key
                },
                success: function(response){
                    console.log('AJAX response:', response);
                    
                    if(response.success){
                        // Mettre à jour l'avatar affiché
                        $('.current-avatar').attr('src', response.data.avatar_url);
                        
                        // Sauvegarder le prompt dans l'URL pour le restaurer après le rechargement
                        var currentUrl = new URL(window.location.href);
                        currentUrl.searchParams.set('last_prompt', encodeURIComponent(description));
                        history.replaceState(null, '', currentUrl.href);
                        
                        // Afficher les informations d'utilisation des crédits
                        var creditInfo = '';
                        if (response.data.credits_used) {
                            creditInfo += ' (' + response.data.credits_used + ' crédits utilisés';
                            if (response.data.credits_remaining !== undefined) {
                                creditInfo += ', ' + response.data.credits_remaining + ' restants';
                            }
                            if (response.data.total_used_today !== undefined) {
                                creditInfo += ', ' + response.data.total_used_today + ' utilisés aujourd\'hui';
                            }
                            creditInfo += ')';
                        }
                        
                        var successMessage = response.data.message || 'Avatar généré avec succès';
                        $status.html('<div class="generation-success"><span class="dashicons dashicons-yes-alt"></span><span>' + successMessage + creditInfo + '</span></div>');
                        
                        // Mise à jour de l'affichage des crédits
                        PixnimeAPI.updateHeaderCredits(response.data.credits_remaining);
                        
                        if (response.data.credits_used) {
                            PixnimeAPI.showCreditNotification(
                                response.data.credits_used,
                                response.data.credits_remaining,
                                response.data.total_used_today
                            );
                        }
                        
                        // Rechargement automatique après 3 secondes
                        setTimeout(function(){
                            location.reload();
                        }, 3000);
                    } else {
                        // Afficher l'erreur APRÈS le bouton
                        var $errorContainer = $('#credit-error-container');
                        if ($errorContainer.length === 0) {
                            $errorContainer = $('<div id="credit-error-container" class="generation-status" style="margin-top: 15px;"></div>');
                            $btn.closest('.submit').after($errorContainer);
                        }
                        $errorContainer.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>Erreur: ' + (response.data || 'Erreur inconnue') + '</span></div>');
                        $errorContainer.show();
                    }
                    
                    $btn.prop('disabled', false).text(pixnimeProL10n.generate_btn || 'Generate');
                },
                error: function(xhr, status, error){
                    // Afficher l'erreur APRÈS le bouton
                    var $errorContainer = $('#credit-error-container');
                    if ($errorContainer.length === 0) {
                        $errorContainer = $('<div id="credit-error-container" class="generation-status" style="margin-top: 15px;"></div>');
                        $btn.closest('.submit').after($errorContainer);
                    }
                    
                    if (error === 'timeout' || error === 'Internal Server Error' || xhr.status === 500) {
                        $errorContainer.html(
                            '<div class="generation-error">' +
                                '<span class="dashicons dashicons-no-alt"></span>' +
                                '<span>Erreur réseau: ' + error + '</span><br/>' +
                                '<p style="margin-top: 10px;">L\'image a sans doute été générée malgré l\'erreur. Rafraichissez la page.</p>' +
                                '<button type="button" class="button button-secondary refresh-avatar-btn" style="margin-top: 5px;">' +
                                    '<span class="dashicons dashicons-update"></span> Rafraîchir pour voir l\'image' +
                                '</button>' +
                            '</div>'
                        );
                    } else {
                        $errorContainer.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>Erreur réseau: ' + error + '</span></div>');
                    }
                    $errorContainer.show();
                    
                    $btn.prop('disabled', false).text(pixnimeProL10n.generate_btn || 'Generate');
                }
            });
        },

        /**
         * Génération d'une variation
         */
        generateVariation: function($btn) {
            var variationPrompt = $('#variation_prompt').val().trim();
            
            if (!variationPrompt) {
                alert(pixnimeProL10n.variation_prompt_required || 'Veuillez saisir un prompt pour la variation');
                return;
            }
            
            var originalText = $btn.text();
            $btn.prop('disabled', true).text('Generating...');
            
            $.ajax({
                url: pixnimeProL10n.ajax_url,
                type: 'POST',
                timeout: 180000, // 3 minutes pour la génération de variation
                data: {
                    action: 'pixnime_generate_variation',
                    nonce: pixnimeProL10n.nonce,
                    variation_prompt: variationPrompt
                },
                success: function(response) {
                    console.log('Variation response:', response);
                    
                    if (response.success) {
                        // Afficher un message de succès
                        var $status = $('#variation-status');
                        if ($status.length === 0) {
                            $status = $('<div id="variation-status" class="generation-status"></div>');
                            $btn.after($status);
                        }
                        
                        var successMessage = response.data.message || 'Variation générée avec succès';
                        $status.html('<div class="generation-success"><span class="dashicons dashicons-yes-alt"></span><span>' + successMessage + '</span></div>');
                        
                        // Rechargement automatique après 3 secondes
                        setTimeout(function(){
                            location.reload();
                        }, 3000);
                    } else {
                        var $status = $('#variation-status');
                        if ($status.length === 0) {
                            $status = $('<div id="variation-status" class="generation-status"></div>');
                            $btn.after($status);
                        }
                        $status.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>Erreur: ' + (response.data || 'Erreur inconnue') + '</span></div>');
                    }
                },
                error: function(xhr, status, error) {
                    var $prompt = $('#variation_prompt');
                    var $error = $('<div class="generation-error" style="margin-top:8px;"><span class="dashicons dashicons-no-alt"></span><span>' + (pixnimeProL10n.variation_network_error || 'Network Error : Wordpress closed connection. Image is probably generated, please refresh.') + '</span> <button type="button" class="button button-secondary refresh-avatar-btn" style="margin-left:12px;"><span class="dashicons dashicons-update"></span> ' + (pixnimeProL10n.refresh_image_btn || 'Refresh to see image') + '</button></div>');
                    // Supprimer tout message d'erreur précédent
                    $prompt.nextAll('.generation-error').remove();
                    $prompt.after($error);
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Gestion du bouton de rafraîchissement d'avatar
         */
        refreshAvatar: function() {
            var $btn = $('.refresh-avatar-btn');
            $btn.prop('disabled', true).text('Rafraîchissement...');
            
            setTimeout(function() {
                location.reload();
            }, 1000);
        },

        /**
         * Initialisation de l'ID unique
         */
        initializeUniqueId: function() {
            // Si l'ID n'est pas déjà défini, en générer un nouveau
            var currentId = $('#avatar_randomunique').val();
            if (!currentId || currentId.trim() === '') {
                $('#avatar_randomunique').val(this.generateRandomId());
            }
        },

        /**
         * Restaurer le prompt depuis l'URL
         */
        restorePromptFromUrl: function() {
            var urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('last_prompt')) {
                var lastPrompt = decodeURIComponent(urlParams.get('last_prompt'));
                var avatarDescription = $('#avatar_description');
                if (avatarDescription.length && lastPrompt.trim()) {
                    avatarDescription.val(lastPrompt);
                    urlParams.delete('last_prompt');
                    var newUrl = window.location.pathname + '?' + urlParams.toString();
                    history.replaceState(null, '', newUrl);
                }
            }
        },

        /**
         * Initialisation des fonctions de génération
         */
        init: function() {
            console.log('Pixnime Pro Generation JS loaded');
            
            // Initialiser l'ID unique
            this.initializeUniqueId();
            
            // Restaurer le prompt depuis l'URL
            this.restorePromptFromUrl();
        }
    };

    // Gestionnaires d'événements pour la génération
    $(document).ready(function() {
        PixnimeGeneration.init();
        
        // Génération d'avatar via formulaire
        $('#pixnime-generate-form').on('submit', function(e){
            e.preventDefault();
            
            var $form = $(this);
            var $btn = $('#generate-avatar-btn');
            var $status = $('#generation-status');
            
            // Vérifier s'il y a déjà des avatars dans le workspace
            var hasCurrentAvatar = $('.main-avatar-image').length > 0;
            var hasVariations = $('.variation-card').length > 0;
            
            if (hasCurrentAvatar || hasVariations) {
                $status.show();
                $status.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>' + pixnimeProL10n.workspace_not_empty_error + '</span></div>');
                return;
            }
            
            // Vérifier les crédits avant de continuer
            $btn.prop('disabled', true).text(pixnimeProL10n.generate_btn || 'Generate');
            $status.show();
            
            PixnimeAPI.checkCreditsBeforeGeneration(function(result) {
                if (!result.success) {
                    // Afficher l'erreur APRÈS le bouton au lieu d'avant
                    var $errorContainer = $('#credit-error-container');
                    if ($errorContainer.length === 0) {
                        $errorContainer = $('<div id="credit-error-container" class="generation-status" style="margin-top: 15px;"></div>');
                        $btn.closest('.submit').after($errorContainer);
                    }
                    $errorContainer.html('<div class="generation-error"><span class="dashicons dashicons-no-alt"></span><span>' + result.message + '</span></div>');
                    $errorContainer.show();
                    
                    $btn.prop('disabled', false).text(pixnimeProL10n.generate_btn || 'Generate');
                    return;
                }
                
                // Masquer les erreurs précédentes s'il y en a
                $('#credit-error-container').hide();
                
                // Crédits OK, continuer avec la génération
                PixnimeGeneration.proceedWithGeneration();
            });
        });
        
        // Fallback: Gestionnaire sur le bouton de génération
        $('#generate-avatar-btn').on('click', function(e) {
            e.preventDefault();
            $('#pixnime-generate-form').submit();
        });
        
        // Génération de variations
        $(document).on('click', '#generate-variation-btn', function(e) {
            e.preventDefault();
            PixnimeGeneration.generateVariation($(this));
        });
        
        // Fallback pour les variations (ancienne classe)
        $(document).on('click', '.generate-variation', function(e) {
            e.preventDefault();
            PixnimeGeneration.generateVariation($(this));
        });
        
        // Bouton de rafraîchissement
        $(document).on('click', '.refresh-avatar-btn', function(e) {
            e.preventDefault();
            PixnimeGeneration.refreshAvatar();
        });
    });

})(jQuery); 